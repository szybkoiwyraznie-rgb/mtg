import { defineCard, createRegistry } from './registry.js';
import { ABILITY_TYPE, createAbility } from '../engine/abilities.js';

/**
 * Syntetyczny katalog testowy.
 *
 * To NIE są realne karty MtG. Zgodnie z ADR 0010 realne karty wejdą dopiero
 * z listy właściciela, każda poprzedzona pobraniem danych ze Scryfall. Do tego
 * czasu katalog celowo zawiera wyłącznie definicje testowe (oznaczone setem
 * SYNTH), które zasilają pełny przepływ danych: registry → walidacja talii →
 * materializacja obiektów gry → symulacja partii.
 *
 * Katalog obejmuje też statusy in-development/limited/unsupported, żeby
 * testy negatywne miały stałe punkty odniesienia.
 */

// Batch 9 token ability: kept as a reusable descriptor for both the token
// registry entry and Dragonbroods' Relic's create_token effect (ADR 0002).
const BATCH9_RELIQUARY_DRAGON_ETB = createAbility({
  type: ABILITY_TYPE.triggered,
  trigger: { event: 'enter_battlefield', requiresTarget: { type: 'any_target', prefer: 'opponent' } },
  effect: { type: 'damage', amount: 3 },
});

/**
 * Pierwszy batch realnych kart (ADR 0010, decyzja właściciela 2026-08-01):
 * Highland Game (KTK), Kappa Tech-Wrecker (NEO), Segmented Krotiq (DTK).
 * Dane pobrane ze Scryfall przed kodowaniem (odfiltrowane JSON-y w docs/cards/),
 * a Oracle text zapisany dosłownie poniżej. Koszt many jest uproszczony do
 * liczby całkowitej (pula many jest bezbarwna) — {1}{G} = 2, {5}{G} = 6.
 * Świadome ograniczenia wsparcia każdej karty są opisane w ENGINE_MILESTONES.md.
 */
export const REAL_CARDS = Object.freeze([
  defineCard({
    id: 'highland-game', name: 'Highland Game', set: 'KTK',
    // M100/E10 (P10): podtyp wg Oracle (Creature — Elk).
    types: ['Creature'], subtypes: ['Elk'], colors: ['G'], power: 2, toughness: 1, manaCost: 2,
    oracleText: 'When this creature dies, you gain 2 life.',
    imageUri: 'https://cards.scryfall.io/large/front/7/f/7fbb10a9-486a-4b9a-b3f5-c17f661af2b2.jpg?1783939067',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'dies' },
        effect: [{ type: 'gain_life', amount: 2 }],
      }),
    ],
    artId: 509,
    plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'kappa-tech-wrecker', name: 'Kappa Tech-Wrecker', set: 'NEO',
    // M100/E10 (P10): podtypy wg Oracle (Creature — Turtle Ninja).
    types: ['Creature'], subtypes: ['Turtle', 'Ninja'], colors: ['G'], power: 1, toughness: 3, manaCost: 2,
    oracleText: 'Ninjutsu {1}{G}\nThis creature enters with a deathtouch counter on it.\nWhenever this creature deals combat damage to a player, you may remove a deathtouch counter from it. When you do, exile target artifact or enchantment that player controls.',
    imageUri: 'https://cards.scryfall.io/large/front/d/3/d3a7bc69-4500-4e7e-94e4-67b85597bd82.jpg?1783923845',
    entersWithCounters: { deathtouch: 1 },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'ninjutsu',
        // M257 r4 (Żywy Tester, g2004): Oracle „Ninjutsu {1}{G}" — pita
        // ZIELONA. Wpis {mana: 2} (bez colors) pozwalał płacić dowolną maną
        // (L57/ADR 0022; ta sama klasa co r3/C — pipy w kosztach).
        cost: { mana: 2, colors: ['G'] },
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: {
          event: 'combat_damage_to_player',
          // Temat 2: „you may remove a deathtouch counter... When you do, exile
          // target artifact or enchantment" — cel wybiera kontroler, a „you
          // may" daje opcję odmowy (allowNone).
          requiresTarget: { type: 'artifact_or_enchantment', controlledBy: 'damaged_player', optional: true },
        },
        effect: [
          { type: 'remove_counter', counter: 'deathtouch', amount: 1 },
          { type: 'exile_permanent', targetType: 'artifact_or_enchantment', controlledBy: 'damaged_player' },
        ],
      }),
    ],
    artId: 278,
    plan: 'Kamigawa',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'segmented-krotiq', name: 'Segmented Krotiq', set: 'DTK',
    // M100/E10 (P10): podtyp wg Oracle (Creature — Insect).
    types: ['Creature'], subtypes: ['Insect'], colors: ['G'], power: 6, toughness: 5, manaCost: 6,
    oracleText: 'Megamorph {6}{G} (You may cast this card face down as a 2/2 creature for {3}. Turn it face up any time for its megamorph cost and put a +1/+1 counter on it.)',
    imageUri: 'https://cards.scryfall.io/large/front/d/c/dcdbe824-f9c7-4f4d-af92-438b16057d99.jpg?1783938576',
    morph: { cost: 3, megamorphCost: 7, colors: ['G'] },
    artId: 523,
    plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
    notes: ['obrót twarzą do góry tylko za koszt megamorph (bez wariantu {3} bez licznika)'],
  }),
  // Drugi batch realnych kart (2026-08-01): Grizzled Outcasts (ISD),
  // Entrancing Lyre (THB), Zoraline, Cosmos Caller (BLB).
  // Strona przednia wilkołaka (transform DFC); tył to osobna definicja
  // 'krallenhorde-wantons' (limited — nie taliowalna, jak token).
  defineCard({
    id: 'grizzled-outcasts', name: 'Grizzled Outcasts', set: 'ISD',
    types: ['Creature'], subtypes: ['Human', 'Werewolf'], colors: ['G'],
    power: 4, toughness: 4, manaCost: 5, keywords: ['transform'],
    oracleText: 'At the beginning of each upkeep, if no spells were cast last turn, transform this creature.',
    imageUri: 'https://cards.scryfall.io/large/front/4/b/4b43b0cb-a5a3-47b4-9b6b-9d2638222bb6.jpg?1783940923',
    transformTo: 'krallenhorde-wantons',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        // „At the beginning of EACH upkeep..." — jawne: każdy upkeep (CR 504.x).
        trigger: { event: 'upkeep', condition: { noSpellsLastTurn: true, eachUpkeep: true } },
        effect: [{ type: 'transform' }],
      }),
    ],
    artId: 171,
    plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
    notes: ['transform tylko przez trigger upkeep (bez ręcznego obrotu)'],
  }),
  defineCard({
    id: 'krallenhorde-wantons', name: 'Krallenhorde Wantons', set: 'ISD',
    types: ['Creature'], subtypes: ['Werewolf'], colors: ['G'],
    power: 7, toughness: 7, manaCost: 5, keywords: ['transform'],
    oracleText: 'At the beginning of each upkeep, if a player cast two or more spells last turn, transform this creature.',
    imageUri: 'https://cards.scryfall.io/large/back/4/b/4b43b0cb-a5a3-47b4-9b6b-9d2638222bb6.jpg?1783940923',
    transformTo: 'grizzled-outcasts',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'upkeep', condition: { minSpellsLastTurn: 2, eachUpkeep: true } },
        effect: [{ type: 'transform' }],
      }),
    ],
    artId: 486,
    plan: 'Innistrad',
    support: { status: 'limited', limitations: ['tylna strona transform — nie można umieścić w talii'] },
  }),
  defineCard({
    id: 'entrancing-lyre', name: 'Entrancing Lyre', set: 'THB',
    types: ['Artifact'], colors: [], manaCost: 3,
    oracleText: 'You may choose not to untap this artifact during your untap step.\n{X}, {T}: Tap target creature with power X or less. It doesn\'t untap during its controller\'s untap step for as long as this artifact remains tapped.',
    imageUri: 'https://cards.scryfall.io/large/front/0/6/064abee6-7394-4b75-946f-4ad9840034ac.jpg?1783931515',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true, manaX: true, maxPowerX: true },
        targets: [{ type: 'creature' }],
        effect: [
          { type: 'tap_permanent' },
          { type: 'lock_untap' },
        ],
      }),
    ],
    artId: 195,
    plan: 'Theros',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'zoraline', name: 'Zoraline, Cosmos Caller', set: 'BLB',
    types: ['Legendary', 'Creature'], subtypes: ['Bat', 'Cleric'], colors: ['W', 'B'],
    keywords: ['flying', 'vigilance'], power: 3, toughness: 3, manaCost: 3,
    oracleText: 'Flying, vigilance\nWhenever a Bat you control attacks, you gain 1 life.\nWhenever Zoraline enters or attacks, you may pay {W}{B} and 2 life. When you do, return target nonland permanent card with mana value 3 or less from your graveyard to the battlefield with a finality counter on it.',
    imageUri: 'https://cards.scryfall.io/large/front/b/7/b7f99fd5-5298-4b27-923d-9d31203c931a.jpg?1783910787',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'bat_attacks' },
        effect: [{ type: 'gain_life', amount: 1 }],
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: {
          event: 'enter_battlefield',
          requiresTarget: { type: 'permanent_card_in_graveyard', controlledBy: 'controller', maxManaValue: 3 },
          payMana: 2, payColors: ['W', 'B'], payLife: 2,
        },
        effect: [
          { type: 'pay_mana', amount: 2 },
          { type: 'pay_life', amount: 2 },
          { type: 'return_permanent_from_graveyard', finalityCounter: true },
        ],
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: {
          event: 'attacks',
          requiresTarget: { type: 'permanent_card_in_graveyard', controlledBy: 'controller', maxManaValue: 3 },
          payMana: 2, payColors: ['W', 'B'], payLife: 2,
        },
        effect: [
          { type: 'pay_mana', amount: 2 },
          { type: 'pay_life', amount: 2 },
          { type: 'return_permanent_from_graveyard', finalityCounter: true },
        ],
      }),
    ],
    artId: 480,
    plan: 'Bloomburrow',
    support: { status: 'supported', limitations: [] },
  }),
  // Trzeci batch realnych kart (2026-08-01): Rupture Spire (CON),
  // Leafcrown Dryad (THS), Prismari Campus (STX).
  defineCard({
    id: 'rupture-spire', name: 'Rupture Spire', set: 'CON',
    types: ['Land'], entersTapped: true,
    oracleText: 'This land enters tapped.\nWhen this land enters, sacrifice it unless you pay {1}.\n{T}: Add one mana of any color.',
    imageUri: 'https://cards.scryfall.io/large/front/5/6/568df642-3ad7-401c-a133-edb56970c3a1.jpg?1783942460',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', payMana: 1, sacrificeIfUnpaid: true },
        effect: [],
      }),
    ],
    artId: 448,
    plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'leafcrown-dryad', name: 'Leafcrown Dryad', set: 'THS',
    types: ['Enchantment', 'Creature'], subtypes: ['Nymph', 'Dryad'], colors: ['G'],
    keywords: ['reach'], power: 2, toughness: 2, manaCost: 2,
    // Bestow {3}{G} (CR 702.103): alternatywny koszt — czar staje się czarem
    // aury z celem „stwór\"; po wejściu załączony NIE jest stworem, a po
    // odłączeniu znów nim jest. Buff zaczarowanego stwora: +2/+2 i reach.
    bestow: { cost: 4, pump: { power: 2, toughness: 2 }, keywords: ['reach'] },
    oracleText: 'Bestow {3}{G} (If you cast this card for its bestow cost, it\'s an Aura spell with enchant creature. It becomes a creature again if it\'s not attached.)\nReach\nEnchanted creature gets +2/+2 and has reach.',
    imageUri: 'https://cards.scryfall.io/large/front/8/2/8202e426-ad91-4d2e-9373-7a829b58fff5.jpg?1783939745',
    artId: 521,
    plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'prismari-campus', name: 'Prismari Campus', set: 'STX',
    types: ['Land'], entersTapped: true,
    oracleText: 'This land enters tapped.\n{T}: Add {U} or {R}.\n{4}, {T}: Scry 1. (Look at the top card of your library. You may put that card on the bottom.)',
    imageUri: 'https://cards.scryfall.io/large/front/7/6/768120f5-9401-4e52-924e-3374bde65b3d.jpg?1783927271',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 4, tap: true },
        effect: { type: 'scry', amount: 1 },
      }),
    ],
    artId: 459,
    plan: 'Arcavios',
    support: { status: 'supported', limitations: [] },
    notes: ['scry 1: decyzja wierzch/spód jest realna (komenda resolve_scry); gracz widzi wyłącznie własne przeglądane karty'],
  }),
  // Czwarty batch realnych kart (2026-08-01): Gloomfang Mauler (MOM),
  // Serra's Embrace (DVD), Cloak of the Bat (CLB). Dane pobrane ze Scryfall
  // przed kodowaniem (docs/cards/), Oracle text dosłownie. Zasada
  // właściciela: karta kodowana w 100% mechanik — limitations na mechanikach
  // samej karty nie wchodzą w grę (puste listy poniżej to konsekwencja).
  defineCard({
    id: 'gloomfang-mauler', name: 'Gloomfang Mauler', set: 'MOM',
    types: ['Creature'], subtypes: ['Nightmare'], colors: ['B'],
    keywords: ['menace'], power: 5, toughness: 5, manaCost: 7,
    // Backup 2 (CR 702.165): ETB trigger — dwa liczniki +1/+1 na docelowym
    // stworze; jeśli to INNY stwór niż źródło, zyskuje menace do końca tury.
    // Cel wybiera kontroler blokującą decyzją resolve_backup.
    backup: { counters: 2, grantKeywords: ['menace'] },
    oracleText: 'Swampcycling {2} ({2}, Discard this card: Search your library for a Swamp card, reveal it, put it into your hand, then shuffle.)\nBackup 2 (When this creature enters, put two +1/+1 counters on target creature. If that\'s another creature, it gains the following ability until end of turn.)\nMenace',
    imageUri: 'https://cards.scryfall.io/large/front/0/2/025a5338-133f-486d-9f73-0896226685c0.jpg?1783917008',
    abilities: [
      // Swampcycling {2} (CR 702.28-29): cycling z kwalifikacją na podtyp
      // Swamp — szuka własnej biblioteki, reveal do ręki, tasowanie.
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'cycling',
        cost: { mana: 2 },
        cycling: { subtypes: ['Swamp'] },
        effect: [],
      }),
    ],
    artId: 199,
    plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'serras-embrace', name: 'Serra\'s Embrace', set: 'DVD',
    types: ['Enchantment'], subtypes: ['Aura'], colors: ['W'], manaCost: 4,
    // Czysta aura (CR 303.4): „enchant creature" — czar aury z celem (każdy
    // stwór); buff zaczarowanego stwora; przy nielegalnym celu w rozstrzygnięciu
    // trafia do grobu (inaczej niż bestow), ginie też po stracie gospodarza
    // (CR 704.5m).
    aura: { pump: { power: 2, toughness: 2 }, keywords: ['flying', 'vigilance'] },
    oracleText: 'Enchant creature\nEnchanted creature gets +2/+2 and has flying and vigilance. (Attacking doesn\'t cause it to tap.)',
    imageUri: 'https://cards.scryfall.io/large/front/2/c/2c45c4b3-f652-4b55-a316-55a864ac2342.jpg?1783938784',
    artId: 110,
    plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'cloak-of-the-bat', name: 'Cloak of the Bat', set: 'CLB',
    types: ['Artifact'], subtypes: ['Equipment'], colors: [], manaCost: 2,
    // Equipment (CR 301.5/702.6): equip {2} — sorcery-speed, cel własny stwór;
    // nosiciel ma flying i haste; equipment ZOSTAJE na polu bitwy gdy nosiciel
    // odejdzie (CR 704.5n) i można je przełożyć na innego własnego stwora.
    equipment: { equip: 2, keywords: ['flying', 'haste'] },
    oracleText: 'Equipped creature has flying and haste.\nEquip {2} ({2}: Attach to target creature you control. Equip only as a sorcery.)',
    imageUri: 'https://cards.scryfall.io/large/front/2/f/2f508a65-ff32-480a-b9c6-075074d0c3c3.jpg?1783922679',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'equip',
        cost: { mana: 2 },
        effect: [],
      }),
    ],
    artId: 200,
    plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
  }),
  // Piąty batch realnych kart (2026-08-02): Midnight Guard (DKA), Holdout
  // Settlement (OGW), Skyclave Geopede (ZNR). Dane Oracle w docs/cards/.
  defineCard({
    id: 'midnight-guard', name: 'Midnight Guard', set: 'DKA',
    types: ['Creature'], subtypes: ['Human', 'Soldier'], colors: ['W'],
    power: 2, toughness: 3, manaCost: 3,
    oracleText: 'Whenever another creature enters, untap this creature.',
    imageUri: 'https://cards.scryfall.io/large/front/2/2/2264b760-c527-470d-bad0-d8baaf543631.jpg?1783940853',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'another_creature_enters' },
        effect: { type: 'untap_permanent' },
      }),
    ],
    artId: 385,
    plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'holdout-settlement', name: 'Holdout Settlement', set: 'OGW',
    types: ['Land'], colors: [],
    oracleText: '{T}: Add {C}. ({C} represents colorless mana.)\n{T}, Tap an untapped creature you control: Add one mana of any color.',
    imageUri: 'https://cards.scryfall.io/large/front/c/f/cf08c317-6f2d-47e3-ab5b-8af73fd3e404.jpg?1783937892',
    abilities: [
      // M212/A (zgłoszenie właściciela): karta ma DWIE odrębne zdolności
      // manowe. Wcześniej była jedna hybryda — koszt z drugiej („tapnij
      // stwora") sklejony z efektem pierwszej (mana bezbarwna), więc gracz
      // płacił stworem za {C} i nie miał wcale dostępu do many dowolnego
      // koloru (precedens kodowania: Heap Gate).
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        effect: { type: 'add_mana', amount: 1 },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true, tapCreature: true },
        effect: { type: 'add_mana', amount: 1, colors: ['W', 'U', 'B', 'R', 'G'] },
      }),
    ],
    artId: 79,
    plan: 'Zendikar',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'skyclave-geopede', name: 'Skyclave Geopede', set: 'ZNR',
    types: ['Creature'], subtypes: ['Insect'], colors: ['R'],
    keywords: ['trample'], power: 3, toughness: 1, manaCost: 3,
    oracleText: 'Trample\nLandfall — Whenever a land you control enters, this creature gets +2/+2 until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/d/b/db9103c9-084f-4ad2-8b7b-ca52be97619d.jpg?1783929349',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'land_entered_under_your_control' },
        effect: { type: 'pump', power: 2, toughness: 2 },
      }),
    ],
    artId: 493,
    plan: 'Zendikar',
    support: { status: 'supported', limitations: [] },
  }),
  // Szósty batch realnych kart (2026-08-02): Soulmender (M20), Illusory
  // Demon (ARB), Jyoti, Moag Ancient (M3C). Dane Oracle w docs/cards/.
  defineCard({
    id: 'soulmender', name: 'Soulmender', set: 'M20',
    types: ['Creature'], subtypes: ['Human', 'Cleric'], colors: ['W'],
    power: 1, toughness: 1, manaCost: 1,
    oracleText: '{T}: You gain 1 life.',
    imageUri: 'https://cards.scryfall.io/large/front/3/1/31b83ffd-bd08-48c6-98a3-811abc203f60.jpg?1783933019',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        effect: { type: 'gain_life', amount: 1 },
      }),
    ],
    artId: 13,
    plan: 'Śródziemie',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'illusory-demon', name: 'Illusory Demon', set: 'ARB',
    types: ['Creature'], subtypes: ['Demon', 'Illusion'], colors: ['B', 'U'],
    keywords: ['flying'], power: 4, toughness: 3, manaCost: 3,
    oracleText: 'Flying\nWhen you cast a spell, sacrifice this creature.',
    imageUri: 'https://cards.scryfall.io/large/front/f/4/f4d69f7f-ac70-477b-9246-8d81fef7d335.jpg?1783942438',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'when_you_cast_spell' },
        effect: { type: 'sacrifice_permanent' },
      }),
    ],
    artId: 305,
    plan: 'Alara',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'jyoti-moag-ancient', name: 'Jyoti, Moag Ancient', set: 'M3C',
    types: ['Legendary', 'Creature'], subtypes: ['Elemental'], colors: ['G', 'U'],
    power: 2, toughness: 4, manaCost: 4,
    oracleText: 'When Jyoti enters, create a 1/1 green Forest Dryad land creature token for each time you\'ve cast your commander from the command zone this game. (They\'re affected by summoning sickness.)\nAt the beginning of each combat, land creatures you control get +X/+X until end of turn, where X is Jyoti\'s power.',
    imageUri: 'https://cards.scryfall.io/large/front/9/d/9d2cb8d1-6aaa-487f-bf5a-89d657c0f37e.jpg?1783911437',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: {
          type: 'create_token',
          cardId: 'token_forest_dryad',
          name: 'Forest Dryad',
          kind: 'creature', power: 1, toughness: 1, colors: ['G'],
          types: ['Land', 'Creature'], subtypes: ['Forest', 'Dryad'],
          // Liczba rzuceń commandera z command zone — w obecnym formacie bez
          // command zone zawsze 0, więc 0 tokenów (mechanicznie poprawne).
          amount: 'commander_casts',
        },
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        // Oracle: „At the beginning of EACH combat…" — także w turze
        // przeciwnika (deskryptor, nie warunek po nazwie karty — ADR 0002).
        trigger: { event: 'beginning_of_combat', eachCombat: true },
        effect: { type: 'buff_land_creatures', power: 'source_power', toughness: 'source_power' },
      }),
    ],
    artId: 307,
    plan: 'Śródziemie',
    support: { status: 'supported', limitations: ['brak command zone w engine — liczba rzuceń commandera zawsze 0, więc ETB nie tworzy tokenów w tym formacie (mechanicznie poprawne); token Forest Dryad zdefiniowany i testowany'] },
    notes: ['land creatures to obiekty z typem Land i rodzajem creature (walczą i tapują się na manę)'],
  }),
  // Token Jyoti (M3C): 1/1 zielony Forest Dryad — land creature (typ Land
  // + rodzaj creature): walczy jak stwór i tapuje się na manę jak land.
  // Definicja tokena — nie taliowalna (limited), jak token_goblin.
  defineCard({
    id: 'token_forest_dryad', name: 'Forest Dryad', set: null,
    types: ['Land', 'Creature', 'Token'], subtypes: ['Forest', 'Dryad'], colors: ['G'],
    power: 1, toughness: 1, manaCost: 0,
    imageUri: 'https://cards.scryfall.io/large/front/1/0/107be8ee-ee22-4d37-94f1-2a5b438fbe05.jpg?1783911122',  // tm3c
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii'] },
  }),
  // Siódmy batch realnych kart (2026-08-02): Fake Your Own Death (OTJ),
  // Puppeteer Clique (SHM), Unstable Frontier (CON), Apprentice Wizard (2XM),
  // Delta Bloodflies (TDM). Dane Oracle w docs/cards/.
  defineCard({
    id: 'fake-your-own-death', name: 'Fake Your Own Death', set: 'OTJ',
    types: ['Instant'], colors: ['B'], manaCost: 2,
    oracleText: 'Until end of turn, target creature gets +2/+0 and gains "When this creature dies, return it to the battlefield tapped under its owner\'s control and you create a Treasure token." (It\'s an artifact with "{T}, Sacrifice this token: Add one mana of any color.")',
    imageUri: 'https://cards.scryfall.io/large/front/7/9/79a17ab9-13c9-41d4-a143-82d8caacfd8b.jpg?1783911832',
    spell: {
      timing: 'instant',
      targets: [{ type: 'creature' }],
      effects: [
        { type: 'pump', power: 2, toughness: 0 },
        // Nadanie zdolności „do końca tury\": trigger dies, który zwraca
        // stwora zatapniętego i tworzy token Treasure. Deskryptor jest
        // generyczny (grant_abilities + return_to_battlefield_tapped).
        {
          type: 'grant_abilities',
          abilities: [
            createAbility({
              type: ABILITY_TYPE.triggered,
              trigger: { event: 'dies' },
              effect: [
                { type: 'return_to_battlefield_tapped' },
                {
                  type: 'create_token', cardId: 'token_treasure', name: 'Treasure',
                  kind: 'artifact', colors: [], types: ['Artifact'], subtypes: ['Treasure'],
                  abilities: [
                    createAbility({
                      type: ABILITY_TYPE.activated,
                      cost: { tap: true, sacrificeSelf: true },
                      // Mana ze Skarba jest identyfikowalna (Marut, Batch 16).
                      effect: { type: 'add_mana', amount: 1, fromTreasure: true },
                    }),
                  ],
                },
              ],
            }),
          ],
        },
      ],
    },
    artId: 295,
    plan: 'Thunder Junction',
    support: { status: 'supported', limitations: [] },
    notes: ['nadany trigger dies działa z LKI: przechodzi z obiektem do grobu w tej samej turze (formerAbilityGrants)'],
  }),
  defineCard({
    id: 'puppeteer-clique', name: 'Puppeteer Clique', set: 'SHM',
    types: ['Creature'], subtypes: ['Faerie', 'Wizard'], colors: ['B'],
    keywords: ['flying', 'persist'], power: 3, toughness: 2, manaCost: 5,
    oracleText: 'Flying\nWhen this creature enters, put target creature card from an opponent\'s graveyard onto the battlefield under your control. It gains haste. At the beginning of your next end step, exile it.\nPersist (When this creature dies, if it had no -1/-1 counters on it, return it to the battlefield under its owner\'s control with a -1/-1 counter on it.)',
    imageUri: 'https://cards.scryfall.io/large/front/6/f/6ff839e1-6f76-4a24-a87c-d4589b1abf66.jpg?1783942753',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: {
          event: 'enter_battlefield',
          requiresTarget: { type: 'creature_card_in_opponent_graveyard' },
        },
        effect: [{ type: 'reanimate_under_your_control', grantKeywords: ['haste'], exileAtNextEndStep: true }],
      }),
      // Persist (CR 702.79) — trigger dies z warunkiem LKI „brak liczników -1/-1\".
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'dies', condition: { noMinusCountersWhenDied: true } },
        effect: [{ type: 'return_with_counter', counter: '-1/-1', amount: 1 }],
      }),
    ],
    artId: 343,
    plan: 'Lorwyn',
    support: { status: 'supported', limitations: [] },
  }),

  // 4. Courage in Crisis (WAR) {2}{G} Instant — +1/+1 counter on target
  // creature, then proliferate. Dwa efekty w spell (sekwencyjnie):
  // add_counter, potem proliferate. Proliferate wybiera cele (każdy
  // gracz/permanent z licznikami) — batch22 (mechanika z commit b8c43a8).
  defineCard({
    id: 'courage-in-crisis', name: 'Courage in Crisis', set: 'WAR',
    // M259/B1: Oracle to SORCERY ({2}{G}, WAR/CMM) — dotąd zamodelowana jako
    // Instant (rzut w dowolnym momencie z priorytetem, CR 307.1 złamane).
    types: ['Sorcery'], colors: ['G'], manaCost: 3,
    oracleText: 'Put a +1/+1 counter on target creature, then proliferate.',
    imageUri: 'https://cards.scryfall.io/large/front/6/7/67a22083-9ef9-4ff7-8502-3a77e69299df.jpg?1783933415',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'creature' }],
      effects: [
        { type: 'add_counter', counter: '+1/+1', amount: 1 },
        // Proliferate (CR 701.27): po +1/+1 counter wybieramy DOWOLNĄ
        // liczbę celów (permanenty z licznikami + gracze z poison > 0);
        // każdy dostaje +1 do każdego typu licznika. Brak wybranych
        // celów → czeka na resolve_proliferate z listą (kolejka
        // pendingProliferate ustawiana wewnętrznie).
        { type: 'proliferate' },
      ],
    },
    artId: 124,
    plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
    notes: ['proliferate kolejkuje pendingProliferate po add_counter; gracz musi jawnie wywołać resolve_proliferate'],
  }),

  // 5. Selesnya Charm (RTR) {G}{W} Instant — modalne 3 tryby.
  defineCard({
    id: 'selesnya-charm', name: 'Selesnya Charm', set: 'RTR',
    types: ['Instant'], colors: ['G', 'W'], manaCost: 2,
    oracleText: 'Choose one —\n• Target creature gets +2/+2 and gains trample until end of turn.\n• Exile target creature with power 5 or greater.\n• Create a 2/2 white Knight creature token with vigilance.',
    imageUri: 'https://cards.scryfall.io/large/front/a/9/a9848eab-1d3a-4ab0-adf6-c20858aa3afb.jpg?1783940333',
    spell: {
      timing: 'instant',
      modes: [
        // Tryb A (Pump): +2/+2 trample EOT.
        { name: 'Wzmocnienie', targets: [{ type: 'creature' }],
          effects: [
            { type: 'pump', power: 2, toughness: 2 },
            { type: 'grant_keywords_until_end_of_turn', keywords: ['trample'] },
          ] },
        // Tryb B (Exile): stwór z mocą ≥ 5.
        { name: 'Wygnanie', targets: [{ type: 'creature_with_power_at_least', min: 5 }],
          effects: [{ type: 'exile_permanent' }] },
        // Tryb C (Token): 2/2 biały Knight z vigilance.
        { name: 'Rycerz',
          effects: [{
            type: 'create_token', cardId: 'token_knight', name: 'Knight',
            kind: 'creature', power: 2, toughness: 2, colors: ['W'],
            types: ['Creature'], subtypes: ['Knight'], keywords: ['vigilance'],
            amount: 1,
          }] },
      ],
    },
    artId: 46,
    plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
  }),

  // 6. Wormfang Newt (JUD) {1}{U} 2/2 Salamander — ETB exile land you control
  // (T2: cel wybiera kontroler, nowy efekt exile_own_land zapamiętuje
  // exiledCardIds na źródle). LTB return exiled card to battlefield under
  // owner's control (return_exiled_to_battlefield czyta exiledCardId z LKI).
  defineCard({
    id: 'wormfang-newt', name: 'Wormfang Newt', set: 'JUD',
    // M259/B4: Oracle „Creature — Nightmare Salamander Beast" (JUD) — dotąd
    // tylko Salamander; pełna linia typów (tribal: Nightmare/Beast, Changeling).
    types: ['Creature'], subtypes: ['Nightmare', 'Salamander', 'Beast'], colors: ['U'],
    power: 2, toughness: 2, manaCost: 2,
    oracleText: 'When this creature enters, exile a land you control.\nWhen this creature leaves the battlefield, return the exiled card to the battlefield under its owner\'s control.',
    imageUri: 'https://cards.scryfall.io/large/front/d/f/df8012c1-76ec-4c36-8b38-5bc41ce5e156.jpg?1783945125',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: {
          event: 'enter_battlefield',
          requiresTarget: { type: 'land_you_control' },
        },
        effect: [{ type: 'exile_own_land' }],
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'leaves_battlefield' },
        effect: [{ type: 'return_exiled_to_battlefield' }],
      }),
    ],
    artId: 316,
    plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
    notes: ['ETB exile land bez innych landów: trigger odpala się, ale exile_own_land nic nie robi (brak celu) — LTB też no-op'],
  }),


  // 7. Raise the Alarm (CMR) {1}{W} Instant — create two 1/1 white Soldier
  // creature tokens (re-uses token_soldier z Captain's Call).
  defineCard({
    id: 'raise-the-alarm', name: 'Raise the Alarm', set: 'CMR',
    types: ['Instant'], colors: ['W'], manaCost: 2,
    oracleText: 'Create two 1/1 white Soldier creature tokens.',
    imageUri: 'https://cards.scryfall.io/large/front/6/c/6c7c8527-55f6-494d-b4f7-c427a5735053.jpg?1783928875',
    spell: {
      timing: 'instant', targets: [],
      effects: [{
        type: 'create_token', cardId: 'token_soldier', name: 'Soldier',
        kind: 'creature', power: 1, toughness: 1, colors: ['W'],
        types: ['Creature'], subtypes: ['Soldier'], amount: 2,
      }],
    },
    artId: 298,
    plan: 'Śródziemie',
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Cellar Door (ISD) {2} Artifact — activated {3},{T} mill bottom +
  // conditional 2/2 B Zombie token if milled creature (re-uses
  // token_zombie z Undead Servant + mill_from_bottom z engine-batch22).
  defineCard({
    id: 'cellar-door', name: 'Cellar Door', set: 'ISD',
    types: ['Artifact'], colors: [], manaCost: 2,
    // M117: Oracle mówi o karcie ze SPODU biblioteki („puts the bottom card”),
    // nie o mill 1 (wierzch). Mechanika (`mill_from_bottom`) była poprawna —
    // błędny był tekst pokazywany graczowi.
    oracleText: '{3}, {T}: Target player puts the bottom card of their library into their graveyard. If it\'s a creature card, you create a 2/2 black Zombie creature token.',
    imageUri: 'https://cards.scryfall.io/large/front/9/7/97bdfb00-7773-4af6-895c-c90088a96b07.jpg?1783940904',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true, mana: 3 },
        targets: [{ type: 'player' }],
        effect: [{
          type: 'mill_from_bottom',
          amount: 1,
          if_creature_create_token: {
            cardId: 'token_zombie', name: 'Zombie', kind: 'creature',
            power: 2, toughness: 2, colors: ['B'],
            types: ['Creature'], subtypes: ['Zombie'],
          },
        }],
      }),
    ],
    artId: 420,
    plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 9. Healer of the Glade (M20) {G} 1/2 Elf — ETB gain 3 life.
  defineCard({
    id: 'healer-of-the-glade', name: 'Healer of the Glade', set: 'M20',
    // M259/B5: Oracle „Creature — Elemental" (M20) — dotąd Elf.
    types: ['Creature'], subtypes: ['Elemental'], colors: ['G'],
    power: 1, toughness: 2, manaCost: 1,
    oracleText: 'When this creature enters, you gain 3 life.',
    imageUri: 'https://cards.scryfall.io/large/front/c/b/cbe262f2-e35b-4c85-938d-3e9e9c764c1b.jpg?1783932964',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{ type: 'gain_life', amount: 3, scope: 'controller' }],
      }),
    ],
    artId: 471,
    plan: 'Zendikar',
    support: { status: 'supported', limitations: [] },
  }),

  // 10. Enter the Enigma (MKM) {U} Instant — target creature can't be
  // blocked + draw 1 (re-uses cant_be_blocked i draw_cards).
  defineCard({
    id: 'enter-the-enigma', name: 'Enter the Enigma', set: 'MKM',
    // M259/B2: Oracle to SORCERY ({U}, DSK) — dotąd zamodelowana jako Instant.
    types: ['Sorcery'], colors: ['U'], manaCost: 1,
    oracleText: 'Target creature can\'t be blocked this turn.\nDraw a card.',
    imageUri: 'https://cards.scryfall.io/large/front/c/f/cf5479c7-9e46-4a57-abe7-8cc670de89e4.jpg?1783909497',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'creature' }],
      effects: [
        { type: 'cant_be_blocked' },
        { type: 'draw_cards', amount: 1 },
      ],
    },
    artId: 528,
    plan: 'Duskmourn',
    support: { status: 'supported', limitations: [] },
  }),

  // Token Selesnya Charm (RTR): 2/2 biały Knight z vigilance.
  defineCard({
    id: 'token_knight', name: 'Knight', set: null,
    types: ['Creature', 'Token'], subtypes: ['Knight'], colors: ['W'],
    keywords: ['vigilance'], power: 2, toughness: 2, manaCost: 0,
    imageUri: 'https://cards.scryfall.io/large/front/b/f/bf9acfe1-de7a-48fe-aed3-28a72db6d1c0.jpg?1783940863',  // l12
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Selesnya Charm'] },
  }),
  // M202/K (zgłoszenie właściciela): token Phyrexian Mite renderował się jako
  // syntetyczna zaślepka, bo NIE MIAŁ WPISU w katalogu — a to z wpisu kafel
  // bierze `imageUri` (Scryfall) i tekst reguł. Sam token działał poprawnie:
  // jest tworzony przez efekt `create_token` Crawling Chorus, który niesie
  // jego cechy i `cantBlock` inline (ADR 0002 — reguła w jednym miejscu),
  // więc ten wpis jest WYŁĄCZNIE danymi prezentacji: druk tokena + grafika.
  // Obraz: Scryfall, set „tone” (Phyrexia: All Will Be One Tokens), karta
  // „Phyrexian Mite” 1/1 colorless Artifact Creature — Phyrexian Mite.
  defineCard({
    id: 'token_phyrexian_mite', name: 'Phyrexian Mite', set: null,
    types: ['Artifact', 'Creature', 'Token'], subtypes: ['Phyrexian', 'Mite'], colors: [],
    keywords: ['toxic'], toxic: 1, power: 1, toughness: 1, manaCost: 0,
    oracleText: 'Toxic 1 (Players dealt combat damage by this creature also get a poison counter.)\nThis creature can\'t block.',
    imageUri: 'https://cards.scryfall.io/large/front/9/6/96ec91a9-659a-455f-98e0-cd30b6c6c2a4.jpg?1783918166',  // tone
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Crawling Chorus'] },
  }),
  // M202/K cd. (ta sama przyczyna co Phyrexian Mite): tokeny tworzone przez
  // Mysidian Elder, Chatter of the Squirrel i Call the Mountain Chocobo nie
  // miały wpisów w katalogu, więc ich kafle renderowały syntetyczną zaślepkę
  // zamiast grafiki. Wpisy są WYŁĄCZNIE danymi prezentacji (druk tokena +
  // obraz Scryfall); reguły tokenów zostają inline w efektach `create_token`
  // (ADR 0002 — jedno źródło reguły). Strażnik: test/m202-k-tokeny-wpisy.test.js.
  defineCard({
    id: 'token_wizard', name: 'Wizard', set: null,
    types: ['Creature', 'Token'], subtypes: ['Wizard'], colors: ['B'],
    power: 0, toughness: 1, manaCost: 0,
    oracleText: 'Whenever you cast a noncreature spell, this token deals 1 damage to each opponent.',
    imageUri: 'https://cards.scryfall.io/large/front/1/8/187fe54c-7d0c-4225-9d46-3affbead897d.jpg?1783906133',  // tfin
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Mysidian Elder'] },
  }),
  defineCard({
    id: 'token_squirrel', name: 'Squirrel', set: null,
    types: ['Creature', 'Token'], subtypes: ['Squirrel'], colors: ['G'],
    power: 1, toughness: 1, manaCost: 0,
    imageUri: 'https://cards.scryfall.io/large/front/5/a/5a6ec62e-0e9b-4312-bfe8-cc85d76fd9e0.jpg?1783909765',  // tblb
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Chatter of the Squirrel'] },
  }),
  defineCard({
    id: 'token_bird_chocobo', name: 'Bird', set: null,
    types: ['Creature', 'Token'], subtypes: ['Bird'], colors: ['G'],
    power: 2, toughness: 2, manaCost: 0,
    oracleText: 'Whenever a land you control enters, this token gets +1/+0 until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/1/f/1fbc471d-5948-47fc-b7cc-81cc13a4cd15.jpg?1783906133',  // tfin
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Call the Mountain Chocobo'] },
  }),
  defineCard({
    id: 'unstable-frontier', name: 'Unstable Frontier', set: 'CON',
    types: ['Land'], colors: [],
    oracleText: '{T}: Add {C}.\n{T}: Target land you control becomes the basic land type of your choice until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/d/9/d97e739f-8675-488e-be2b-4e455fbe390b.jpg?1783942460',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        targets: [{ type: 'land_you_control' }],
        effect: { type: 'become_basic_land_type' },
      }),
    ],
    artId: 49,
    plan: 'Alara',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'apprentice-wizard', name: 'Apprentice Wizard', set: '2XM',
    types: ['Creature'], subtypes: ['Human', 'Wizard'], colors: ['U'],
    power: 0, toughness: 1, manaCost: 3,
    oracleText: '{U}, {T}: Add {C}{C}{C}.',
    imageUri: 'https://cards.scryfall.io/large/front/e/1/e13026a8-7e3c-45b2-9838-080f14ae4b29.jpg?1783930205',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true, mana: 1, colors: ['U'] },
        effect: { type: 'add_mana', amount: 3 },
      }),
    ],
    artId: 188,
    plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'delta-bloodflies', name: 'Delta Bloodflies', set: 'TDM',
    types: ['Creature'], subtypes: ['Insect'], colors: ['B'],
    keywords: ['flying'], power: 1, toughness: 2, manaCost: 2,
    oracleText: 'Flying\nWhenever this creature attacks, if you control a creature with a counter on it, each opponent loses 1 life.',
    imageUri: 'https://cards.scryfall.io/large/front/1/1/119bb72d-aed9-47dc-9285-7bc836cc3776.jpg?1783907378',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'attacks', condition: { controlsCreatureWithCounter: true } },
        effect: { type: 'lose_life', amount: 1, scope: 'each_opponent' },
      }),
    ],
    artId: 431,
    plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),
  // Token Fake Your Own Death (OTJ): Treasure — artefakt bez statystyk ze
  // zdolnością „{T}, Sacrifice this token: Add one mana of any color\".
  // Definicja tokena — nie taliowalna (limited), jak token_goblin.
  defineCard({
    id: 'token_treasure', name: 'Treasure', set: null,
    types: ['Artifact', 'Token'], subtypes: ['Treasure'], colors: [],
    manaCost: 0,
    imageUri: 'https://cards.scryfall.io/large/front/7/e/7ec6f053-96f7-4e57-b2eb-4e7699a40a4f.jpg?1783911520',  // totj
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii'] },
  }),
  // Ósmy batch realnych kart (2026-08-02): Phyrexian Rager (DMU), Nefarious
  // Imp (CLB), Gather the Townsfolk (DDQ), Evangel of Synthesis (BRO),
  // Woolly Loxodon (KTK). Dane Oracle w docs/cards/.
  defineCard({
    id: 'phyrexian-rager', name: 'Phyrexian Rager', set: 'DMU',
    types: ['Creature'], subtypes: ['Phyrexian', 'Horror'], colors: ['B'],
    power: 2, toughness: 2, manaCost: 3,
    oracleText: 'When this creature enters, you draw a card and you lose 1 life.',
    imageUri: 'https://cards.scryfall.io/large/front/6/f/6fd574e7-705f-4a65-aad0-68ff6d63bf0f.jpg?1783921329',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [
          { type: 'draw_cards', amount: 1 },
          { type: 'lose_life', amount: 1, scope: 'controller' },
        ],
      }),
    ],
    artId: 75,
    plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'nefarious-imp', name: 'Nefarious Imp', set: 'CLB',
    types: ['Creature'], subtypes: ['Imp'], colors: ['B'],
    keywords: ['flying'], power: 2, toughness: 1, manaCost: 3,
    oracleText: 'Flying\nWhenever one or more permanents you control leave the battlefield, scry 1. (Look at the top card of your library. You may put that card on the bottom.)',
    imageUri: 'https://cards.scryfall.io/large/front/0/d/0dc61b93-b87a-47f4-b5b5-eedb1db48288.jpg?1783922758',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'permanents_you_control_leave_battlefield' },
        effect: { type: 'scry', amount: 1 },
      }),
    ],
    artId: 3,
    plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
    notes: ['„one or more" liczone per komenda: kilka permanentów odchodzących naraz daje jeden trigger (zgodne z CR 603.2)'],
  }),
  defineCard({
    id: 'gather-the-townsfolk', name: 'Gather the Townsfolk', set: 'DDQ',
    types: ['Sorcery'], colors: ['W'], manaCost: 2,
    oracleText: 'Create two 1/1 white Human creature tokens.\nFateful hour — If you have 5 or less life, create five of those tokens instead.',
    imageUri: 'https://cards.scryfall.io/large/front/7/6/76f66ee8-8289-4780-aaec-feabd8ea9e3d.jpg?1783937856',
    spell: {
      timing: 'sorcery',
      targets: [],
      effects: [
        {
          type: 'create_token', cardId: 'token_human', name: 'Human',
          kind: 'creature', power: 1, toughness: 1, colors: ['W'],
          types: ['Creature'], subtypes: ['Human'],
          amount: 2,
          // Fateful hour (CR 702.86 w minimalnym wymiarze): przy życiu ≤ 5
          // powstaje pięć tokenów zamiast dwóch.
          ifLifeAtMost: 5, amountIfCondition: 5,
        },
      ],
    },
    artId: 335,
    plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'evangel-of-synthesis', name: 'Evangel of Synthesis', set: 'BRO',
    types: ['Creature'], subtypes: ['Phyrexian', 'Human', 'Cleric'], colors: ['B', 'U'],
    power: 2, toughness: 3, manaCost: 2,
    oracleText: 'When this creature enters, draw a card, then discard a card.\nAs long as you\'ve drawn two or more cards this turn, this creature gets +1/+0 and has menace.',
    imageUri: 'https://cards.scryfall.io/large/front/e/8/e8b60003-a987-49b0-a0f8-bb825c97da4d.jpg?1783920031',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [
          { type: 'draw_cards', amount: 1 },
          { type: 'discard_cards', amount: 1 },
        ],
      }),
      // Zdolność STATYCZNA (CR 604.3): buff obowiązuje, dopóki warunek jest
      // spełniony — przeliczany przy każdym odczycie statystyk, nie „do końca
      // tury\" (licznik dobrań zeruje się przy zmianie tury).
      createAbility({
        type: ABILITY_TYPE.static,
        condition: { minCardsDrawnThisTurn: 2 },
        pump: { power: 1, toughness: 0 },
        keywords: ['menace'],
      }),
    ],
    artId: 352,
    plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'woolly-loxodon', name: 'Woolly Loxodon', set: 'KTK',
    types: ['Creature'], subtypes: ['Elephant', 'Warrior'], colors: ['G'],
    power: 6, toughness: 7, manaCost: 7, keywords: ['morph'],
    oracleText: 'Morph {5}{G} (You may cast this card face down as a 2/2 creature for {3}. Turn it face up any time for its morph cost.)',
    imageUri: 'https://cards.scryfall.io/large/front/a/8/a890c55a-8746-4233-b75a-19cc760c1e8e.jpg?1783939063',
    // Zwykły morph (CR 702.37) — obrót za koszt morph BEZ licznika +1/+1
    // (megamorph Segmented Krotiq kładzie licznik; to inne pole).
    morph: { cost: 3, morphCost: 6, colors: ['G'] },
    artId: 518,
    plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),
  // Token Gather the Townsfolk (DDQ): 1/1 biały Human.
  // Definicja tokena — nie taliowalna (limited), jak token_goblin.
  defineCard({
    id: 'token_human', name: 'Human', set: null,
    types: ['Creature', 'Token'], subtypes: ['Human'], colors: ['W'],
    power: 1, toughness: 1, manaCost: 0,
    imageUri: 'https://cards.scryfall.io/large/front/1/5/15a620da-5056-4582-8da5-2c955c3f4c0d.jpg?1783937829',  // ddq
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii'] },
  }),
  // Token Food (ELD): artefakt ze zdolnością „{2}, {T}, Sacrifice this
  // artifact: You gain 3 life\". Tworzony przez karty generujące Food.
  defineCard({
    id: 'token_food', name: 'Food', set: null,
    types: ['Artifact', 'Token'], subtypes: ['Food'], colors: [],
    manaCost: 0,
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2, tap: true, sacrificeSelf: true },
        effect: { type: 'gain_life', amount: 3 },
      }),
    ],
    imageUri: 'https://cards.scryfall.io/large/front/b/f/bf36408d-ed85-497f-8e68-d3a922c388a0.jpg?1783932477',  // teld
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii'] },
  }),
  // Dziewiąty batch realnych kart (2026-08-03): Kor Cartographer (CMR),
  // Scorpion Sentinel (FIN), Dunland Crebain (LTR), Dragonbroods' Relic (TDM),
  // Secluded Steppe (DDO). Dane Oracle w docs/cards/.
  defineCard({
    id: 'kor-cartographer', name: 'Kor Cartographer', set: 'CMR',
    types: ['Creature'], subtypes: ['Kor', 'Scout'], colors: ['W'],
    power: 2, toughness: 2, manaCost: 4,
    oracleText: 'When this creature enters, you may search your library for a Plains card, put it onto the battlefield tapped, then shuffle.',
    imageUri: 'https://cards.scryfall.io/large/front/5/8/583ef638-1ea1-4301-bb86-78cb2b5f3aab.jpg?1783928881',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: {
          type: 'search_library_to_battlefield',
          qualifier: { subtypes: ['Plains'] },
          entersTapped: true,
        },
      }),
    ],
    artId: 537,
    plan: 'Zendikar',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'scorpion-sentinel', name: 'Scorpion Sentinel', set: 'FIN',
    types: ['Artifact', 'Creature'], subtypes: ['Robot', 'Scorpion'], colors: ['U'],
    power: 1, toughness: 4, manaCost: 2,
    oracleText: 'As long as you control seven or more lands, this creature gets +3/+0.',
    imageUri: 'https://cards.scryfall.io/large/front/0/8/08ab5220-e5c1-472e-8217-97fd60e1773c.jpg?1783906630',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.static,
        condition: { minLandsControlled: 7 },
        pump: { power: 3, toughness: 0 },
      }),
    ],
    artId: 67,
    plan: 'Final Fantasy',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'dunland-crebain', name: 'Dunland Crebain', set: 'LTR',
    types: ['Creature'], subtypes: ['Bird', 'Horror'], colors: ['B'],
    keywords: ['flying'], power: 1, toughness: 1, manaCost: 3,
    oracleText: 'Flying\nWhen this creature enters, amass Orcs 2.',
    imageUri: 'https://cards.scryfall.io/large/front/6/9/695c05ab-e46e-46c7-bd2e-ef0b2307e449.jpg?1783916311',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: {
          type: 'amass', amount: 2, subtype: 'Orc', name: 'Orc Army',
          cardId: 'token_orc_army', colors: ['B'],
        },
      }),
    ],
    artId: 1,
    plan: 'Śródziemie',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'dragonbroods-relic', name: "Dragonbroods' Relic", set: 'TDM',
    types: ['Artifact'], colors: ['G'], manaCost: 2,
    oracleText: '{T}, Tap an untapped creature you control: Add one mana of any color.\n{3}{W}{U}{B}{R}{G}, Sacrifice this artifact: Create a 4/4 Dragon creature token named Reliquary Dragon that\'s all colors. It has flying, lifelink, and "When this token enters, it deals 3 damage to any target." Activate only as a sorcery.',
    imageUri: 'https://cards.scryfall.io/large/front/3/d/3d634087-77ba-4543-aa7a-8a3774d69cd7.jpg?1783907343',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        // M212/A (ta sama klasa co Holdout Settlement): „Add one mana of any
        // color" bez jawnych kolorów spadało na fallback `src.colors`, czyli
        // kolor KARTY — artefakt zielony dawał wyłącznie {G}.
        cost: { tap: true, tapCreature: true },
        effect: { type: 'add_mana', amount: 1, colors: ['W', 'U', 'B', 'R', 'G'] },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        timing: 'sorcery',
        cost: { mana: 8, sacrificeSelf: true, colors: ['W', 'U', 'B', 'R', 'G'] },
        effect: {
          type: 'create_token', cardId: 'token_reliquary_dragon', name: 'Reliquary Dragon',
          kind: 'creature', power: 4, toughness: 4,
          colors: ['W', 'U', 'B', 'R', 'G'], types: ['Creature'], subtypes: ['Dragon'],
          keywords: ['flying', 'lifelink'], abilities: [BATCH9_RELIQUARY_DRAGON_ETB],
        },
      }),
    ],
    artId: 372,
    plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'secluded-steppe', name: 'Secluded Steppe', set: 'DDO',
    types: ['Land'], colors: [], entersTapped: true,
    oracleText: 'This land enters tapped.\n{T}: Add {W}.\nCycling {W} ({W}, Discard this card: Draw a card.)',
    imageUri: 'https://cards.scryfall.io/large/front/d/d/dd65f598-c8f5-4e53-a011-9742c66a1698.jpg?1783938631',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'cycling',
        cost: { mana: 1, colors: ['W'] },
        cycling: { drawCards: 1 },
        effect: [],
      }),
    ],
    artId: 492,
    plan: 'Śródziemie',
    support: { status: 'supported', limitations: [] },
  }),
  // Tokeny Batch 9 — limited, nie są legalne w talii.
  defineCard({
    id: 'token_orc_army', name: 'Orc Army', set: null,
    types: ['Creature', 'Token'], subtypes: ['Orc', 'Army'], colors: ['B'],
    power: 0, toughness: 0, manaCost: 0,
    imageUri: 'https://cards.scryfall.io/large/front/2/f/2f8b43e8-dd89-452e-b572-8559e19fdea2.jpg?1783916049',  // tltr
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; statystyki rosną przez amass'] },
  }),
  defineCard({
    id: 'token_reliquary_dragon', name: 'Reliquary Dragon', set: null,
    types: ['Creature', 'Token'], subtypes: ['Dragon'], colors: ['W', 'U', 'B', 'R', 'G'],
    keywords: ['flying', 'lifelink'], power: 4, toughness: 4, manaCost: 0,
    abilities: [BATCH9_RELIQUARY_DRAGON_ETB],
    imageUri: 'https://cards.scryfall.io/large/front/4/4/44465924-8cc2-49a4-bc07-8dbae7570af6.jpg?1783906782',  // ttdm
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Dragonbroods\' Relic'] },
  }),
  defineCard({
    id: 'token_elemental', name: 'Elemental', set: null,
    types: ['Creature', 'Token'], subtypes: ['Elemental'], colors: ['G'],
    power: 1, toughness: 1, manaCost: 0,
    imageUri: 'https://cards.scryfall.io/large/front/0/0/008695e6-6d6f-4c16-bf05-377e8cc5f5ff.jpg?1783911524',  // totj
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; P/T ustala efekt Tumbleweed Rising'] },
  }),
  // Dziesiąty batch realnych kart (2026-08-03): Goblin Piker (M11), Angel of
  // the Dawn (M19), Armored Skaab (ISD), Tumbleweed Rising (OTJ), Dawntreader
  // Elk (DKA). Dane Oracle w docs/cards/.
  defineCard({
    id: 'goblin-piker', name: 'Goblin Piker', set: 'M11',
    types: ['Creature'], subtypes: ['Goblin', 'Warrior'], colors: ['R'],
    power: 2, toughness: 1, manaCost: 2, oracleText: '',
    imageUri: 'https://cards.scryfall.io/large/front/8/5/85516547-2c1a-432b-9fc5-8d2c91156c77.jpg?1783941805',
    artId: 232,
    plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
    notes: ['karta bez zdolności — standardowa istota 2/1'],
  }),
  defineCard({
    id: 'angel-of-the-dawn', name: 'Angel of the Dawn', set: 'M19',
    types: ['Creature'], subtypes: ['Angel'], colors: ['W'],
    keywords: ['flying'], power: 3, toughness: 3, manaCost: 5,
    oracleText: 'Flying\nWhen this creature enters, creatures you control get +1/+1 and gain vigilance until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/f/4/f4bae0e4-1143-4dc4-afb1-e6b4201ff101.jpg?1783934610',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: { type: 'buff_creatures_you_control', power: 1, toughness: 1, keywords: ['vigilance'] },
      }),
    ],
    artId: 510,
    plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'armored-skaab', name: 'Armored Skaab', set: 'ISD',
    types: ['Creature'], subtypes: ['Zombie', 'Warrior'], colors: ['U'],
    power: 1, toughness: 4, manaCost: 3,
    oracleText: 'When this creature enters, mill four cards.',
    imageUri: 'https://cards.scryfall.io/large/front/c/e/ce4d00f2-30e6-41d5-b997-c66350fe783c.jpg?1783940980',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: { type: 'mill_cards', amount: 4 },
      }),
    ],
    artId: 216,
    plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
    notes: ['mill nie kończy gry poza draw stepem; pusta biblioteka po prostu mieli mniej kart'],
  }),
  defineCard({
    id: 'tumbleweed-rising', name: 'Tumbleweed Rising', set: 'OTJ',
    types: ['Sorcery'], colors: ['G'], manaCost: 2,
    oracleText: 'Create an X/X green Elemental creature token, where X is the greatest power among creatures you control.\nPlot {2}{G}',
    imageUri: 'https://cards.scryfall.io/large/front/2/7/275d2d2a-ef85-48c9-919d-bc62cdad8a10.jpg?1783911802',
    plot: { cost: 3 },
    spell: {
      timing: 'sorcery', targets: [],
      effects: [{
        type: 'create_token', cardId: 'token_elemental', name: 'Elemental',
        kind: 'creature', power: 'greatest_power_you_control',
        toughness: 'greatest_power_you_control', colors: ['G'],
        types: ['Creature'], subtypes: ['Elemental'], amount: 1,
      }],
    },
    artId: 294,
    plan: 'Thunder Junction',
    support: { status: 'supported', limitations: [] },
    notes: ['Plot działa jako deterministyczna akcja z ręki: zapłać {2}{G}, exile, a w późniejszej fazie main rzuć bez many; X to największa moc własnego stwora'],
  }),
  defineCard({
    id: 'dawntreader-elk', name: 'Dawntreader Elk', set: 'DKA',
    types: ['Creature'], subtypes: ['Elk'], colors: ['G'],
    power: 2, toughness: 2, manaCost: 2,
    oracleText: '{G}, Sacrifice this creature: Search your library for a basic land card, put it onto the battlefield tapped, then shuffle.',
    imageUri: 'https://cards.scryfall.io/large/front/1/2/127c969b-1c9a-4265-af0e-5b9dbe136064.jpg?1783940809',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 1, sacrificeSelf: true, colors: ['G'] },
        effect: { type: 'search_library_to_battlefield', qualifier: { types: ['Basic', 'Land'] }, entersTapped: true },
      }),
    ],
    artId: 481,
    plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
  }),
  // Jedenasty batch realnych kart (2026-08-03): Underdark Explorer (CLB),
  // Angel's Feather (M11), Release the Ants (MOR), Porcelain Legionnaire
  // (NPH), Curate (BRO), Canonized in Blood (LCI). Dane Oracle w docs/cards/.
  defineCard({
    id: 'underdark-explorer', name: 'Underdark Explorer', set: 'CLB',
    types: ['Creature'], subtypes: ['Lizard', 'Warrior'], colors: ['B'],
    keywords: ['menace'], power: 5, toughness: 3, manaCost: 5,
    oracleText: 'Menace (This creature can\'t be blocked except by two or more creatures.)\nWhen this creature enters, you take the initiative.',
    imageUri: 'https://cards.scryfall.io/large/front/a/2/a2bf9736-b5f5-4fd4-8406-9f57fefd86e7.jpg?1783922750',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{ type: 'take_initiative' }],
      }),
    ],
    artId: 44,
    plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'angels-feather', name: 'Angel\'s Feather', set: 'M11',
    types: ['Artifact'], colors: [], manaCost: 2,
    oracleText: 'Whenever a player casts a white spell, you may gain 1 life.',
    imageUri: 'https://cards.scryfall.io/large/front/e/f/ef2caa08-1b25-4ace-9204-068777f82e69.jpg?1783941792',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        // Temat 2: „you may gain 1 life" — decyzja kontrolera (tak/nie,
        // resolve_optional_trigger_choice); wcześniej deterministyczne „tak".
        trigger: { event: 'player_casts_spell', condition: { spellColorsInclude: ['W'] }, mayFire: true },
        effect: [{ type: 'gain_life', amount: 1 }],
      }),
    ],
    artId: 223,
    plan: 'Śródziemie',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'release-the-ants', name: 'Release the Ants', set: 'MOR',
    types: ['Instant'], colors: ['R'], manaCost: 2,
    oracleText: 'Release the Ants deals 1 damage to any target. Clash with an opponent. If you win, return Release the Ants to its owner\'s hand. (Each clashing player reveals the top card of their library, then puts that card on their choice of the top or bottom. A player wins if their card had a greater mana value.)',
    imageUri: 'https://cards.scryfall.io/large/front/1/b/1b6f1afb-2451-4611-ac3e-3513a4651719.jpg?1783942785',
    spell: {
      timing: 'instant',
      targets: [{ type: 'any_target' }],
      effects: [
        { type: 'damage', amount: 1 },
        { type: 'clash', returnToHandOnWin: true },
      ],
    },
    artId: 89,
    plan: 'Lorwyn',
    support: { status: 'supported', limitations: [] },
    notes: ['clash: obaj gracze realnie wybierają wierzch/spód swojej odsłoniętej karty (resolve_clash_choice); pusta biblioteka przegrywa clash', 'wygrany czar wraca do ręki właściciela; remis i przegrana = grób'],
  }),
  defineCard({
    id: 'porcelain-legionnaire', name: 'Porcelain Legionnaire', set: 'NPH',
    types: ['Artifact', 'Creature'], subtypes: ['Phyrexian', 'Soldier'], colors: ['W'],
    keywords: ['first_strike'], power: 3, toughness: 1,
    // M259/B3 (CR 202.3): {2}{W/P} to mana value 3 — manaCost niesie PEŁNĄ
    // wartość (włącznie z symbolami phyrexian), a płatność odejmuje symbole
    // opłacone życiem (patrz resources.js/spells.js/game-state.js).
    manaCost: 3, phyrexianManaCost: 1,
    oracleText: '({W/P} can be paid with either {W} or 2 life.)\nFirst strike',
    imageUri: 'https://cards.scryfall.io/large/front/2/6/2616aa0e-8413-4e63-877c-bffd5263f552.jpg?1783941324',
    artId: 345,
    plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
    notes: ['phyrexian mana: gracz wybiera dla każdego symbolu {W/P} — mana albo 2 życia (warianty komendy cast_permanent, UI grupuje je jak X)', 'first strike: dwa przebiegi obrażeń w combat (najpierw first strike, potem SBA i zwykłe) — bez double strike'],
  }),
  defineCard({
    id: 'curate', name: 'Curate', set: 'BRO',
    types: ['Instant'], colors: ['U'], manaCost: 2,
    oracleText: 'Surveil 2. (Look at the top two cards of your library, then put any number of them into your graveyard and the rest on top of your library in any order.)\nDraw a card.',
    imageUri: 'https://cards.scryfall.io/large/front/f/e/fe8c3fc8-c1cc-4dfc-94cb-1538bff9d09a.jpg?1783920114',
    spell: {
      timing: 'instant',
      targets: [],
      effects: [
        { type: 'surveil', amount: 2 },
        { type: 'draw_cards', amount: 1 },
      ],
    },
    artId: 302,
    plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
    notes: ['surveil jest realną, blokującą decyzją (resolve_surveil — jak scry): gracz wybiera karty do grobu ORAZ kolejność reszty na wierzchu („in any order")', 'dobranie czeka na decyzję surveil (czar wisi na stosie do resolve_surveil)'],
  }),
  defineCard({
    id: 'canonized-in-blood', name: 'Canonized in Blood', set: 'LCI',
    types: ['Enchantment'], colors: ['B'], manaCost: 2,
    oracleText: 'At the beginning of your end step, if you descended this turn, put a +1/+1 counter on target creature you control. (You descended if a permanent card was put into your graveyard from anywhere.)\n{5}{B}{B}, Sacrifice this enchantment: Create a 4/3 white and black Vampire Demon creature token with flying.',
    imageUri: 'https://cards.scryfall.io/large/front/3/8/384b6892-5dfc-4607-b511-cf83544a9357.jpg?1783913782',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: {
          event: 'end_step',
          condition: { descendedThisTurn: true },
          requiresTarget: { type: 'creature_you_control' },
        },
        effect: [{ type: 'add_counter', counter: '+1/+1', amount: 1 }],
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 7, sacrificeSelf: true, colors: ['B', 'B'] },
        effect: [{
          type: 'create_token', cardId: 'token_vampire_demon', name: 'Vampire Demon',
          kind: 'creature', power: 4, toughness: 3, colors: ['W', 'B'],
          types: ['Creature'], subtypes: ['Vampire', 'Demon'], keywords: ['flying'],
        }],
      }),
    ],
    artId: 526,
    plan: 'Ixalan',
    support: { status: 'supported', limitations: [] },
  }),
  // Token Canonized in Blood (LCI): 4/3 czarno-biały Vampire Demon z flying.
  // Definicja tokena — nie taliowalna (limited), jak token_goblin.
  defineCard({
    id: 'token_vampire_demon', name: 'Vampire Demon', set: null,
    types: ['Creature', 'Token'], subtypes: ['Vampire', 'Demon'], colors: ['W', 'B'],
    keywords: ['flying'], power: 4, toughness: 3, manaCost: 0,
    imageUri: 'https://cards.scryfall.io/large/front/3/0/3005eb0a-5c96-4a07-a6b9-a907d1095cdf.jpg?1783913605',  // tlci
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Canonized in Blood'] },
  }),
  // Token lochu Undercity (Catacombs): 4/1 czarny Skeleton z menace.
  // Definicja tokena — nie taliowalna (limited), jak token_goblin.
  defineCard({
    id: 'token_skeleton', name: 'Skeleton', set: null,
    types: ['Creature', 'Token'], subtypes: ['Skeleton'], colors: ['B'],
    keywords: ['menace'], power: 4, toughness: 1, manaCost: 0,
    imageUri: 'https://cards.scryfall.io/large/front/c/f/cf4c245f-af2f-46a7-81f3-670a04940901.jpg?1783922321',  // tclb
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez pokój Catacombs lochu Undercity'] },
  }),
  // Dwunasty batch realnych kart (2026-08-03): Grave Exchange (AVR),
  // Hysterical Blindness (ISD), Barkform Harvester (BLB), Undead Servant
  // (ORI), Rage of Purphoros (THS). Dane Oracle w docs/cards/.
  defineCard({
    id: 'grave-exchange', name: 'Grave Exchange', set: 'AVR',
    types: ['Sorcery'], colors: ['B'], manaCost: 6,
    oracleText: 'Return target creature card from your graveyard to your hand. Target player sacrifices a creature of their choice.',
    imageUri: 'https://cards.scryfall.io/large/front/1/4/14f420c4-801b-48e7-a10b-de44a2417265.jpg?1783940698',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'creature_card_in_graveyard' }, { type: 'player' }],
      effects: [
        { type: 'return_creature_card_to_hand', targetIndex: 0 },
        // Wybór „of their choice\" należy do CELU (blokująca decyzja
        // resolve_sacrifice_choice); boty odpowiadają deterministycznie.
        { type: 'player_sacrifices_creature', targetIndex: 1 },
      ],
    },
    artId: 101,
    plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
    notes: ['gracz bez stworów nie poświęca niczego; wybór poświęcanego stwora jest decyzją CELU (resolve_sacrifice_choice)'],
  }),
  defineCard({
    id: 'hysterical-blindness', name: 'Hysterical Blindness', set: 'ISD',
    types: ['Instant'], colors: ['U'], manaCost: 3,
    oracleText: 'Creatures your opponents control get -4/-0 until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/5/a/5aeaa757-e3b0-4606-a689-e8a20a686c3a.jpg?1783940973',
    spell: {
      timing: 'instant',
      targets: [],
      effects: [{ type: 'buff_opponents_creatures', power: -4, toughness: 0 }],
    },
    artId: 282,
    plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
    notes: ['globalny -4/-0 do końca tury na stworach przeciwnika (ujemna moc nie zabija stwora)'],
  }),
  defineCard({
    id: 'barkform-harvester', name: 'Barkform Harvester', set: 'BLB',
    types: ['Artifact', 'Creature'], subtypes: ['Shapeshifter'], colors: [],
    power: 2, toughness: 3, manaCost: 3, keywords: ['reach', 'changeling'],
    oracleText: 'Changeling (This card is every creature type.)\nReach\n{2}: Put target card from your graveyard on the bottom of your library.',
    imageUri: 'https://cards.scryfall.io/large/front/f/7/f77049a6-0f22-415b-bc89-20bcb32accf6.jpg?1783910787',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2 },
        targets: [{ type: 'card_in_graveyard' }],
        effect: { type: 'put_graveyard_card_on_bottom' },
      }),
    ],
    artId: 233,
    plan: 'Bloomburrow',
    support: { status: 'supported', limitations: [] },
    notes: ['changeling reprezentowany jako keyword (żadna mechanika katalogu nie pyta o typy stwora)'],
  }),
  defineCard({
    id: 'undead-servant', name: 'Undead Servant', set: 'ORI',
    types: ['Creature'], subtypes: ['Zombie'], colors: ['B'],
    power: 3, toughness: 2, manaCost: 4,
    oracleText: 'When this creature enters, create a 2/2 black Zombie creature token for each card named Undead Servant in your graveyard.',
    imageUri: 'https://cards.scryfall.io/large/front/3/6/36afdfd4-8db7-45b6-9b6d-b9293fe6c26d.jpg?1783938335',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{
          type: 'create_token', cardId: 'token_zombie', name: 'Zombie',
          kind: 'creature', power: 2, toughness: 2, colors: ['B'],
          types: ['Creature'], subtypes: ['Zombie'],
          amount: 'cards_named_in_graveyard', countCardId: 'undead-servant',
        }],
      }),
    ],
    artId: 128,
    plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
    notes: ['liczba tokenów = liczba innych kopii Undead Servant w grobie kontrolera (token Zombie nie jest liczony)'],
  }),
  defineCard({
    id: 'rage-of-purphoros', name: 'Rage of Purphoros', set: 'THS',
    types: ['Sorcery'], colors: ['R'], manaCost: 5,
    oracleText: 'Rage of Purphoros deals 4 damage to target creature. It can\'t be regenerated this turn. Scry 1. (Look at the top card of your library. You may put that card on the bottom.)',
    imageUri: 'https://cards.scryfall.io/large/front/1/e/1e249f31-cc67-4d0c-9db5-962d10cf74ca.jpg?1783939756',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'creature' }],
      effects: [
        { type: 'damage', amount: 4 },
        // CR 701.12b: „It can't be regenerated this turn" — flaga trwała
        // do końca tury ustawiana na celu (effects.js). tryRegenerate
        // (SBA) i destroy_permanent (efekty) sprawdzają listę
        // state.cantBeRegeneratedThisTurn, więc tarcza regeneracji
        // (regenerate albo drugi efekt) nie chroni tego stwora.
        { type: 'cant_be_regenerated_this_turn' },
        { type: 'scry', amount: 1 },
      ],
    },
    artId: 401,
    plan: 'Theros',
    support: { status: 'supported', limitations: [] },
    notes: ['scry 1 to blokująca decyzja'],
  }),
  // Token Undead Servant (ORI/M20): 2/2 czarny Zombie. Definicja tokena —
  // nie taliowalna (limited), jak token_goblin.
  defineCard({
    id: 'token_zombie', name: 'Zombie', set: null,
    types: ['Creature', 'Token'], subtypes: ['Zombie'], colors: ['B'],
    power: 2, toughness: 2, manaCost: 0,
    imageUri: 'https://cards.scryfall.io/large/front/7/c/7c60e495-8fb7-43bb-b11d-52882c0246bc.jpg?1783937829',  // ddq
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Undead Servant'] },
  }),
  // Trzynasty batch realnych kart (2026-08-03): Scorned Villager (DKA),
  // Curse of the Pierced Heart (ISD), Emissary Escort (EOE), Snarling Wolf
  // (VOW), Negate (M20). Dane Oracle w docs/cards/.
  defineCard({
    id: 'scorned-villager', name: 'Scorned Villager', set: 'DKA',
    types: ['Creature'], subtypes: ['Human', 'Werewolf'], colors: ['G'],
    power: 1, toughness: 1, manaCost: 2, keywords: ['transform'],
    oracleText: '{T}: Add {G}.\nAt the beginning of each upkeep, if no spells were cast last turn, transform this creature.',
    imageUri: 'https://cards.scryfall.io/large/front/6/f/6f35e364-81d9-4888-993b-acc7a53d963c.jpg?1783940808',
    transformTo: 'moonscarred-werewolf',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        // M193/A: kolor WPROST z Oracle („{T}: Add {G}") — dotad kolor znala
        // wylacznie reczna mapa MANA_SOURCE_MAP, a deskryptor milczal.
        effect: { type: 'add_mana', amount: 1, colors: ['G'] },
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'upkeep', condition: { noSpellsLastTurn: true, eachUpkeep: true } },
        effect: [{ type: 'transform' }],
      }),
    ],
    artId: 443,
    plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
    notes: ['transform tylko przez trigger upkeep (bez ręcznego obrotu)'],
  }),
  // Tylna strona Scorned Villager — Moonscarred Werewolf (DKA). Limited,
  // nie taliowalna (jak krallenhorde-wantons).
  defineCard({
    id: 'moonscarred-werewolf', name: 'Moonscarred Werewolf', set: 'DKA',
    types: ['Creature'], subtypes: ['Werewolf'], colors: ['G'],
    power: 2, toughness: 2, manaCost: 2, keywords: ['transform', 'vigilance'],
    oracleText: 'Vigilance\n{T}: Add {G}{G}.\nAt the beginning of each upkeep, if a player cast two or more spells last turn, transform this creature.',
    imageUri: 'https://cards.scryfall.io/large/back/6/f/6f35e364-81d9-4888-993b-acc7a53d963c.jpg?1783940808',
    transformTo: 'scorned-villager',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        // M193/A: Oracle „{T}: Add {G}{G}" — dwie many ZIELONE (kolor z danych).
        effect: { type: 'add_mana', amount: 2, colors: ['G'] },
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'upkeep', condition: { minSpellsLastTurn: 2, eachUpkeep: true } },
        effect: [{ type: 'transform' }],
      }),
    ],
    artId: 485,
    plan: 'Innistrad',
    support: { status: 'limited', limitations: ['tylna strona transform — nie można umieścić w talii'] },
  }),
  defineCard({
    id: 'curse-of-the-pierced-heart', name: 'Curse of the Pierced Heart', set: 'ISD',
    types: ['Enchantment'], subtypes: ['Aura', 'Curse'], colors: ['R'], manaCost: 2,
    oracleText: 'Enchant player\nAt the beginning of enchanted player\'s upkeep, this Aura deals 1 damage to that player or a planeswalker that player controls.',
    imageUri: 'https://cards.scryfall.io/large/front/7/1/71010182-c004-4d18-adab-80319cd1e625.jpg?1783940940',
    aura: { enchant: 'player' },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'upkeep', condition: { enchantedPlayerUpkeep: true } },
        effect: [{ type: 'damage_enchanted_player', amount: 1 }],
      }),
    ],
    artId: 91,
    plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
    notes: ['„Enchant player": zaczarowany gracz wybierany przy rzucaniu (decyzja gracza); planeswalkery nie istnieją w engine, więc 1 obrażeń zawsze trafia zaczarowanego gracza'],
  }),
  defineCard({
    id: 'emissary-escort', name: 'Emissary Escort', set: 'EOE',
    types: ['Artifact', 'Creature'], subtypes: ['Robot', 'Soldier'], colors: ['U'],
    power: 0, toughness: 4, manaCost: 2,
    oracleText: 'This creature gets +X/+0, where X is the greatest mana value among other artifacts you control.',
    imageUri: 'https://cards.scryfall.io/large/front/b/5/b52ba87f-3ac7-4f32-901c-d089df979f94.jpg?1783905982',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.static,
        pump: { power: 'greatest_mana_among_other_artifacts', toughness: 0 },
      }),
    ],
    artId: 100,
    plan: 'The Edge',
    support: { status: 'supported', limitations: [] },
    notes: ['X = największa mana value wśród INNYCH artefaktów kontrolera (bez samego źródła), przeliczane przy odczycie statystyk (CR 604.3)'],
  }),
  defineCard({
    id: 'snarling-wolf', name: 'Snarling Wolf', set: 'VOW',
    types: ['Creature'], subtypes: ['Wolf'], colors: ['G'],
    power: 1, toughness: 1, manaCost: 1,
    oracleText: '{1}{G}: This creature gets +2/+2 until end of turn. Activate only once each turn.',
    imageUri: 'https://cards.scryfall.io/large/front/e/c/ecd271d7-a3c8-4448-b8e2-bcef5d7e9118.jpg?1783924801',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2, colors: ['G'] },
        effect: { type: 'pump', power: 2, toughness: 2 },
        oncePerTurn: true,
      }),
    ],
    artId: 214,
    plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
    notes: ['„activate only once each turn" przez limit aktywacji zdolności (reset co turę)'],
  }),
  defineCard({
    id: 'negate', name: 'Negate', set: 'M20',
    types: ['Instant'], colors: ['U'], manaCost: 2,
    oracleText: 'Counter target noncreature spell.',
    imageUri: 'https://cards.scryfall.io/large/front/3/3/33b83158-78b4-425e-8379-be3ef038295c.jpg?1783933006',
    spell: {
      timing: 'instant',
      targets: [{ type: 'noncreature_spell_on_stack' }],
      effects: [{ type: 'counter_spell' }],
    },
    artId: 461,
    plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
    notes: ['„noncreature spell" = czar na stosie niebędący stworem (instants/sorceries i czyste aury); cast bestow (stwór) nie jest celem Negate'],
  }),

  // =========================================================================
  // Batch 14 (10 kart, 2026-08-04)
  // =========================================================================

  // 1. Ainok Tracker (KTK) — First strike + Morph {4}{R}
  defineCard({
    id: 'ainok-tracker', name: 'Ainok Tracker', set: 'KTK',
    types: ['Creature'], subtypes: ['Dog', 'Scout'], colors: ['R'],
    power: 3, toughness: 3, manaCost: 6,
    oracleText: 'First strike\nMorph {4}{R} (You may cast this card face down as a 2/2 creature for {3}. Turn it face up any time for its morph cost.)',
    imageUri: 'https://cards.scryfall.io/large/front/0/f/0ff9400d-4842-471f-bf7e-3b21df352e0a.jpg?1783939076',
    keywords: ['first_strike'],
    morph: { cost: 3, morphCost: 5, colors: ['R'] },
    artId: 68,
    plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Spectral Prison (AVR) — Aura: doesn't untap, sac on targeting
  defineCard({
    id: 'spectral-prison', name: 'Spectral Prison', set: 'AVR',
    types: ['Enchantment'], colors: ['U'], manaCost: 2,
    oracleText: "Enchant creature\nEnchanted creature doesn't untap during its controller's untap step.\nWhen enchanted creature becomes the target of a spell, sacrifice this Aura.",
    imageUri: 'https://cards.scryfall.io/large/front/8/9/89d141bc-7307-40c2-a7ed-427caaec5efc.jpg?1783940711',
    aura: { keywords: [] },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: { type: 'lock_untap' },
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'aura_host_targeted_by_spell' },
        effect: { type: 'sacrifice_permanent' },
      }),
    ],
    artId: 181,
    plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
    notes: ['lock_untap: zablokowane do końca tury (jak Entrancing Lyre); sacrifice on targeting przez aura_host_targeted_by_spell trigger'],
  }),

  // 3. Raucous Carnival (DSK) — Conditional entersTapped based on life
  defineCard({
    id: 'raucous-carnival', name: 'Raucous Carnival', set: 'DSK',
    types: ['Land'], colors: [],
    oracleText: "This land enters tapped unless a player has 13 or less life.\n{T}: Add {R} or {W}.",
    imageUri: 'https://cards.scryfall.io/large/front/3/6/3604a211-9bf7-474e-bd78-32a862f4259c.jpg?1783909427',
    entersTapped: true,
    entersTappedCondition: { type: 'player_life_at_most', amount: 13 },
    artId: 48,
    plan: 'Duskmourn',
    support: { status: 'supported', limitations: [] },
  }),

  // 4. Cloudbound Moogle (FIN) — Flying, ETB +1/+1 counter, Plainscycling
  defineCard({
    id: 'cloudbound-moogle', name: 'Cloudbound Moogle', set: 'FIN',
    types: ['Creature'], subtypes: ['Moogle'], colors: ['W'],
    power: 2, toughness: 3, manaCost: 5,
    oracleText: "Flying\nWhen this creature enters, put a +1/+1 counter on target creature.\nPlainscycling {2} ({2}, Discard this card: Search your library for a Plains card, reveal it, put it into your hand, then shuffle.)",
    imageUri: 'https://cards.scryfall.io/large/front/7/3/7387bca7-f496-45da-a0ac-6be049303a8f.jpg?1783906653',
    keywords: ['flying'],
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'creature' } },
        effect: { type: 'add_counter', counter: '+1/+1', amount: 1 },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2 },
        cycling: { subtypes: ['Plains'] },
        effect: {},
      }),
    ],
    artId: 86,
    plan: 'Final Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Insatiable Appetite (ELD) — Instant, may sacrifice Food for +5/+5
  defineCard({
    id: 'insatiable-appetite', name: 'Insatiable Appetite', set: 'ELD',
    types: ['Instant'], colors: ['G'], manaCost: 2,
    oracleText: "You may sacrifice a Food. If you do, target creature gets +5/+5 until end of turn. Otherwise, that creature gets +3/+3 until end of turn.",
    imageUri: 'https://cards.scryfall.io/large/front/2/3/2357f2db-00c2-41f6-bd04-93f905dea461.jpg?1783932609',
    spell: {
      timing: 'instant',
      targets: [{ type: 'creature' }],
      effects: [{ type: 'sacrifice_food_choice' }],
    },
    artId: 386,
    plan: 'Eldraine',
    support: { status: 'supported', limitations: [] },
    notes: ['Food tokens: gracz musi mieć token Food na polu bitwy; jeśli nie ma — automatycznie +3/+3'],
  }),

  // 6. Stirring Bard (CLB) — Defender, initiative, grant menace + haste
  defineCard({
    id: 'stirring-bard', name: 'Stirring Bard', set: 'CLB',
    types: ['Creature'], subtypes: ['Dragon', 'Bard'], colors: ['R'],
    power: 0, toughness: 4, manaCost: 4,
    oracleText: "Defender\nWhen this creature enters, you take the initiative.\nMantle of Inspiration — {T}: Target creature gains menace and haste until end of turn.",
    imageUri: 'https://cards.scryfall.io/large/front/d/0/d06d9d83-d1e6-4499-a1ac-6f865159f6b6.jpg?1783922729',
    keywords: ['defender'],
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: { type: 'take_initiative' },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        effect: { type: 'grant_keywords_until_end_of_turn', keywords: ['menace', 'haste'] },
        targets: [{ type: 'creature' }],
      }),
    ],
    artId: 251,
    plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
  }),

  // 7. Hunter's Blowgun (LCI) — Equipment, conditional deathtouch/reach
  defineCard({
    id: 'hunters-blowgun', name: "Hunter's Blowgun", set: 'LCI',
    // M100/E10 (P10): podtyp wg Oracle (Artifact — Equipment) — dotąd tile
    // pokazywał gołe „Artifact", a typ Equipment jest regułowo istotny.
    types: ['Artifact'], subtypes: ['Equipment'], colors: [], manaCost: 1,
    oracleText: "Equipped creature gets +1/+1.\nEquipped creature has deathtouch during your turn. Otherwise, it has reach.\nEquip {2} ({2}: Attach to target creature you control. Equip only as a sorcery.)",
    imageUri: 'https://cards.scryfall.io/large/front/3/3/3348abe7-6aa3-47f7-8203-a15f75007e33.jpg?1783913724',
    equipment: {
      equip: 2,
      pump: { power: 1, toughness: 1 },
      keywords: [],
      conditionalKeywords: [
        { condition: { activePlayerIsController: true }, keywords: ['deathtouch'] },
        { condition: { activePlayerIsController: false }, keywords: ['reach'] },
      ],
    },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'equip',
        cost: { mana: 2 },
        effect: {},
      }),
    ],
    artId: 267,
    plan: 'Ixalan',
    support: { status: 'supported', limitations: [] },
    notes: ['deathtouch w walce: obrażenia ≥1 od stwora z deathtouch niszczą cel (SBA); warunkowe keywordy wg whose turn'],
  }),

  // 8. Geological Appraiser (LCI) — ETB if cast, discover 3
  defineCard({
    id: 'geological-appraiser', name: 'Geological Appraiser', set: 'LCI',
    types: ['Creature'], subtypes: ['Human', 'Artificer'], colors: ['R'],
    power: 3, toughness: 2, manaCost: 4,
    oracleText: "When this creature enters, if you cast it, discover 3. (Exile cards from the top of your library until you exile a nonland card with mana value 3 or less. Cast it without paying its mana cost or put it into your hand. Put the rest on the bottom in a random order.)",
    imageUri: 'https://cards.scryfall.io/large/front/7/f/7f9c1a82-695b-4df2-8e51-2d71a62e7baf.jpg?1783913759',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', condition: { ifCast: true } },
        effect: { type: 'discover', amount: 3 },
      }),
    ],
    artId: 382,
    plan: 'Ixalan',
    support: { status: 'supported', limitations: [] },
    notes: ['discover: odsłanianie do MV≤3, rzuć bez kosztu albo do ręki, reszta na spód; blokująca decyzja resolve_discover_choice'],
  }),

  // 9. Lodestone Needle // Guidestone Compass (LCI) — DFC Transform
  defineCard({
    id: 'lodestone-needle', name: 'Lodestone Needle', set: 'LCI',
    types: ['Artifact'], colors: ['U'], manaCost: 2,
    oracleText: "Flash\nWhen this artifact enters, tap up to one target artifact or creature and put two stun counters on it.\nCraft with artifact {2}{U} ({2}{U}, Exile this artifact, Exile another artifact you control or an artifact card from your graveyard: Return this card transformed under its owner's control. Craft only as a sorcery.)",
    imageUri: 'https://cards.scryfall.io/large/front/d/e/dedd7a22-92e2-41fd-aa80-944c69653a5e.jpg?1783913799',
    keywords: ['flash'],
    transformTo: 'guidestone-compass',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        // „tap UP TO ONE target artifact or creature" — cel opcjonalny
        // (CR 601.2c); bez `optional` gracz musiał wskazać cel, nawet gdy
        // jedynym kandydatem był jego własny permanent (M105/B5).
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'artifact_or_creature', optional: true } },
        effect: [
          { type: 'tap_permanent' },
          { type: 'add_counter', counter: 'stun', amount: 2 },
        ],
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'craft',
        // M259/B6: „Craft with artifact {2}{U}" — pip {U} obowiązuje (dotąd
        // 3 bezbarwne; CR 118.2/601.2f).
        cost: { mana: 3, colors: ['U'] },
        timing: 'sorcery',
        effect: { type: 'craft_transform' },
      }),
    ],
    artId: 483,
    plan: 'Ixalan',
    support: { status: 'supported', limitations: [] },
  }),
  // Guidestone Compass — back face of Lodestone Needle. Tyły kart
  // dwustronnych NIE są osobnymi pozycjami do talii (poza polem bitwy karta
  // istnieje tylko stroną frontową, CR 711.4) — bug ze stołu 2026-08-05:
  // backside na ręku nie da się rzucić. Jak przy Shiva/tokenach: limited
  // (walidacja talii i kreator odrzucają ten wpis).
  defineCard({
    id: 'guidestone-compass', name: 'Guidestone Compass', set: 'LCI',
    types: ['Artifact'], colors: ['U'],
    oracleText: "{1}, {T}: Target creature you control explores. Activate only as a sorcery.",
    imageUri: 'https://cards.scryfall.io/large/back/d/e/dedd7a22-92e2-41fd-aa80-944c69653a5e.jpg?1783913799',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 1, tap: true },
        timing: 'sorcery',
        effect: { type: 'explore' },
        targets: [{ type: 'creature_you_control' }],
      }),
    ],
    artId: 484,
    plan: 'Ixalan',
    support: { status: 'limited', limitations: ['Tył karty dwustronnej (Lodestone Needle) — nie do talii ani kreatora; do gry trafia wyłącznie przez transform frontu'] },
    notes: ['Explore: reveal top, if land → hand, else +1/+1 counter + choose back/graveyard; blokująca decyzja resolve_explore_choice'],
  }),

  // 10. Panic Spellbomb (SOM) — Artifact, sacrifice for can't block, dies draw
  defineCard({
    id: 'panic-spellbomb', name: 'Panic Spellbomb', set: 'SOM',
    types: ['Artifact'], colors: [], manaCost: 1,
    oracleText: "{T}, Sacrifice this artifact: Target creature can't block this turn.\nWhen this artifact is put into a graveyard from the battlefield, you may pay {R}. If you do, draw a card.",
    imageUri: 'https://cards.scryfall.io/large/front/e/9/e9a29832-8630-498a-9ac3-bc709a6dc95d.jpg?1783941699',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true, sacrificeSelf: true },
        effect: { type: 'cant_block' },
        targets: [{ type: 'creature' }],
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'dies', payMana: 1, payColors: ['R'] },
        effect: { type: 'draw_cards', amount: 1 },
      }),
    ],
    artId: 542,
    plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
    notes: ['can\'t block = tymczasowy znacznik do cleanup; dies trigger z opcjonalną płatnością {R}'],
  }),

  // =========================================================================
  // Batch 15 (10 kart, 2026-08-04) — lista właściciela
  // Howl of the Night Pack, Goblin Picker, Dragon Arch, Trigon of Corruption,
  // Aerith Rescue Mission, Esper Stormblade, Forge Devil, Shatter,
  // Sweet Oblivion, Village Rites. Dane Oracle pobrane ze Scryfall
  // (docs/cards/scryfall-*.json), artId ze słownika kolekcji.
  // =========================================================================

  // 1. Howl of the Night Pack (M10) — Sorcery, token Wolf za każdy Forest
  defineCard({
    id: 'howl-of-the-night-pack', name: 'Howl of the Night Pack', set: 'M10',
    types: ['Sorcery'], colors: ['G'], manaCost: 7,
    oracleText: 'Create a 2/2 green Wolf creature token for each Forest you control.',
    imageUri: 'https://cards.scryfall.io/large/front/a/3/a37ba2c4-dd92-4b23-a830-5dbabc9a972b.jpg?1783942361',
    spell: {
      timing: 'sorcery', targets: [],
      effects: [{
        type: 'create_token', cardId: 'token_wolf', name: 'Wolf',
        kind: 'creature', power: 2, toughness: 2, colors: ['G'],
        types: ['Creature'], subtypes: ['Wolf'],
        // Liczba tokenów = liczba kontrolowanych landów z podtypem Forest
        // („for each Forest you control") — źródło dynamiczne.
        amount: 'lands_with_subtype_you_control', subtype: 'Forest',
      }],
    },
    artId: 37,
    plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Goblin Picker (DMU) — {R},{T},Discard a card: Draw a card
  defineCard({
    id: 'goblin-picker', name: 'Goblin Picker', set: 'DMU',
    types: ['Creature'], subtypes: ['Goblin'], colors: ['R'],
    power: 2, toughness: 2, manaCost: 2,
    oracleText: '{R}, {T}, Discard a card: Draw a card.',
    imageUri: 'https://cards.scryfall.io/large/front/6/d/6d8f1f06-dde5-41f2-923c-67d1d4d13fab.jpg?1783921317',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        // {R} — pip czerwony (CR 202.1); bez `colors` zdolność opłacała
        // dowolna mana (M105/B2).
        cost: { mana: 1, tap: true, colors: ['R'], discardCard: true },
        effect: { type: 'draw_cards', amount: 1 },
      }),
    ],
    artId: 388,
    plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Dragon Arch (APC) — {2},{T}: połóż wielokolorowego stwora z ręki
  defineCard({
    id: 'dragon-arch', name: 'Dragon Arch', set: 'APC',
    types: ['Artifact'], colors: [], manaCost: 5,
    oracleText: '{2}, {T}: You may put a multicolored creature card from your hand onto the battlefield.',
    imageUri: 'https://cards.scryfall.io/large/front/e/e/eec581b8-e509-420c-b142-afaa6dd06cc8.jpg?1783945326',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2, tap: true },
        effect: { type: 'put_multicolored_creature_from_hand' },
      }),
    ],
    artId: 72,
    plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
    notes: ['wybór stwora z ręki jest decyzją GRACZA (resolve_hand_creature); „you may" pozwala nic nie kłaść; wielokolorowy = colors.length >= 2'],
  }),

  // 4. Trigon of Corruption (SOM) — charge counters, -1/-1 na cel
  defineCard({
    id: 'trigon-of-corruption', name: 'Trigon of Corruption', set: 'SOM',
    types: ['Artifact'], colors: [], manaCost: 4,
    oracleText: 'This artifact enters with three charge counters on it.\n{B}{B}, {T}: Put a charge counter on this artifact.\n{2}, {T}, Remove a charge counter from this artifact: Put a -1/-1 counter on target creature.',
    imageUri: 'https://cards.scryfall.io/large/front/2/6/26e215e0-836c-4b37-8f9a-9093a535bff1.jpg?1783941694',
    entersWithCounters: { charge: 3 },
    abilities: [
      // {B}{B}, {T}: doładuj charge counter. Koszt jest DWUKOLOROWY (dwa pipy
      // czarne, CR 202.1) — bez `colors` zdolność opłacało dowolne 2 many
      // (M105/B1).
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2, tap: true, colors: ['B', 'B'] },
        effect: { type: 'add_counter', counter: 'charge', amount: 1 },
      }),
      // {2}, {T}, Remove a charge counter: -1/-1 na docelowym stworze.
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2, tap: true, removeCounter: { name: 'charge', amount: 1 } },
        targets: [{ type: 'creature' }],
        effect: { type: 'add_counter', counter: '-1/-1', amount: 1 },
      }),
    ],
    artId: 218,
    plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Aerith Rescue Mission (FIN) — modal „Choose one"
  defineCard({
    id: 'aerith-rescue-mission', name: 'Aerith Rescue Mission', set: 'FIN',
    types: ['Sorcery'], colors: ['W'], manaCost: 4,
    oracleText: "Choose one —\n• Take the Elevator — Create three 1/1 colorless Hero creature tokens.\n• Take 59 Flights of Stairs — Tap up to three target creatures. Put a stun counter on one of them. (If a permanent with a stun counter would become untapped, remove one from it instead.)",
    imageUri: 'https://cards.scryfall.io/large/front/3/1/3123d16c-e1e6-4659-a7a3-2ec6efc6bf08.jpg?1783906653',
    spell: {
      timing: 'sorcery',
      modes: [
        // Tryb A (Take the Elevator): trzy 1/1 bezbarwne tokeny Hero.
        {
          // Nazwa trybu z Oracle text (M30): widoczna w etykiecie akcji,
          // żeby gracz rozróżnił warianty "Choose one".
          name: 'Winda',
          effects: [{
            type: 'create_token', cardId: 'token_hero', name: 'Hero',
            kind: 'creature', power: 1, toughness: 1, colors: [],
            types: ['Creature'], subtypes: ['Hero'], amount: 3,
          }],
        },
        // Tryb B (Take 59 Flights of Stairs): tap do 3 celowanych stworów
        // + stun counter na jednym z nich (wybór gracza).
        {
          name: 'Schody',
          // „Tap up to three target creatures" — CR 601.2c dopuszcza wybór
          // ZERO celów (M105/B4: min 1 blokowało tryb przy pustym stole).
          variableTargets: { type: 'creature', min: 0, max: 3 },
          stunAmongTargets: true,
          effects: [
            { type: 'tap_permanents', applyTo: 'allChosen' },
            { type: 'add_counter', counter: 'stun', amount: 1, applyTo: 'extra:stunTargetId' },
          ],
        },
      ],
    },
    artId: 275,
    plan: 'Final Fantasy',
    support: { status: 'supported', limitations: [] },
    notes: ['modal „Choose one": gracz wybiera tryb i cele (enumeracja wariantów); stun counters istnieją od Batchu 14'],
  }),

  // 6. Esper Stormblade (ARB) — hybrid {W/B}{U}, statyczny bonus
  defineCard({
    id: 'esper-stormblade', name: 'Esper Stormblade', set: 'ARB',
    types: ['Artifact', 'Creature'], subtypes: ['Vedalken', 'Wizard'],
    colors: ['W', 'B', 'U'], power: 2, toughness: 1, manaCost: 2,
    oracleText: 'As long as you control another multicolored permanent, this creature gets +1/+1 and has flying.',
    imageUri: 'https://cards.scryfall.io/large/front/e/6/e60ac6f0-fdec-4e2c-86c6-02d36c7bbaf5.jpg?1783942412',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.static,
        condition: { controlsAnotherMulticolored: true },
        pump: { power: 1, toughness: 1 },
        keywords: ['flying'],
      }),
    ],
    artId: 191,
    plan: 'Alara',
    support: { status: 'supported', limitations: [] },
    notes: ['wielokolorowy permanent = colors.length >= 2'],
  }),

  // 7. Forge Devil (DKA) — ETB 1 dmg do stwora + 1 dmg do ciebie
  defineCard({
    id: 'forge-devil', name: 'Forge Devil', set: 'DKA',
    types: ['Creature'], subtypes: ['Devil'], colors: ['R'],
    power: 1, toughness: 1, manaCost: 1,
    oracleText: 'When this creature enters, it deals 1 damage to target creature and 1 damage to you.',
    imageUri: 'https://cards.scryfall.io/large/front/6/3/63b565a5-d706-47b4-bfa2-deebcc0e2e60.jpg?1783940817',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'creature' } },
        effect: [
          { type: 'damage', amount: 1 },
          { type: 'damage_to_controller', amount: 1 },
        ],
      }),
    ],
    artId: 393,
    plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Shatter (SOM) — Destroy target artifact
  defineCard({
    id: 'shatter', name: 'Shatter', set: 'SOM',
    types: ['Instant'], colors: ['R'], manaCost: 2,
    oracleText: 'Destroy target artifact.',
    imageUri: 'https://cards.scryfall.io/large/front/0/4/04d70f7e-5ae9-455f-8430-123623920a92.jpg?1783941722',
    spell: {
      timing: 'instant',
      targets: [{ type: 'artifact' }],
      effects: [{ type: 'destroy_permanent' }],
    },
    artId: 507,
    plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  // 9. Sweet Oblivion (THB) — mill 4 celu + Escape z cmentarza
  defineCard({
    id: 'sweet-oblivion', name: 'Sweet Oblivion', set: 'THB',
    types: ['Sorcery'], colors: ['U'], manaCost: 2,
    oracleText: 'Target player mills four cards.\nEscape—{3}{U}, Exile four other cards from your graveyard. (You may cast this card from your graveyard for its escape cost.)',
    imageUri: 'https://cards.scryfall.io/large/front/5/1/51ac77d4-f918-4bbc-b023-8117a8c401ee.jpg?1783931576',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'player' }],
      effects: [{ type: 'mill_cards', amount: 4 }],
      // Escape (CR 702.138): rzuć z grobu za {3}{U} + wygnaj 4 inne karty z grobu.
      escape: { cost: 4, exileCount: 4 },
    },
    artId: 103,
    plan: 'Theros',
    support: { status: 'supported', limitations: [] },
    notes: ['Escape: czar z grobu za koszt escape + wygnanie 4 innych kart z grobu (wybór gracza); po rozstrzygnięciu wraca do grobu i można go uciec ponownie'],
  }),

  // 10. Village Rites (M21) — dodatkowy koszt sacrifice a creature, dobierz 2
  defineCard({
    id: 'village-rites', name: 'Village Rites', set: 'M21',
    types: ['Instant'], colors: ['B'], manaCost: 1,
    oracleText: 'As an additional cost to cast this spell, sacrifice a creature.\nDraw two cards.',
    imageUri: 'https://cards.scryfall.io/large/front/9/c/9c0f60a6-b5c8-4704-8b61-94e8fc463e5d.jpg?1783930699',
    spell: {
      timing: 'instant',
      targets: [],
      additionalCost: { sacrificeCreature: true },
      effects: [{ type: 'draw_cards', amount: 2 }],
    },
    artId: 279,
    plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
    notes: ['dodatkowy koszt „sacrifice a creature": gracz wybiera, którego stwora poświęcić (enumeracja wariantów); bez stwora czar nie jest dostępny'],
  }),

  // =========================================================================
  // Batch 16 (10 kart, 2026-08-04) — lista właściciela
  // Alaborn Trooper, Wedgelight Rammer, Jill Shiva's Dominant // Shiva Warden
  // of Ice, Ethersworn Shieldmage, Fiery Fall, Plague Reaver, Greatsword
  // of Tyr, Ramroller, Marut, Stoic Rebuttal. Dane Oracle pobrane ze Scryfall
  // (docs/cards/scryfall-*.json), artId ze słownika kolekcji.
  // =========================================================================

  // 1. Alaborn Trooper (P02 — Portal Second Age) — vanilla 2/3
  defineCard({
    id: 'alaborn-trooper', name: 'Alaborn Trooper', set: 'P02',
    types: ['Creature'], subtypes: ['Human', 'Soldier'], colors: ['W'],
    power: 2, toughness: 3, manaCost: 3, oracleText: '',
    imageUri: 'https://cards.scryfall.io/large/front/e/1/e1cd30b4-4ed8-467e-808e-b0caf4196d90.jpg?1783946495',
    artId: 185,
    plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
    notes: ['karta bez zdolności — standardowa istota 2/3'],
  }),

  // 2. Wedgelight Rammer (EOE) — Artifact Spacecraft z mechaniką Station
  defineCard({
    id: 'wedgelight-rammer', name: 'Wedgelight Rammer', set: 'EOE',
    types: ['Artifact'], subtypes: ['Spacecraft'], colors: ['W'],
    // Station: obiekt NIE jest stworem, dopóki nie osiągnie progu liczników
    // charge (9+); wydrukowane P/T 3/4 nosimy na obiekcie, a przełączaniem
    // kind steruje counters.js (syncStationKind przy każdej zmianie liczników).
    power: 3, toughness: 4, manaCost: 4,
    station: { threshold: 9, keywords: ['flying', 'first_strike'] },
    oracleText: 'When this Spacecraft enters, create a 2/2 colorless Robot artifact creature token.\nStation (Tap another creature you control: Put charge counters equal to its power on this Spacecraft. Station only as a sorcery. It\'s an artifact creature at 9+.)\n9+ | Flying, first strike',
    imageUri: 'https://cards.scryfall.io/large/front/2/c/2cb0984f-dc8b-4bb3-a4fd-8d6d4ae20198.jpg?1783905986',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{
          type: 'create_token', cardId: 'token_robot', name: 'Robot',
          kind: 'creature', power: 2, toughness: 2, colors: [],
          types: ['Artifact', 'Creature'], subtypes: ['Robot'],
        }],
      }),
      // Station — tap another creature you control: charge counters = jego moc.
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'station',
        cost: { tapOtherCreature: true },
        timing: 'sorcery',
        effect: [{ type: 'station_counters', counter: 'charge' }],
      }),
    ],
    artId: 288,
    plan: 'The Edge',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Jill, Shiva's Dominant // Shiva, Warden of Ice (FIN) — transform DFC;
  // strona tylna to osobna definicja 'shiva-warden-of-ice' (limited, jak
  // krallenhorde-wantons).
  defineCard({
    id: 'jill-shivas-dominant', name: "Jill, Shiva's Dominant", set: 'FIN',
    types: ['Legendary', 'Creature'], subtypes: ['Human', 'Noble', 'Warrior'], colors: ['U'],
    power: 2, toughness: 2, manaCost: 3,
    transformTo: 'shiva-warden-of-ice',
    oracleText: "When Jill enters, return up to one other target nonland permanent to its owner's hand.\n{3}{U}{U}, {T}: Exile Jill, then return it to the battlefield transformed under its owner's control. Activate only as a sorcery.",
    imageUri: 'https://cards.scryfall.io/large/front/1/f/1f163763-4802-4a96-a5bc-f3c381db7b5c.jpg?1783906640',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        // Temat 2: „up to one other target nonland permanent" — cel wybiera
        // kontroler; „up to one" daje opcję odmowy (allowNone).
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'other_nonland_permanent', optional: true } },
        effect: [{ type: 'bounce_permanent' }],
      }),
      // {3}{U}{U}, {T}: exile+return transformed (sorcery-speed). Ta sama
      // mechanika obsługuje powrót stroną przednią z rozdziału III Sagi.
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 5, tap: true, colors: ['U', 'U'] },
        timing: 'sorcery',
        effect: [{ type: 'exile_return_transformed' }],
      }),
    ],
    artId: 525,
    plan: 'Final Fantasy',
    support: { status: 'supported', limitations: [] },
  }),
  // Shiva, Warden of Ice — tylna strona DFC: Legendary Enchantment Creature
  // — Saga Elemental. Rozdziały Sagi odpalają liczniki lore (CR 714): wejście
  // = rozdział I, po kroku dobierania kontrolera = kolejne.
  defineCard({
    id: 'shiva-warden-of-ice', name: 'Shiva, Warden of Ice', set: 'FIN',
    types: ['Legendary', 'Enchantment', 'Creature'], subtypes: ['Saga', 'Elemental'], colors: ['U'],
    power: 4, toughness: 5, manaCost: 3,
    transformTo: 'jill-shivas-dominant',
    saga: {
      // M172/B (uwaga właściciela): tytuły rozdziałów z Oracle — decyzja
      // celu i log nazywają rozdział („Mesmerize"), nie generyczny trigger.
      chapterNames: ['Mesmerize', 'Mesmerize', 'Cold Snap'],
      chapters: [
                // I, II — Mesmerize: "Target creature can't be blocked this turn."
        // Temat 2 dla Sag: cel wybiera KONTROLER Sagi (resolve_trigger_target)
        // — nie dawny deterministyczny "najsilniejszy własny stwór". Domyślna
        // kolejność kandydatów (pole bitwy) oznacza, że boty (pierwsza oferta)
        // zachowują dotychczasowe zachowanie: najsilniejszy własny stwór.
        [{ type: 'cant_be_blocked', requiresTarget: { type: 'creature_you_control' } }],
        [{ type: 'cant_be_blocked', requiresTarget: { type: 'creature_you_control' } }],
        // III — Cold Snap: tap wszystkich landów przeciwników + exile+return
        // stroną przednią (Saga znika przed warunkiem poświęcenia CR 714.4).
        // Efekty bezcelowe — idą od razu na stos, bez requiresTarget.
        [{ type: 'tap_all_lands_opponents_control' }, { type: 'exile_return_transformed' }],
      ],
    },
    oracleText: '(As this Saga enters and after your draw step, add a lore counter.)\nI, II — Mesmerize — Target creature can\'t be blocked this turn.\nIII — Cold Snap — Tap all lands your opponents control. Exile Shiva, then return it to the battlefield (front face up).',
    imageUri: 'https://cards.scryfall.io/large/back/1/f/1f163763-4802-4a96-a5bc-f3c381db7b5c.jpg?1783906640',
    artId: 527,
    plan: 'Final Fantasy',
    support: { status: 'limited', limitations: ['tylna strona transform — nie można umieścić w talii'] },
  }),

  // 4. Ethersworn Shieldmage (ARB) — artifact creature z flash + prewencją
  // obrażeń. Druk ARB (Alara Reborn) potwierdzony przez właściciela
  // 2026-08-05 (wcześniej podany „CON\" ze względu na plan Alara w arkuszu;
  // Scryfall zna wyłącznie ARC i ARB). artId 536 ze słownika kolekcji.
  defineCard({
    id: 'ethersworn-shieldmage', name: 'Ethersworn Shieldmage', set: 'ARB',
    types: ['Artifact', 'Creature'], subtypes: ['Vedalken', 'Wizard'],
    colors: ['U', 'W'], power: 2, toughness: 2, manaCost: 3,
    keywords: ['flash'],
    oracleText: 'Flash\nWhen this creature enters, prevent all damage that would be dealt to artifact creatures this turn.',
    imageUri: 'https://cards.scryfall.io/large/front/c/5/c5340e18-faed-4787-a42c-c12935bb0646.jpg?1783942442',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        // Prewencja do cleanup: wszystkie ARTEFAKTOWE STWORY (obu graczy —
        // tak mówi karta) nie otrzymują obrażeń do końca tury.
        effect: [{ type: 'prevent_damage_this_turn', typesInclude: ['Artifact'], isCreature: true }],
      }),
    ],
    artId: 536,
    plan: 'Alara',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Fiery Fall (MM2) — 5 obrażeń do stwora + Basic landcycling
  defineCard({
    id: 'fiery-fall', name: 'Fiery Fall', set: 'MM2',
    types: ['Instant'], colors: ['R'], manaCost: 6,
    oracleText: 'Fiery Fall deals 5 damage to target creature.\nBasic landcycling {1}{R} ({1}{R}, Discard this card: Search your library for a basic land card, reveal it, put it into your hand, then shuffle.)',
    imageUri: 'https://cards.scryfall.io/large/front/2/2/22014836-8a81-4385-bdb0-b9a080fa57af.jpg?1783938405',
    spell: {
      timing: 'instant',
      targets: [{ type: 'creature' }],
      effects: [{ type: 'damage', amount: 5 }],
    },
    abilities: [
      // Basic landcycling {1}{R}: szuka karty z WSZYSTKIMI typami Basic+Land.
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'cycling',
        cycling: { allTypes: ['Basic', 'Land'] },
        cost: { mana: 2, colors: ['R'] },
        effect: [],
      }),
    ],
    artId: 102,
    plan: 'Alara',
    support: { status: 'supported', limitations: [] },
  }),

  // 6. Plague Reaver (CMR) — 6/5, end-step poświęca inne stwory, ping-pong
  defineCard({
    id: 'plague-reaver', name: 'Plague Reaver', set: 'CMR',
    types: ['Creature'], subtypes: ['Beast'], colors: ['B'],
    power: 6, toughness: 5, manaCost: 3,
    oracleText: 'At the beginning of your end step, sacrifice each other creature you control.\nDiscard two cards, Sacrifice this creature: Choose target opponent. Return this creature to the battlefield under that player\'s control at the beginning of their next upkeep.',
    imageUri: 'https://cards.scryfall.io/large/front/2/3/230b9bc8-29c8-49cb-b4f5-1aceeda8bf45.jpg?1783928829',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'end_step' },
        effect: [{ type: 'sacrifice_each_other_creature' }],
      }),
      // Ping-pong: odrzuć 2 + poświęć → wraca w następnym upkeepu celu-pod
      // jego kontrolą (opóźniony trigger CR 603.7 — patrz triggers.js).
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { discardCards: 2, sacrificeSelf: true },
        targets: [{ type: 'opponent' }],
        effect: [{ type: 'return_to_battlefield_under_control_at_upkeep' }],
      }),
    ],
    artId: 291,
    plan: 'Alara',
    support: { status: 'supported', limitations: [] },
  }),

  // 7. Greatsword of Tyr (CLB) — Equipment z triggerem ataku nosiciela
  defineCard({
    id: 'greatsword-of-tyr', name: 'Greatsword of Tyr', set: 'CLB',
    types: ['Artifact'], subtypes: ['Equipment'], colors: ['W'], manaCost: 2,
    // M257 r3 (uwaga C właściciela): Oracle = „Equip {W}" — pita KOLOROWA,
    // nie generyczna {1}. `colors` w deskryptorze = pipy kosztu (jednostek
    // `equip`), reszta generyczna — to samo kodowanie co koszt czarów/suspend
    // (L57: docs/cards/scryfall-greatsword-of-tyr.json).
    equipment: { equip: 1, colors: ['W'] },
    oracleText: 'Whenever equipped creature attacks, put a +1/+1 counter on it and tap up to one target creature defending player controls.\nEquip {W} ({W}: Attach to target creature you control. Equip only as a sorcery.)',
    imageUri: 'https://cards.scryfall.io/large/front/5/0/50088a60-642b-47ed-a289-ef0b617b688f.jpg?1783922813',
    abilities: [
      // Trigger siedzi na EQUIPMENTU (nie na nosicielu): przy deklaracji ataku
      // nosiciela cel 0 = atakujący, cel 1 = stwór gracza broniącego albo null
      // („up to one\" — obsługa w triggers.js, efekty po targetIndex).
      createAbility({
        type: ABILITY_TYPE.triggered,
        // M212/Z4: cel „up to one target creature defending player controls"
        // jest DANĄ karty (deskryptor), nie wiedzą wbudowaną w silnik.
        trigger: {
          event: 'equipped_creature_attacks',
          requiresTarget: { type: 'creature_defending_player_controls', upTo: true },
        },
        effect: [
          { type: 'add_counter', counter: '+1/+1', amount: 1 },
          { type: 'tap_permanent', targetIndex: 1 },
        ],
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'equip',
        // M257 r3: Oracle „Equip {W}" — pita biała (koszt dla UI/wizarda;
        // autorytatywny koszt płatności = deskryptor equipment.colors).
        cost: { mana: 1, colors: ['W'] },
        effect: [],
      }),
    ],
    artId: 308,
    plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Ramroller (ORI) — Juggernaut: atakuje co turę, +2/+0 za inny artefakt
  defineCard({
    id: 'ramroller', name: 'Ramroller', set: 'ORI',
    types: ['Artifact', 'Creature'], subtypes: ['Juggernaut'], colors: [],
    power: 2, toughness: 3, manaCost: 3,
    oracleText: 'This creature attacks each combat if able.\nThis creature gets +2/+0 as long as you control another artifact.',
    imageUri: 'https://cards.scryfall.io/large/front/0/7/07f7ba4d-26bb-4631-a135-f27d94f376d1.jpg?1783938308',
    abilities: [
      // „Attacks each combat if able\" (CR 508.1c): statyczny wymóg ataku —
      // combat traktuje go jak stały goad (walidacja i opcje deklaracji).
      createAbility({ type: ABILITY_TYPE.static, mustAttack: true }),
      createAbility({
        type: ABILITY_TYPE.static,
        condition: { controlsAnotherArtifact: true },
        pump: { power: 2, toughness: 0 },
      }),
    ],
    artId: 238,
    plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 9. Marut (CLB) — 7/7 trample za 8; ETB liczy manę wydaną ze Skarbów
  defineCard({
    id: 'marut', name: 'Marut', set: 'CLB',
    types: ['Artifact', 'Creature'], subtypes: ['Construct'], colors: [],
    keywords: ['trample'], power: 7, toughness: 7, manaCost: 8,
    oracleText: 'Trample\nWhen this creature enters, if mana from a Treasure was spent to cast it, create a Treasure token for each mana from a Treasure spent to cast it. (It\'s an artifact with "{T}, Sacrifice this token: Add one mana of any color.")',
    imageUri: 'https://cards.scryfall.io/large/front/a/3/a3ce857f-2870-4dc9-a763-9ce710e4b375.jpg?1783922671',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        // Mana ze Skarba wydana na rzut jest wpisana na obiekcie
        // (manaFromTreasureSpent — patrz resources.castPermanent); wejście
        // inną drogą (reanimacja, token) daje 0 tokenów — zgodnie z „if\".
        effect: [{
          type: 'create_token', cardId: 'token_treasure', name: 'Treasure',
          kind: 'artifact', colors: [], types: ['Artifact'], subtypes: ['Treasure'],
          amount: 'mana_from_treasure_spent',
          abilities: [
            createAbility({
              type: ABILITY_TYPE.activated,
              cost: { tap: true, sacrificeSelf: true },
              effect: { type: 'add_mana', amount: 1, fromTreasure: true },
            }),
          ],
        }],
      }),
    ],
    artId: 462,
    plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
    notes: ['„mana from a Treasure" = pula many wytworzonej zdolnościami Skarba oznaczonymi fromTreasure; spendMana zużywa ją deterministycznie jako pierwszą'],
  }),

  // 10. Stoic Rebuttal (SOM) — Metalcraft counterspell „Counter target spell"
  defineCard({
    id: 'stoic-rebuttal', name: 'Stoic Rebuttal', set: 'SOM',
    types: ['Instant'], colors: ['U'], manaCost: 3,
    oracleText: 'Metalcraft — This spell costs {1} less to cast if you control three or more artifacts.\nCounter target spell.',
    imageUri: 'https://cards.scryfall.io/large/front/f/2/f2805239-f30a-4eca-a10b-41673daaa287.jpg?1783941736',
    spell: {
      timing: 'instant',
      // „Counter target spell\" (bez „noncreature\" jak w Negate) — nowy typ
      // celu spell_on_stack: dowolny czar na stosie, także czar-stwór bestow.
      targets: [{ type: 'spell_on_stack' }],
      effects: [{ type: 'counter_spell' }],
      // Metalcraft (CR 702.80): koszt o 1 mniejszy przy >= 3 artefaktach
      // kontrolera (warunek oceniany w chwili rzutu — spells.js).
      costReduction: { amount: 1, condition: { controlsArtifactsAtLeast: 3 } },
    },
    artId: 487,
    plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  // Token Wedgelight Rammer (EOE): 2/2 bezbarwny Robot — artefaktowy stwór.
  // Definicja tokena — nie taliowalna (limited), jak token_wolf.
  defineCard({
    id: 'token_robot', name: 'Robot', set: null,
    types: ['Artifact', 'Creature', 'Token'], subtypes: ['Robot'], colors: [],
    power: 2, toughness: 2, manaCost: 0,
    imageUri: 'https://cards.scryfall.io/large/front/c/4/c46f9a07-005c-44b7-8057-b2f00b274dd6.jpg?1783905782',  // teoe
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Wedgelight Rammer'] },
  }),

  // Token Howl of the Night Pack (M10): 2/2 zielony Wolf.
  // Definicja tokena — nie taliowalna (limited), jak token_goblin.
  defineCard({
    id: 'token_wolf', name: 'Wolf', set: null,
    types: ['Creature', 'Token'], subtypes: ['Wolf'], colors: ['G'],
    power: 2, toughness: 2, manaCost: 0,
    imageUri: 'https://cards.scryfall.io/large/front/0/f/0f63920d-18a0-4267-bb4e-a972ba86067d.jpg?1783942345',  // tm10
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Howl of the Night Pack'] },
  }),
  // Token Aerith Rescue Mission (FIN): 1/1 bezbarwny Hero.
  defineCard({
    id: 'token_hero', name: 'Hero', set: null,
    types: ['Creature', 'Token'], subtypes: ['Hero'], colors: [],
    power: 1, toughness: 1, manaCost: 0,
    imageUri: 'https://cards.scryfall.io/large/front/d/0/d0657ce1-bf75-4007-ac1b-0623eb263357.jpg?1783906138',  // tfin
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Aerith Rescue Mission'] },
  }),

  // =========================================================================
  // Batch 17 (10 kart, 2026-08-05) — lista właściciela. Mechaniki (infect,
  // cleave, indestructible, animacja lądu, any_creature_dies, draw_cards both
  // players) wniósł do engine'u PR #26; ten batch DOKOŃCZA go definicjami
  // kart, testami i dopisaniem do talii. Dane Oracle w docs/cards/scryfall-*.json,
  // artId i plan ze słownika kolekcji (tools/collection-art-ids.csv).
  // =========================================================================

  // 1. Maritime Guard (M11) — vanilla 1/3 Merfolk Soldier.
  defineCard({
    id: 'maritime-guard', name: 'Maritime Guard', set: 'M11',
    types: ['Creature'], subtypes: ['Merfolk', 'Soldier'], colors: ['U'],
    power: 1, toughness: 3, manaCost: 2, oracleText: '',
    imageUri: 'https://cards.scryfall.io/large/front/f/3/f365d82a-88a3-403b-92a6-91c9ccb3421f.jpg?1783941824',
    artId: 222,
    plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
    notes: ['karta bez zdolności — standardowa istota 1/3'],
  }),

  // 2. Carrion Call (SOM) — Instant, dwa 1/1 zielone Phyrexian Insect z infect.
  defineCard({
    id: 'carrion-call', name: 'Carrion Call', set: 'SOM',
    types: ['Instant'], colors: ['G'], manaCost: 4,
    oracleText: 'Create two 1/1 green Phyrexian Insect creature tokens with infect. (They deal damage to creatures in the form of -1/-1 counters and to players in the form of poison counters.)',
    imageUri: 'https://cards.scryfall.io/large/front/b/c/bc3c1a8e-3bdb-42cf-9442-5de7e4670d66.jpg?1783941719',
    spell: {
      timing: 'instant', targets: [],
      effects: [{
        type: 'create_token', cardId: 'token_insect', name: 'Phyrexian Insect',
        kind: 'creature', power: 1, toughness: 1, colors: ['G'],
        types: ['Creature'], subtypes: ['Phyrexian', 'Insect'], keywords: ['infect'],
        amount: 2,
      }],
    },
    artId: 31,
    plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
    notes: ['tokeny z infect: obrażenia do gracza dają znaki trucizny (przegrana przy 10), do stwora — liczniki -1/-1 (CR 702.89)'],
  }),

  // 3. Garruk's Companion (M11) — 3/2 Beast z trample.
  defineCard({
    id: 'garruks-companion', name: "Garruk's Companion", set: 'M11',
    types: ['Creature'], subtypes: ['Beast'], colors: ['G'],
    keywords: ['trample'], power: 3, toughness: 2, manaCost: 2,
    oracleText: "Trample (This creature can deal excess combat damage to the player or planeswalker it's attacking.)",
    imageUri: 'https://cards.scryfall.io/large/front/8/6/863c9a10-d83f-415b-adf2-2d0f870410b2.jpg?1783941798',
    artId: 84,
    plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
  }),

  // 4. Lunar Rejection (VOW) — Instant z Cleave. Zwykły rzut odbija stwora
  // Wolf/Werewolf i dobiera kartę; Cleave {3}{U} odbija dowolnego stwora
  // („wykreślony" fragment [Wolf or Werewolf] znosi ograniczenie podtypu).
  defineCard({
    id: 'lunar-rejection', name: 'Lunar Rejection', set: 'VOW',
    types: ['Instant'], colors: ['U'], manaCost: 2,
    oracleText: "Cleave {3}{U} (You may cast this spell for its cleave cost. If you do, remove the words in square brackets.)\nReturn target [Wolf or Werewolf] creature to its owner's hand.\nDraw a card.",
    imageUri: 'https://cards.scryfall.io/large/front/0/f/0f66511c-355f-4e8a-96fc-3afc7a315231.jpg?1783924891',
    spell: {
      timing: 'instant',
      targets: [{ type: 'creature_with_subtypes', subtypes: ['Wolf', 'Werewolf'] }],
      effects: [
        { type: 'bounce_permanent' },
        { type: 'draw_cards', amount: 1 },
      ],
      // Cleave (CR 701.33): alternatywny koszt, który „wykreśla" ograniczenie
      // podtypu celu — cleave celuje dowolnego stwora (creature), nie tylko
      // Wolf/Werewolf. Efekt i cele pochodzą z deskryptora cleave.
      cleave: {
        manaCost: 4,
        targets: [{ type: 'creature' }],
        effects: [
          { type: 'bounce_permanent' },
          { type: 'draw_cards', amount: 1 },
        ],
      },
    },
    artId: 24,
    plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Selhoff Occultist (ISD) — 2/3, „whenever this creature or another
  // creature dies, target player mills a card" (trigger any_creature_dies).
  defineCard({
    id: 'selhoff-occultist', name: 'Selhoff Occultist', set: 'ISD',
    types: ['Creature'], subtypes: ['Human', 'Rogue'], colors: ['U'],
    power: 2, toughness: 3, manaCost: 3,
    oracleText: 'Whenever this creature or another creature dies, target player mills a card.',
    imageUri: 'https://cards.scryfall.io/large/front/a/e/aeac4885-bd04-42bd-8e10-06c3efbce108.jpg?1783940967',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        // any_creature_dies odpala się przy śmierci dowolnego stwora — też
        // samego źródła (abilitiesOnDeath w triggers.js).
        trigger: { event: 'any_creature_dies', requiresTarget: { type: 'player', prefer: 'opponent' } },
        effect: { type: 'mill_cards', amount: 1 },
      }),
    ],
    artId: 17,
    plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),

  // 6. Reclusive Artificer (ORI) — {2}{U}{R} 2/3 Haste, ETB „you may have it
  // deal damage to target creature equal to the number of artifacts you control".
  defineCard({
    id: 'reclusive-artificer', name: 'Reclusive Artificer', set: 'ORI',
    types: ['Creature'], subtypes: ['Human', 'Artificer'], colors: ['U', 'R'],
    keywords: ['haste'], power: 2, toughness: 3, manaCost: 4,
    oracleText: "Haste (This creature can attack and {T} as soon as it comes under your control.)\nWhen this creature enters, you may have it deal damage to target creature equal to the number of artifacts you control.",
    imageUri: 'https://cards.scryfall.io/large/front/5/2/5299a549-06cf-47e8-b6cd-7e44d9f1efb8.jpg?1783938313',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        // Temat 2: „you may have it deal damage to target creature" — cel
        // wybiera kontroler, a „you may" daje opcję odmowy (allowNone).
        // Obrażenia = liczba artefaktów kontrolera źródła (wartość dynamiczna
        // 'artifacts_you_control').
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'creature', optional: true } },
        effect: { type: 'damage', amount: 'artifacts_you_control' },
      }),
    ],
    artId: 213,
    plan: 'Kaladesh',
    support: { status: 'supported', limitations: [] },
  }),

  // 7. Captain's Call (CMR) — Sorcery, trzy 1/1 białe tokeny Soldier.
  defineCard({
    id: 'captains-call', name: "Captain's Call", set: 'CMR',
    types: ['Sorcery'], colors: ['W'], manaCost: 4,
    oracleText: 'Create three 1/1 white Soldier creature tokens.',
    imageUri: 'https://cards.scryfall.io/large/front/a/c/ac907330-492d-4705-bb8a-1fdb080632e1.jpg?1783928889',
    spell: {
      timing: 'sorcery', targets: [],
      effects: [{
        type: 'create_token', cardId: 'token_soldier', name: 'Soldier',
        kind: 'creature', power: 1, toughness: 1, colors: ['W'],
        types: ['Creature'], subtypes: ['Soldier'],
        amount: 3,
      }],
    },
    artId: 252,
    plan: 'Śródziemie',
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Your Temple Is Under Attack (CLB) — Instant, modal „Choose one":
  //   • Pray for Protection — stwory kontrolera zyskują indestructible do EOT;
  //   • Strike a Deal — kontroler i cel-oponent dobierają po 2 karty.
  defineCard({
    id: 'your-temple-is-under-attack', name: 'Your Temple Is Under Attack', set: 'CLB',
    types: ['Instant'], colors: ['W'], manaCost: 3,
    oracleText: "Choose one —\n• Pray for Protection — Creatures you control gain indestructible until end of turn.\n• Strike a Deal — You and target opponent each draw two cards.",
    imageUri: 'https://cards.scryfall.io/large/front/7/a/7ad8aa76-b643-4bd2-aaeb-036c1d50db54.jpg?1783922798',
    spell: {
      timing: 'instant',
      modes: [
        // Pray for Protection: globalny grant indestructible do końca tury
        // (buff_creatures_you_control z keywords; cleanup zdejmuje grant).
        {
          // Nazwa trybu z Oracle text (CLB): widoczna w etykiecie akcji.
          name: 'Modlitwa o ochronę',
          effects: [{ type: 'buff_creatures_you_control', power: 0, toughness: 0, keywords: ['indestructible'] }],
        },
        // Strike a Deal: kontroler i cel-oponent dobierają po 2 karty
        // (draw_cards_both_players używa targets[0] jako drugiego gracza).
        {
          name: 'Zawrzyj pakt',
          targets: [{ type: 'opponent' }],
          effects: [{ type: 'draw_cards_both_players', amount: 2 }],
        },
      ],
    },
    artId: 440,
    plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
    notes: ['modal „Choose one": gracz wybiera tryb (enumeracja wariantów); indestructible chroni przed śmiertelnymi obrażeniami, deathtouch i efektem destroy, wygasa w cleanup'],
  }),

  // 9. Crested Herdcaller (RIX) — 3/3 Dinosaur z trample, ETB tworzy 3/3
  // zielony token Dinosaur z trample.
  defineCard({
    id: 'crested-herdcaller', name: 'Crested Herdcaller', set: 'RIX',
    types: ['Creature'], subtypes: ['Dinosaur'], colors: ['G'],
    keywords: ['trample'], power: 3, toughness: 3, manaCost: 5,
    oracleText: 'Trample\nWhen this creature enters, create a 3/3 green Dinosaur creature token with trample.',
    imageUri: 'https://cards.scryfall.io/large/front/8/0/80bccca0-6425-4676-a98a-e0721a6beff7.jpg?1783935290',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{
          type: 'create_token', cardId: 'token_dinosaur', name: 'Dinosaur',
          kind: 'creature', power: 3, toughness: 3, colors: ['G'],
          types: ['Creature'], subtypes: ['Dinosaur'], keywords: ['trample'],
        }],
      }),
    ],
    artId: 494,
    plan: 'Ixalan',
    support: { status: 'supported', limitations: [] },
  }),

  // 10. Silvanus's Invoker (CLB) — {8}: untap target land you control, animuje
  // go w 8/8 Elemental z trample i haste do końca tury („It's still a land").
  defineCard({
    id: 'silvanuss-invoker', name: "Silvanus's Invoker", set: 'CLB',
    types: ['Creature'], subtypes: ['Dragon', 'Druid'], colors: ['G'],
    power: 3, toughness: 2, manaCost: 3,
    oracleText: "Conjure Elemental — {8}: Untap target land you control. It becomes an 8/8 Elemental creature with trample and haste until end of turn. It's still a land.",
    imageUri: 'https://cards.scryfall.io/large/front/f/1/f1dd1bb8-013b-4028-becd-e0cb4b84f1ad.jpg?1783922702',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 8 },
        targets: [{ type: 'land_you_control' }],
        effect: [
          { type: 'untap_permanent' },
          // Animacja lądu w istotę z zachowaniem typu Land (retainTypes) —
          // granty trample/haste i animacja znikają w cleanup.
          { type: 'animate_permanent_until_end_of_turn', power: 8, toughness: 8, typesAdd: ['Creature'], subtypesAdd: ['Elemental'], keywordsAdd: ['trample', 'haste'], retainTypes: true },
        ],
      }),
    ],
    artId: 539,
    plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
    notes: ['„It\'s still a land" — animowany land zachowuje typ Land (retainTypes: true); animacja i nadane keywordy (trample, haste) wygasają w cleanup'],
  }),

  // Token Carrion Call (SOM): 1/1 zielony Phyrexian Insect z infect.
  // Definicja tokena — nie taliowalna (limited), jak token_wolf.
  defineCard({
    id: 'token_insect', name: 'Phyrexian Insect', set: null,
    types: ['Creature', 'Token'], subtypes: ['Phyrexian', 'Insect'], colors: ['G'],
    keywords: ['infect'], power: 1, toughness: 1, manaCost: 0,
    imageUri: 'https://cards.scryfall.io/large/front/5/a/5a90e8ab-5a76-4834-9cd6-186af939ea41.jpg?1783918174',  // tonc
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Carrion Call'] },
  }),
  // Token Captain's Call (CMR): 1/1 biały Soldier.
  defineCard({
    id: 'token_soldier', name: 'Soldier', set: null,
    types: ['Creature', 'Token'], subtypes: ['Soldier'], colors: ['W'],
    power: 1, toughness: 1, manaCost: 0,
    imageUri: 'https://cards.scryfall.io/large/front/4/3/430ed737-b918-4485-a623-e781c0beb67b.jpg?1783928591',  // tcmr
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Captain\'s Call'] },
  }),
  // Token Crested Herdcaller (RIX): 3/3 zielony Dinosaur z trample.
  defineCard({
    id: 'token_dinosaur', name: 'Dinosaur', set: null,
    types: ['Creature', 'Token'], subtypes: ['Dinosaur'], colors: ['G'],
    keywords: ['trample'], power: 3, toughness: 3, manaCost: 0,
    imageUri: 'https://cards.scryfall.io/large/front/b/1/b1ade1a5-74bf-41cd-b3b4-3bf33cf6d016.jpg?1783931642',  // tgn2
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Crested Herdcaller'] },
  }),

  // =========================================================================
  // Batch 18 (10 kart, 2026-08-05) — lista właściciela
  // Ainok Artillerist (DTK), Kin-Tree Nurturer (TDM), Gorger Wurm (ARB),
  // Bone Splinters (ALA), Brute Force (MM2), Forever Young (ELD),
  // Trostani Discordant (CLU), Fear of Burning Alive (DSK),
  // Jeskai Windscout (KTK), Hobble (PLS). Dane Oracle pobrane ze Scryfall
  // (docs/cards/scryfall-*.json, 2026-08-05), artId ze słownika kolekcji.
  // =========================================================================

  // 1. Ainok Artillerist (DTK) — 4/1 Dog Archer; reach, dopóki ma licznik +1/+1
  defineCard({
    id: 'ainok-artillerist', name: 'Ainok Artillerist', set: 'DTK',
    types: ['Creature'], subtypes: ['Dog', 'Archer'], colors: ['G'],
    power: 4, toughness: 1, manaCost: 3,
    oracleText: 'This creature has reach as long as it has a +1/+1 counter on it. (It can block creatures with flying.)',
    imageUri: 'https://cards.scryfall.io/large/front/3/a/3a4c8964-06e4-4a24-9a7e-9cac0fb8518e.jpg?1783938582',
    abilities: [
      // Zdolność STATYCZNA (CR 604.3): reach obowiązuje, dopóki źródło ma
      // co najmniej jeden licznik +1/+1 — przeliczanie przy każdym odczycie
      // (warunek generyczny hasCounter, kwalifikacja licznika danymi).
      createAbility({
        type: ABILITY_TYPE.static,
        condition: { hasCounter: '+1/+1' },
        keywords: ['reach'],
      }),
    ],
    artId: 321,
    plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
    notes: ['reach warunkowy licznikiem +1/+1 — znika wraz ze zdjęciem licznika (przeliczanie przy odczycie)'],
  }),

  // 2. Kin-Tree Nurturer (TDM) — 2/1 Human Druid z lifelink, ETB endures 1
  defineCard({
    id: 'kin-tree-nurturer', name: 'Kin-Tree Nurturer', set: 'TDM',
    types: ['Creature'], subtypes: ['Human', 'Druid'], colors: ['B'],
    keywords: ['lifelink'], power: 2, toughness: 1, manaCost: 3,
    // Endure 1 (TDM, CR w tej implementacji): przy wejściu wybór gracza —
    // 1 licznik +1/+1 na źródle ALBO token 1/1 biały Spirit
    // (resolve_endure_choice, cz. 2 batchu).
    endure: 1,
    oracleText: 'Lifelink\nWhen this creature enters, it endures 1. (Put a +1/+1 counter on it or create a 1/1 white Spirit creature token.)',
    imageUri: 'https://cards.scryfall.io/large/front/2/1/2177ef64-28bf-4acf-b1f1-c1408f03c411.jpg?1783907376',
    artId: 502,
    plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
    notes: ['endure: wybór liczniki/token należy do kontrolera (blokująca decyzja); liczniki dostępne tylko, gdy źródło wciąż jest stworem na polu bitwy'],
  }),

  // 3. Gorger Wurm (ARB) — 5/5 Wurm z Devour 1
  defineCard({
    id: 'gorger-wurm', name: 'Gorger Wurm', set: 'ARB',
    types: ['Creature'], subtypes: ['Wurm'], colors: ['G', 'R'],
    power: 5, toughness: 5, manaCost: 5,
    // Devour 1 (CR 702.82): „As this creature enters, you may sacrifice any
    // number of creatures. It enters with that many +1/+1 counters on it."
    // Sekwencyjna decyzja kontrolera (resolve_devour_choice) — każde
    // poświęcenie to counters liczników na źródle; samo źródło jest wyłączone.
    devour: { counters: 1 },
    oracleText: 'Devour 1 (As this creature enters, you may sacrifice any number of creatures. It enters with that many +1/+1 counters on it.)',
    imageUri: 'https://cards.scryfall.io/large/front/0/0/00e5a9be-bfb2-466b-b0fe-3b24694e9f84.jpg?1783942430',
    artId: 342,
    plan: 'Alara',
    support: { status: 'supported', limitations: [] },
    notes: ['devour rozstrzygany po wejściu (po zdarzeniu ETB), nie jako zastępstwo wejścia — żaden kolejny trigger nie może wpaść między wejście a poświęcenia (stan silnika: decyzje blokujące)'],
  }),

  // 4. Bone Splinters (ALA) — sorcery, dodatkowy koszt sacrifice, destroy
  defineCard({
    id: 'bone-splinters', name: 'Bone Splinters', set: 'ALA',
    types: ['Sorcery'], colors: ['B'], manaCost: 1,
    oracleText: 'As an additional cost to cast this spell, sacrifice a creature.\nDestroy target creature.',
    imageUri: 'https://cards.scryfall.io/large/front/d/4/d4a4b3a3-b7ae-4210-8037-098fdf5808d0.jpg?1783942568',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'creature' }],
      additionalCost: { sacrificeCreature: true },
      effects: [{ type: 'destroy_permanent' }],
    },
    artId: 136,
    plan: 'Alara',
    support: { status: 'supported', limitations: [] },
    notes: ['dodatkowy koszt „sacrifice a creature": gracz wybiera, którego stwora poświęcić (enumeracja wariantów); bez stwora czar nie jest dostępny'],
  }),

  // 5. Brute Force (MM2) — instant, cel dostaje +3/+3 do końca tury
  defineCard({
    id: 'brute-force', name: 'Brute Force', set: 'MM2',
    types: ['Instant'], colors: ['R'], manaCost: 1,
    oracleText: 'Target creature gets +3/+3 until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/e/f/efa32b2a-ce3c-441a-88d4-1ee853a7c265.jpg?1783938406',
    spell: {
      timing: 'instant',
      targets: [{ type: 'creature' }],
      effects: [{ type: 'pump', power: 3, toughness: 3 }],
    },
    artId: 39,
    plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 6. Forever Young (ELD) — karty-stwory z grobu na wierzch biblioteki + draw
  defineCard({
    id: 'forever-young', name: 'Forever Young', set: 'ELD',
    types: ['Sorcery'], colors: ['B'], manaCost: 2,
    oracleText: 'Put any number of target creature cards from your graveyard on top of your library.\nDraw a card.',
    imageUri: 'https://cards.scryfall.io/large/front/7/8/7873c1f9-572c-4740-82f8-cf3cbc7318d0.jpg?1783932639',
    spell: {
      timing: 'sorcery',
      // Cele wybierane przy rozstrzyganiu („any number of target creature
      // cards ... from YOUR graveyard" — tylko własny grób rzucającego):
      // sekwencyjna decyzja resolve_graveyard_top_choice, nie cast-time
      // targeting, więc targets jest puste.
      targets: [],
      effects: [
        { type: 'graveyard_creatures_to_library_top_choice' },
        { type: 'draw_cards', amount: 1 },
      ],
    },
    artId: 293,
    plan: 'Eldraine',
    support: { status: 'supported', limitations: [] },
    notes: ['na wierzch biblioteki ląduje każdy wybór po kolei (ostatni najwyżej); bez kart-stworów w grobie pierwszy efekt nic nie robi i „Draw a card." rozstrzyga się normalnie'],
  }),

  // 7. Trostani Discordant (CLU) — legendary 1/4: hymn + ETB 2 tokeny, end step
  defineCard({
    id: 'trostani-discordant', name: 'Trostani Discordant', set: 'CLU',
    types: ['Legendary', 'Creature'], subtypes: ['Dryad'], colors: ['G', 'W'],
    power: 1, toughness: 4, manaCost: 5,
    oracleText: 'Other creatures you control get +1/+1.\nWhen Trostani enters, create two 1/1 white Soldier creature tokens with lifelink.\nAt the beginning of your end step, each player gains control of all creatures they own.',
    imageUri: 'https://cards.scryfall.io/large/front/7/9/79d61bba-4404-4336-8290-51d1576f728d.jpg?1783912513',
    abilities: [
      // Hymn (CR 604): zasięg scope.affects — buffuje INNE stwory kontrolera
      // (nie samą Trostani). Przeliczane przy każdym odczycie statystyk.
      createAbility({
        type: ABILITY_TYPE.static,
        scope: { affects: 'other_creatures_you_control' },
        pump: { power: 1, toughness: 1 },
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{
          type: 'create_token', cardId: 'token_soldier_lifelink', name: 'Soldier',
          kind: 'creature', amount: 2, power: 1, toughness: 1, colors: ['W'],
          types: ['Creature'], subtypes: ['Soldier'], keywords: ['lifelink'],
        }],
      }),
      // „At the beginning of your end step, each player gains control of all
      // creatures they own." (CR 108.3 — pole ownerId na obiekcie).
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'end_step' },
        effect: [{ type: 'control_to_owners_all_creatures' }],
      }),
    ],
    artId: 331,
    plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
    notes: ['hymn obejmuje tokeny i stwory dowolnych źródeł pod kontrolą gracza; zmiana kontroli w kroku końcowym nakłada chorobę atakową (CR 302.6)'],
  }),

  // 8. Fear of Burning Alive (DSK) — Enchantment Creature 4/4, ETB 4 dmg,
  //    delirium przy niecombatowych obrażeniach w przeciwnika
  defineCard({
    id: 'fear-of-burning-alive', name: 'Fear of Burning Alive', set: 'DSK',
    types: ['Enchantment', 'Creature'], subtypes: ['Nightmare'], colors: ['R'],
    power: 4, toughness: 4, manaCost: 6,
    oracleText: 'When this creature enters, it deals 4 damage to each opponent.\nDelirium — Whenever a source you control deals noncombat damage to an opponent, if there are four or more card types among cards in your graveyard, this creature deals that amount of damage to target creature that player controls.',
    imageUri: 'https://cards.scryfall.io/large/front/b/2/b282f8e3-8b79-47e9-8c18-62284211442b.jpg?1783909470',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{ type: 'damage_each_opponent', amount: 4 }],
      }),
      // Delirium (CR 702.34, intervening if CR 603.4): warunek 4+ typów kart
      // w grobie kontrolera sprawdzany przy odpaleniu i przy rozstrzyganiu.
      // Cel (stwór poszkodowanego gracza) wybiera kontroler triggera
      // (resolve_delirium_target); obrażenia w wysokości zdarzenia.
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'noncombat_damage_to_opponent', condition: { delirium: true } },
        effect: [],
      }),
    ],
    artId: 419,
    plan: 'Duskmourn',
    support: { status: 'supported', limitations: [] },
    notes: ['trigger bez legalnego celu nie trafia na stos (nie kolejkuje decyzji); źródło obrażeń może już być w grobie — kontroler czytany z ostatniej znanej informacji (CR 603.10)'],
  }),

  // 9. Jeskai Windscout (KTK) — 2/1 Bird Scout z flying i prowess
  defineCard({
    id: 'jeskai-windscout', name: 'Jeskai Windscout', set: 'KTK',
    types: ['Creature'], subtypes: ['Bird', 'Scout'], colors: ['U'],
    keywords: ['flying'], power: 2, toughness: 1, manaCost: 3,
    oracleText: 'Flying\nProwess (Whenever you cast a noncreature spell, this creature gets +1/+1 until end of turn.)',
    imageUri: 'https://cards.scryfall.io/large/front/6/6/66356e38-38e1-4b09-80c2-be26007ff99c.jpg?1783939088',
    abilities: [
      // Prowess (CR 702.108 — generyczny trigger „you cast a noncreature
      // spell"): instant/sorcery, czar aury (także karta-stwór rzucona za
      // bestow — jest wtedy czarem aury, CR 702.103a) albo permanent
      // nie-będący stworem. Land drop nie jest rzutem.
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'you_cast_noncreature_spell' },
        effect: { type: 'pump', power: 1, toughness: 1 },
      }),
    ],
    artId: 477,
    plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),

  // 10. Hobble (PLS) — aura: gospodarz nie atakuje, nie blokuje gdy czarny
  defineCard({
    id: 'hobble', name: 'Hobble', set: 'PLS',
    types: ['Enchantment'], subtypes: ['Aura'], colors: ['W'], manaCost: 3,
    // Czysta aura (CR 303.4, jak Serra's Embrace): „enchant creature" — czar
    // aury z celem. Ograniczenia gospodarza egzekwuje combat
    // (permanents.attachmentRestrictions): `cantBlock` warunkowe kolorami
    // gospodarza („can't block if it's black").
    aura: { cantAttack: true, cantBlock: { hostHasColor: 'B' } },
    oracleText: "Enchant creature\nWhen this Aura enters, draw a card.\nEnchanted creature can't attack.\nEnchanted creature can't block if it's black.",
    imageUri: 'https://cards.scryfall.io/large/front/5/4/54c76a22-f9e3-408b-a5bd-403add57e31a.jpg?1783945630',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{ type: 'draw_cards', amount: 1 }],
      }),
    ],
    artId: 522,
    plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
    notes: ['ograniczenia liczone przy odczycie — odłączenie aury znosi je natychmiast; „can\'t block if it\'s black" ocenia bieżące kolory gospodarza'],
  }),

  // Token Kin-Tree Nurturer (TDM) — endure: N/N biały Spirit (N=1).
  defineCard({
    id: 'token_spirit', name: 'Spirit', set: null,
    types: ['Creature', 'Token'], subtypes: ['Spirit'], colors: ['W'],
    power: 1, toughness: 1, manaCost: 0,
    imageUri: 'https://cards.scryfall.io/large/front/f/2/f22410b3-5c0b-4282-9b0b-5ba61229b6e7.jpg?1783906786',  // ttdm
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez endure (Kin-Tree Nurturer)'] },
  }),
  // Token Trostani Discordant (CLU): 1/1 biały Soldier z lifelink.
  defineCard({
    id: 'token_soldier_lifelink', name: 'Soldier', set: null,
    types: ['Creature', 'Token'], subtypes: ['Soldier'], colors: ['W'],
    keywords: ['lifelink'], power: 1, toughness: 1, manaCost: 0,
    imageUri: 'https://cards.scryfall.io/large/front/1/7/1774c68a-3d76-4fe1-b741-e6acf6b9214c.jpg?1783916674',  // tmom
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Trostani Discordant'] },
  }),

  // ------------------------- Batch 19 (2026-08-06, lista właściciela) -----

  // 1. Illvoi Operative (EOE) — trigger „your second spell each turn"
  defineCard({
    id: 'illvoi-operative', name: 'Illvoi Operative', set: 'EOE',
    types: ['Creature'], subtypes: ['Jellyfish', 'Rogue'], colors: ['U'],
    power: 2, toughness: 1, manaCost: 2,
    oracleText: 'Whenever you cast your second spell each turn, put a +1/+1 counter on this creature.',
    imageUri: 'https://cards.scryfall.io/large/front/d/0/d0ae9fc7-1802-4806-9996-1f1f458ff6a7.jpg?1783905980',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'you_cast_second_spell_each_turn' },
        effect: { type: 'add_counter', counter: '+1/+1', amount: 1 },
      }),
    ],
    artId: 53,
    plan: 'The Edge',
    support: { status: 'supported', limitations: [] },
    notes: ['rzut aury liczy się do „second spell" (zdarzenie aura_spell_cast), jak w MtG'],
  }),

  // 2. Grounded (AVR) — czysta aura: gospodarz traci flying
  defineCard({
    id: 'grounded', name: 'Grounded', set: 'AVR',
    types: ['Enchantment'], subtypes: ['Aura'], colors: ['G'], manaCost: 2,
    aura: { losesKeywords: ['flying'] },
    oracleText: "Enchant creature\nEnchanted creature loses flying.",
    imageUri: 'https://cards.scryfall.io/large/front/d/c/dc4982f0-0ede-4846-82c8-bcf7ad63d099.jpg?1783940666',
    artId: 62,
    plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
    notes: ['odbiór liczony w warstwie ostatniej effectiveKeywords (po grantach) — wygrywa np. z buffem „gains flying" z innej aury'],
  }),

  // 3. Ruinous Rampage (EOE) — sorcery modalny „Choose one"
  defineCard({
    id: 'ruinous-rampage', name: 'Ruinous Rampage', set: 'EOE',
    types: ['Sorcery'], colors: ['R'], manaCost: 3,
    oracleText: "Choose one —\n• Ruinous Rampage deals 3 damage to each opponent.\n• Exile all artifacts with mana value 3 or less.",
    imageUri: 'https://cards.scryfall.io/large/front/9/1/91d7a4c2-1a4b-4e9f-b543-225b6906752f.jpg?1783905947',
    spell: {
      timing: 'sorcery',
      modes: [
        // 3 obrażenia każdemu przeciwnikowi (jak ETB Fear of Burning Alive).
        // Oracle: pierwszy tryb nie ma własnej nazwy ("• Ruinous Rampage deals…"),
        // więc używamy nazwy karty jako nazwy trybu ("Ruinous Rampage").
        {
          name: '3 obrażenia dla każdego przeciwnika',
          effects: [{ type: 'damage_each_opponent', amount: 3 }],
        },
        // Bezcelowe wygnanie wszystkich artefaktów o MV ≤ 3.
        // Oracle: "• Exile all artifacts with mana value 3 or less" — brak
        // własnej nazwy, więc skrócona "Exile Artifacts".
        {
          name: 'Wygnaj artefakty',
          effects: [{ type: 'exile_all', filter: { types: ['Artifact'], manaValueAtMost: 3 } }],
        },
      ],
    },
    artId: 475,
    plan: 'The Edge',
    support: { status: 'supported', limitations: [] },
  }),

  // 4. Tellah, Great Sage (FIN) — progi wydanej many na triggerze noncreature
  defineCard({
    id: 'tellah-great-sage', name: 'Tellah, Great Sage', set: 'FIN',
    types: ['Legendary', 'Creature'], subtypes: ['Human', 'Wizard'], colors: ['U', 'R'],
    power: 3, toughness: 3, manaCost: 5,
    oracleText: 'Whenever you cast a noncreature spell, create a 1/1 colorless Hero creature token. If four or more mana was spent to cast that spell, draw two cards. If eight or more mana was spent to cast that spell, sacrifice Tellah and it deals that much damage to each opponent.',
    imageUri: 'https://cards.scryfall.io/large/front/a/6/a67793ef-ef80-4434-9c54-e3fd8a270bbe.jpg?1783906561',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'you_cast_noncreature_spell' },
        effect: [
          { type: 'create_token', cardId: 'token_hero', name: 'Hero', kind: 'creature', power: 1, toughness: 1, colors: [], types: ['Creature'], subtypes: ['Hero'], amount: 1 },
          { type: 'draw_cards', amount: 2, condition: { manaSpentAtLeast: 4 } },
          { type: 'sacrifice_permanent', condition: { manaSpentAtLeast: 8 } },
          { type: 'damage_each_opponent', amountFrom: 'manaSpent', condition: { manaSpentAtLeast: 8 } },
        ],
      }),
    ],
    artId: 15,
    plan: 'Final Fantasy',
    support: { status: 'supported', limitations: [] },
    notes: ['wydana mana = efektywny koszt many rzutu (bez części opłaconej życiem; koszty dodatkowe nie zwiększają licznika)'],
  }),

  // 5. Etherium Sculptor (ALA) — statyczna obniżka kosztu artefaktów o {1}
  defineCard({
    id: 'etherium-sculptor', name: 'Etherium Sculptor', set: 'ALA',
    types: ['Artifact', 'Creature'], subtypes: ['Vedalken', 'Artificer'], colors: ['U'],
    power: 1, toughness: 2, manaCost: 2,
    oracleText: 'Artifact spells you cast cost {1} less to cast.',
    imageUri: 'https://cards.scryfall.io/large/front/0/d/0d050f2d-bd65-4ab9-9ea6-9deba91b2792.jpg?1783942575',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.static,
        costModifier: { spellTypes: ['Artifact'], amount: 1 },
      }),
    ],
    artId: 285,
    plan: 'Alara',
    support: { status: 'supported', limitations: [] },
  }),

  // 6. Boros Challenger (GRN) — mentor + aktywowany pump
  defineCard({
    id: 'boros-challenger', name: 'Boros Challenger', set: 'GRN',
    types: ['Creature'], subtypes: ['Human', 'Soldier'], colors: ['R', 'W'],
    power: 2, toughness: 3, manaCost: 2,
    oracleText: 'Mentor (Whenever this creature attacks, put a +1/+1 counter on target attacking creature with lesser power.)\n{2}{R}{W}: This creature gets +1/+1 until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/5/4/545f3a30-7984-4046-8a14-51bc9cbc3fe0.jpg?1783934141',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'mentor_attacks' },
        effect: [],
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 4, colors: ['R', 'W'] },
        effect: { type: 'pump', power: 1, toughness: 1 },
      }),
    ],
    artId: 140,
    plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
  }),

  // 7. Pilgrim's Eye (GNT) — ETB: szukaj basic landa do ręki (reveal+shuffle)
  defineCard({
    id: 'pilgrims-eye', name: "Pilgrim's Eye", set: 'GNT',
    types: ['Artifact', 'Creature'], subtypes: ['Thopter'], colors: [],
    keywords: ['flying'], power: 1, toughness: 1, manaCost: 3,
    oracleText: "Flying\nWhen this creature enters, you may search your library for a basic land card, reveal it, put it into your hand, then shuffle.",
    imageUri: 'https://cards.scryfall.io/large/front/3/b/3bef04f5-4498-40c7-bfc2-0e2e619fcca1.jpg?1783933968',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{ type: 'search_library_to_hand', qualifier: { types: ['Basic', 'Land'] } }],
      }),
    ],
    artId: 132,
    plan: 'Zendikar',
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Dementia Bat (NPH) — {4}{B}, poświęć: cel-gracz odrzuca 2 karty
  defineCard({
    id: 'dementia-bat', name: 'Dementia Bat', set: 'NPH',
    types: ['Creature'], subtypes: ['Phyrexian', 'Bat'], colors: ['B'],
    keywords: ['flying'], power: 2, toughness: 2, manaCost: 5,
    oracleText: 'Flying\n{4}{B}, Sacrifice this creature: Target player discards two cards.',
    imageUri: 'https://cards.scryfall.io/large/front/7/2/72ae22c3-2dea-463e-894a-188657849909.jpg?1783941315',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 5, sacrificeSelf: true, colors: ['B'] },
        // M201 (znalezisko #4, CR 115.4): Oracle mówi „target PLAYER” —
        // kontroler też jest legalnym celem (bywa sensowny: madness, efekty
        // z grobu). Deskryptor `opponent` cicho zmieniał legalność celów;
        // `prefer: 'opponent'` zostawia botom dotychczasowy wybór.
        targets: [{ type: 'player', prefer: 'opponent' }],
        effect: [{ type: 'discard_cards', amount: 2, applyTo: 'target' }],
      }),
    ],
    artId: 403,
    plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  // 9. Seer's Lantern (OGW) — artefakt many {C} + aktywowane scry 1
  defineCard({
    id: 'seers-lantern', name: "Seer's Lantern", set: 'OGW',
    types: ['Artifact'], colors: [], manaCost: 3,
    oracleText: '{T}: Add {C}.\n{2}, {T}: Scry 1. (Look at the top card of your library. You may put that card on the bottom.)',
    imageUri: 'https://cards.scryfall.io/large/front/6/6/6618a854-7d9c-4e57-b959-4c0259cb4d97.jpg?1783937894',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        effect: { type: 'add_mana', amount: 1 },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2, tap: true },
        effect: { type: 'scry', amount: 1 },
      }),
    ],
    artId: 489,
    plan: 'Śródziemie',
    support: { status: 'supported', limitations: [] },
    notes: ['produkcja {C} = 1 bezbarwna many (pula engine jest bezbarwna); zdolność many w MANA_SOURCE_MAP jak inne artefakty many'],
  }),

  // 10. You're Confronted by Robbers (CLB) — instant modalny „Choose one"
  defineCard({
    id: 'youre-confronted-by-robbers', name: "You're Confronted by Robbers", set: 'CLB',
    types: ['Instant'], colors: ['W'], manaCost: 4,
    oracleText: "Choose one —\n• Stall for Time — Tap up to three target creatures.\n• Call for Aid — Create three 1/1 white Soldier creature tokens.",
    imageUri: 'https://cards.scryfall.io/large/front/f/7/f76e5d23-a45f-4100-8638-fce33f290fc6.jpg?1783922797',
    spell: {
      timing: 'instant',
      modes: [
        // Stall for Time: tap do 3 celowanych stworów (jak Aerith tryb B bez stun).
        {
          // Nazwa trybu z Oracle text (CLB): widoczna w etykiecie akcji.
          name: 'Zyskiwanie czasu',
          variableTargets: { type: 'creature', min: 0, max: 3 },
          effects: [{ type: 'tap_permanents', applyTo: 'allChosen' }],
        },
        // Call for Aid: trzy 1/1 białe tokeny Soldier.
        {
          name: 'Wezwanie pomocy',
          effects: [{
            type: 'create_token', cardId: 'token_soldier', name: 'Soldier',
            kind: 'creature', power: 1, toughness: 1, colors: ['W'],
            types: ['Creature'], subtypes: ['Soldier'], amount: 3,
          }],
        },
      ],
    },
    artId: 532,
    plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),


  // ===================== Batch 20 (10 kart, 2026-08-06) ======================

  // 1. Rustwing Falcon (M19) — vanilla 1/2 Bird z flying.
  defineCard({
    id: 'rustwing-falcon', name: 'Rustwing Falcon', set: 'M19',
    types: ['Creature'], subtypes: ['Bird'], colors: ['W'],
    power: 1, toughness: 2, manaCost: 1, keywords: ['flying'],
    oracleText: 'Flying',
    imageUri: 'https://cards.scryfall.io/large/front/c/6/c6691e62-8887-41e8-8e74-76ee2353d45e.jpg?1783934596',
    artId: 503, plan: 'Śródziemie',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Monastery Flock (KTK) — 0/5 Bird, defender + flying, Morph {U}.
  defineCard({
    id: 'monastery-flock', name: 'Monastery Flock', set: 'KTK',
    types: ['Creature'], subtypes: ['Bird'], colors: ['U'],
    // {2}{U} — mana value 3 (M105/B3: było 2, czyli stwór o manę tańszy).
    power: 0, toughness: 5, manaCost: 3, keywords: ['defender', 'flying'],
    morph: { cost: 3, morphCost: 1, colors: ['U'] },
    oracleText: 'Defender, flying\nMorph {U} (You may cast this card face down as a 2/2 creature for {3}. Turn it face up any time for its morph cost.)',
    imageUri: 'https://cards.scryfall.io/large/front/e/5/e53c0e50-4b0b-43d8-80c0-2c216722c87a.jpg?1783939087',
    artId: 467, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Death-Hood Cobra (2XM) — {1}{G}: reach EOT; {1}{G}: deathtouch EOT (self).
  defineCard({
    id: 'death-hood-cobra', name: 'Death-Hood Cobra', set: '2XM',
    types: ['Creature'], subtypes: ['Phyrexian', 'Snake'], colors: ['G'],
    power: 2, toughness: 2, manaCost: 2,
    oracleText: '{1}{G}: This creature gains reach until end of turn.\n{1}{G}: This creature gains deathtouch until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/d/e/def88ab5-1b82-46f5-a136-ee1addff4214.jpg?1783930149',
    artId: 533, plan: 'Mirrodin',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2, colors: ['G'] },
        effect: { type: 'grant_keywords_until_end_of_turn', keywords: ['reach'] },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2, colors: ['G'] },
        effect: { type: 'grant_keywords_until_end_of_turn', keywords: ['deathtouch'] },
      }),
    ],
    support: { status: 'supported', limitations: [] },
  }),

  // 4. Coralhelm Guide (BFZ) — {4}{U}: target creature can't be blocked this turn
  defineCard({
    id: 'coralhelm-guide', name: 'Coralhelm Guide', set: 'BFZ',
    types: ['Creature'], subtypes: ['Merfolk', 'Scout', 'Ally'], colors: ['U'],
    power: 2, toughness: 1, manaCost: 2,
    oracleText: '{4}{U}: Target creature can\'t be blocked this turn.',
    imageUri: 'https://cards.scryfall.io/large/front/3/3/33787a5b-d1d1-4d60-ba09-d9c98025e9b3.jpg?1783938210',
    artId: 2, plan: 'Zendikar',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 5, colors: ['U'] },
        targets: [{ type: 'creature' }],
        effect: { type: 'cant_be_blocked' },
      }),
    ],
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Gorehorn Minotaurs (MM2) — Bloodthirst 2
  defineCard({
    id: 'gorehorn-minotaurs', name: 'Gorehorn Minotaurs', set: 'MM2',
    types: ['Creature'], subtypes: ['Minotaur', 'Warrior'], colors: ['R'],
    power: 3, toughness: 3, manaCost: 4,
    bloodthirst: 2,
    oracleText: 'Bloodthirst 2 (If an opponent was dealt damage this turn, this creature enters with two +1/+1 counters on it.)',
    imageUri: 'https://cards.scryfall.io/large/front/c/d/cda652b4-3ae5-4a5b-be82-c0e47a886907.jpg?1783938405',
    artId: 83, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 6. Caravan Vigil (ISD) — search basic land; Morbid → battlefield instead
  defineCard({
    id: 'caravan-vigil', name: 'Caravan Vigil', set: 'ISD',
    types: ['Sorcery'], colors: ['G'], manaCost: 1,
    oracleText: 'Search your library for a basic land card, reveal it, put it into your hand, then shuffle.\nMorbid — You may put that card onto the battlefield instead of putting it into your hand if a creature died this turn.',
    imageUri: 'https://cards.scryfall.io/large/front/9/a/9a8dfb98-a975-41bf-8aac-c0001c9ddaa7.jpg?1783940922',
    artId: 381, plan: 'Innistrad',
    spell: {
      timing: 'sorcery', targets: [],
      effects: [{ type: 'search_basic_land_morbid' }],
    },
    support: { status: 'supported', limitations: [] },
  }),

  // 7. Chittering Rats (DST) — ETB: opponent puts hand card on top of library
  defineCard({
    id: 'chittering-rats', name: 'Chittering Rats', set: 'DST',
    types: ['Creature'], subtypes: ['Rat'], colors: ['B'],
    power: 2, toughness: 2, manaCost: 3,
    oracleText: 'When this creature enters, target opponent puts a card from their hand on top of their library.',
    imageUri: 'https://cards.scryfall.io/large/front/9/8/980135d5-dfaa-4beb-b4b3-1e256bb46e61.jpg?1783944446',
    // M197 (decyzja właściciela): „Świat Wiedźmina to po prostu Wiedźmin".
    artId: 540, plan: 'Wiedźmin',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'opponent' } },
        effect: [{ type: 'opponent_hand_card_to_top' }],
      }),
    ],
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Goldmeadow Nomad (ECL) — {W}, Exile from graveyard: 1/1 Kithkin token
  defineCard({
    id: 'goldmeadow-nomad', name: 'Goldmeadow Nomad', set: 'ECL',
    types: ['Creature'], subtypes: ['Kithkin', 'Scout'], colors: ['W'],
    power: 1, toughness: 2, manaCost: 1,
    oracleText: '{W}, Exile this card from your graveyard: Create a 1/1 green and white Kithkin creature token. Activate only as a sorcery.',
    imageUri: 'https://cards.scryfall.io/large/front/0/0/00ddbe6c-11de-4bc6-aabe-d6d8385a838a.jpg?1783904506',
    artId: 190, plan: 'Lorwyn',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 1, exileFromGraveyard: true, colors: ['W'] },
        timing: 'sorcery',
        fromGraveyard: true,
        effect: { type: 'create_token', cardId: 'token_kithkin', name: 'Kithkin', kind: 'creature', power: 1, toughness: 1, colors: ['G', 'W'], types: ['Creature'], subtypes: ['Kithkin'] },
      }),
    ],
    support: { status: 'supported', limitations: [] },
  }),

  // Token Goldmeadow Nomad (ECL): 1/1 green/white Kithkin.
  defineCard({
    id: 'token_kithkin', name: 'Kithkin', set: null,
    types: ['Creature', 'Token'], subtypes: ['Kithkin'], colors: ['G', 'W'],
    power: 1, toughness: 1, manaCost: 0,
    imageUri: 'https://cards.scryfall.io/large/front/2/e/2ed11e1b-2289-48d2-8d96-ee7e590ecfd4.jpg?1783904325',  // tecl
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Goldmeadow Nomad'] },
  }),

  // 9. Fear of Abduction (DSK) — exile own creature cost + ETB exile opp + LTB return
  defineCard({
    id: 'fear-of-abduction', name: 'Fear of Abduction', set: 'DSK',
    types: ['Enchantment', 'Creature'], subtypes: ['Nightmare'], colors: ['W'],
    power: 5, toughness: 5, manaCost: 6, keywords: ['flying'],
    additionalCost: { exileCreature: true },
    oracleText: 'As an additional cost to cast this spell, exile a creature you control.\nFlying\nWhen this creature enters, exile target creature an opponent controls.\nWhen this creature leaves the battlefield, put each card exiled with it into its owner\'s hand.',
    imageUri: 'https://cards.scryfall.io/large/front/f/c/fc9374be-5e4b-4c23-8b6e-94c03d4f5ef1.jpg?1783909510',
    artId: 373, plan: 'Duskmourn',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'creature_opponent_controls' } },
        effect: [{ type: 'exile_opponent_creature' }],
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'leaves_battlefield' },
        effect: [{ type: 'return_banished_to_hand' }],
      }),
    ],
    support: { status: 'supported', limitations: [] },
  }),

  // 10. Moonlit Meditation (EOE) — replacement: first token → copies of enchanted permanent
  defineCard({
    id: 'moonlit-meditation', name: 'Moonlit Meditation', set: 'EOE',
    types: ['Enchantment'], subtypes: ['Aura'], colors: ['U'], manaCost: 3,
    // M117 (ADR 0002): efekt zastępczy jako DESKRYPTOR karty. Wcześniej
    // engine rozpoznawał tę kartę po `cardId === 'moonlit-meditation'`.
    aura: {
      enchantType: 'artifact_or_creature',
      replaceTokenCreation: { copiesOfEnchanted: true, oncePerTurn: true, optional: true },
    },
    oracleText: 'Enchant artifact or creature you control\\nThe first time you would create one or more tokens each turn, you may instead create that many tokens that are copies of enchanted permanent.',
    imageUri: 'https://cards.scryfall.io/large/front/f/2/f2a56007-5bca-4edf-9cc4-5f77a273636c.jpg?1783905978',
    artId: 281, plan: 'The Edge',
    support: { status: 'supported', limitations: [] },
  }),

  // Token-klon (Moonlit Meditation): kopia zaczarowanego permanentu — nie taliowalna.
  defineCard({
    id: 'token_clone', name: 'Clone', set: null,
    types: ['Token'], colors: [],
    imageUri: 'https://cards.scryfall.io/large/front/b/2/b2a03ba1-2182-4074-99f5-f3952c1d37ec.jpg?1783902815',  // tmsc
    support: { status: 'limited', limitations: [] },
    notes: ['token-klon — tworzony przez Moonlit Meditation; P/T/typy zależą od zaczarowanego permanentu'],
  }),

  // Uwaga (Batch 19): tokeny Soldier z CLB to istniejący `token_soldier`
  // (definicja z Captain's Call) — identyczny profil 1/1 biały Soldier;
  // nowego tokena nie dodajemy (deduplikacja).


  // ===================== Batch 21 (10 kart, 2026-08-07) ======================

  // 1. Servant of the Scale (DTK) — ETB +1/+1; dies przenosi liczniki na cel.
  defineCard({
    id: 'servant-of-the-scale', name: 'Servant of the Scale', set: 'DTK',
    types: ['Creature'], subtypes: ['Human', 'Soldier'], colors: ['G'],
    power: 0, toughness: 0, manaCost: 1,
    entersWithCounters: { '+1/+1': 1 },
    oracleText: 'This creature enters with a +1/+1 counter on it.\nWhen this creature dies, put X +1/+1 counters on target creature you control, where X is the number of +1/+1 counters on this creature.',
    imageUri: 'https://cards.scryfall.io/large/front/c/a/ca887c41-a8ee-4751-a902-87149c29a9df.jpg?1783938577',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'dies', requiresTarget: { type: 'creature_you_control' } },
        effect: [{ type: 'transfer_counters_on_dies', counter: '+1/+1' }],
      }),
    ],
    artId: 10, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Gray Slaad (CLB) — Adventure: Entropic Decay {1}{B} mill 4 → exile,
  //    potem rzut stwora z exile; menace+deathtouch przy >= 4 kartach stwora.
  defineCard({
    id: 'gray-slaad', name: 'Gray Slaad', set: 'CLB',
    types: ['Creature'], subtypes: ['Frog', 'Horror'], colors: ['B'],
    power: 4, toughness: 1, manaCost: 3,
    oracleText: 'As long as there are four or more creature cards in your graveyard, this creature has menace and deathtouch.\nEntropic Decay — {1}{B} (Then exile this card. You may cast the creature later from exile.)',
    imageUri: 'https://cards.scryfall.io/large/front/0/c/0c2b6960-ff4c-4557-ba6d-d504f87d4516.jpg?1783922760',
    adventure: {
      cost: 2, colors: ['B'],
      spell: { timing: 'sorcery', targets: [], effects: [{ type: 'mill_cards', amount: 4 }] },
    },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.static,
        condition: { minCreatureCardsInGraveyard: 4 },
        keywords: ['menace', 'deathtouch'],
      }),
    ],
    artId: 234, plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Ember Beast (GTC) — „can't attack or block alone".
  defineCard({
    id: 'ember-beast', name: 'Ember Beast', set: 'GTC',
    types: ['Creature'], subtypes: ['Beast'], colors: ['R'],
    power: 3, toughness: 4, manaCost: 3,
    oracleText: "This creature can't attack or block alone.",
    imageUri: 'https://cards.scryfall.io/large/front/8/a/8a6d9cab-b07b-456b-9562-7ea7f6bec7f3.jpg?1783940125',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.static,
        cantAttackAlone: true, cantBlockAlone: true,
      }),
    ],
    artId: 26, plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
  }),

  // 4. Kor Sanctifiers (HOP) — Kicker {W}; ETB „if it was kicked" niszczy
  //    celowy artefakt/enchantment.
  defineCard({
    id: 'kor-sanctifiers', name: 'Kor Sanctifiers', set: 'HOP',
    types: ['Creature'], subtypes: ['Kor', 'Cleric'], colors: ['W'],
    power: 2, toughness: 3, manaCost: 3,
    kicker: { cost: 1, colors: ['W'] },
    oracleText: 'Kicker {W} (You may pay an additional {W} as you cast this spell.)\nWhen this creature enters, if it was kicked, destroy target artifact or enchantment.',
    imageUri: 'https://cards.scryfall.io/large/front/2/c/2c1544bf-d4f4-4e3a-9b93-8ea50bc86922.jpg?1783942336',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: {
          event: 'enter_battlefield',
          requiresTarget: { type: 'artifact_or_enchantment' },
          condition: { wasKicked: true },
        },
        effect: [{ type: 'destroy_permanent' }],
      }),
    ],
    artId: 43, plan: 'Zendikar',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Irontread Crusher (AER) — Vehicle, Crew 3 (6/6 artefaktowy stwór do
  //    końca tury po zatapnięciu stworów o łącznej mocy >= 3).
  defineCard({
    id: 'irontread-crusher', name: 'Irontread Crusher', set: 'AER',
    types: ['Artifact'], subtypes: ['Vehicle'], colors: [],
    power: 6, toughness: 6, manaCost: 4,
    oracleText: 'Crew 3 (Tap any number of creatures you control with total power 3 or more: This Vehicle becomes an artifact creature until end of turn.)',
    imageUri: 'https://cards.scryfall.io/large/front/8/1/81873223-29c7-466b-b922-6717ec84afff.jpg?1783936726',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        // Crew (CR 701.36) NIE ma w Oracle „Activate only as a sorcery" —
        // aktywuje się jak instant (z priorytetem, także w turze przeciwnika).
        // Audyt Batchu 26 (M65): timing 'sorcery' blokował crew w odpowiedzi
        // na czar i w turze przeciwnika.
        cost: { crewPower: 3 },
        effect: { type: 'animate_permanent_until_end_of_turn', power: 6, toughness: 6, typesAdd: ['Creature'] },
      }),
    ],
    artId: 455, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 6. Skilled Animator (CMR) — ETB: celowy artefakt staje się artefaktowym
  //    stworem 5/5, DOPÓKI animator jest na polu bitwy (linked animation).
  defineCard({
    id: 'skilled-animator', name: 'Skilled Animator', set: 'CMR',
    types: ['Creature'], subtypes: ['Human', 'Artificer'], colors: ['U'],
    power: 1, toughness: 3, manaCost: 3,
    oracleText: "When this creature enters, target artifact you control becomes an artifact creature with base power and toughness 5/5 for as long as this creature remains on the battlefield.",
    imageUri: 'https://cards.scryfall.io/large/front/b/c/bc396c69-9773-4d57-a955-280742a10a91.jpg?1783928850',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'artifact_you_control' } },
        effect: [{ type: 'animate_linked', power: 5, toughness: 5, typesAdd: ['Artifact', 'Creature'] }],
      }),
    ],
    artId: 204, plan: 'Kaladesh',
    support: { status: 'supported', limitations: [] },
  }),

  // 7. Withstand (GPT) — tarcza prewencji „next 3 damage" na dowolny cel + draw.
  defineCard({
    id: 'withstand', name: 'Withstand', set: 'GPT',
    types: ['Instant'], colors: ['W'], manaCost: 3,
    oracleText: 'Prevent the next 3 damage that would be dealt to any target this turn.\nDraw a card.',
    imageUri: 'https://cards.scryfall.io/large/front/b/b/bb458f79-13dd-4446-be75-463f19548867.jpg?1783943523',
    spell: {
      timing: 'instant',
      targets: [{ type: 'any_target' }],
      effects: [
        { type: 'prevent_next_damage', amount: 3 },
        { type: 'draw_cards', amount: 1 },
      ],
    },
    artId: 137, plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Nightshade Harvester (CMR) — landfall przeciwnika: ten gracz traci
  //    życie, źródło dostaje +1/+1.
  defineCard({
    id: 'nightshade-harvester', name: 'Nightshade Harvester', set: 'CMR',
    types: ['Creature'], subtypes: ['Elf', 'Shaman'], colors: ['B'],
    power: 2, toughness: 2, manaCost: 4,
    oracleText: 'Whenever a land an opponent controls enters, that player loses 1 life. Put a +1/+1 counter on this creature.',
    imageUri: 'https://cards.scryfall.io/large/front/8/2/8297ab13-d6f3-487b-86ec-6eb299eb0614.jpg?1783928832',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'land_entered_under_opponent_control' },
        effect: [
          { type: 'lose_life', amount: 1, applyTo: 'event_player' },
          { type: 'add_counter', counter: '+1/+1', amount: 1 },
        ],
      }),
    ],
    artId: 430, plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
  }),

  // 9. True Conviction (SOM) — globalny anthem keywordów: double strike
  //    i lifelink dla stworów kontrolera.
  defineCard({
    id: 'true-conviction', name: 'True Conviction', set: 'SOM',
    types: ['Enchantment'], colors: ['W'], manaCost: 6,
    oracleText: 'Creatures you control have double strike and lifelink.',
    imageUri: 'https://cards.scryfall.io/large/front/2/3/23a1d384-1b36-42d0-957f-48103f9cdbdd.jpg?1783941741',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.static,
        scope: { affects: 'other_creatures_you_control' },
        keywords: ['double_strike', 'lifelink'],
      }),
    ],
    artId: 482, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  // 10. Disa the Restless (M3C) — Lhurgoyf z dowolnej strefy do grobu → na
  //     pole bitwy; combat damage stworami → token Tarmogoyf (dynamiczne P/T).
  defineCard({
    id: 'disa-the-restless', name: 'Disa the Restless', set: 'M3C',
    types: ['Legendary', 'Creature'], subtypes: ['Human', 'Scout'], colors: ['B', 'R', 'G'],
    power: 5, toughness: 6, manaCost: 5,
    oracleText: 'Whenever a Lhurgoyf permanent card is put into your graveyard from anywhere other than the battlefield, put it onto the battlefield.\nWhenever one or more creatures you control deal combat damage to a player, create a Tarmogoyf token.',
    imageUri: 'https://cards.scryfall.io/large/front/c/9/c976edeb-0fa1-4647-a16c-870d8a3c30c6.jpg?1783911438',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'card_put_into_graveyard_from_nonbattlefield', subtypes: ['Lhurgoyf'] },
        effect: [{ type: 'put_graveyard_card_onto_battlefield' }],
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'any_combat_damage_to_player' },
        effect: [{
          type: 'create_token', cardId: 'token_tarmogoyf', name: 'Tarmogoyf',
          kind: 'creature', power: 0, toughness: 0, colors: ['G'],
          types: ['Creature'], subtypes: ['Lhurgoyf'],
          // Dynamiczne P/T: liczba typów kart we WSZYSTKICH grobach (+1
          // do wytrzymałości) — marker liczony w permanents.staticBonuses.
          abilities: [createAbility({
            type: ABILITY_TYPE.static,
            pump: { power: 'card_types_in_all_graveyards', toughness: 'card_types_in_all_graveyards_plus_1' },
          })],
        }],
      }),
    ],
    artId: 531, plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
  }),

  // Token Tarmogoyf (Disa the Restless, M3C): */*+1 — nie taliowalny.
  defineCard({
    id: 'token_tarmogoyf', name: 'Tarmogoyf', set: null,
    types: ['Creature', 'Token'], subtypes: ['Lhurgoyf'], colors: ['G'],
    power: 0, toughness: 0, manaCost: 0,
    oracleText: "Tarmogoyf's power is equal to the number of card types among cards in all graveyards and its toughness is equal to that number plus 1.",
    abilities: [
      createAbility({
        type: ABILITY_TYPE.static,
        pump: { power: 'card_types_in_all_graveyards', toughness: 'card_types_in_all_graveyards_plus_1' },
      }),
    ],
    imageUri: 'https://cards.scryfall.io/large/front/f/2/f26e1f55-284c-4540-bf5c-ebc7ab9687ab.jpg?1783911122',  // tm3c
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Disa the Restless'] },
  }),

  // =========================================================================
  // Batch 22 (10 kart, 2026-08-08) — lista właściciela
  // Thistledown Players, Etherwrought Page, Stomping Slabs, Courage in
  // Crisis, Selesnya Charm, Wormfang Newt, Raise the Alarm, Cellar Door,
  // Healer of the Glade, Enter the Enigma. Dane Oracle w
  // docs/cards/scryfall-*.json, artId i plan ze słownika
  // tools/collection-art-ids.csv.
  // =========================================================================

  // 1. Thistledown Players (BLB) {2}{W} 3/3 — trigger attacks + untap
  // target nonland permanent (T2: cel wybiera kontroler).
  defineCard({
    id: 'thistledown-players', name: 'Thistledown Players', set: 'BLB',
    types: ['Creature'], subtypes: ['Mouse', 'Bard'], colors: ['W'],
    power: 3, toughness: 3, manaCost: 3,
    oracleText: 'Whenever this creature attacks, untap target nonland permanent.',
    imageUri: 'https://cards.scryfall.io/large/front/a/f/afa8d83f-8586-4127-8b55-9715e9547488.jpg?1783910855',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'attacks', requiresTarget: { type: 'nonland_permanent' } },
        effect: [{ type: 'untap_permanent' }],
      }),
    ],
    artId: 374,
    plan: 'Bloomburrow',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Etherwrought Page (ARB) {1}{W}{U}{B} Artifact — upkeep trigger
  // "choose one" (modalne tryby). Boty deterministycznie biorą
  // pierwszą (tryb 0 = gain 2 life) — modalność zostawiamy dla
  // graczy (resolve_modal_choice).
  defineCard({
    id: 'etherwrought-page', name: 'Etherwrought Page', set: 'ARB',
    types: ['Artifact'], colors: ['B', 'U', 'W'], manaCost: 4,
    oracleText: 'At the beginning of your upkeep, choose one —\n• You gain 2 life.\n• Surveil 1. (Look at the top card of your library. You may put that card into your graveyard.)\n• Each opponent loses 1 life.',
    imageUri: 'https://cards.scryfall.io/large/front/5/6/568785f1-47c7-4011-926f-44693f7e0233.jpg?1783942417',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: {
          event: 'upkeep',
          // Modalne tryby (Batch 22): kolejka pendingModalTrigger →
          // resolve_modal_choice. Boty biorą pierwszą opcję (tryb 0).
          modes: [
            { name: 'Zysk 2 życia', effects: [{ type: 'gain_life', amount: 2, scope: 'controller' }] },
            { name: 'Surveil 1',  effects: [{ type: 'surveil', amount: 1 }] },
            { name: 'Utrata życia',    effects: [{ type: 'lose_life', amount: 1, scope: 'each_opponent' }] },
          ],
        },
        effect: [],
      }),
    ],
    artId: 55,
    plan: 'Alara',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Stomping Slabs (MOR) {2}{R} Sorcery — reveal top 7 + put bottom
  // in any order; if „Stomping Slabs" was in reveal, deal 7 to any
  // target. Mechaniki: reveal_top_to_bottom_order (Batch 22) + kolejka
  // pendingDamageTarget (resolve_damage_target).
  defineCard({
    id: 'stomping-slabs', name: 'Stomping Slabs', set: 'MOR',
    types: ['Sorcery'], colors: ['R'], manaCost: 3,
    oracleText: 'Reveal the top seven cards of your library, then put those cards on the bottom of your library in any order. If a card named Stomping Slabs was revealed this way, Stomping Slabs deals 7 damage to any target.',
    imageUri: 'https://cards.scryfall.io/large/front/8/2/820f1acf-7f0c-4ee5-9f18-b5627aac7c81.jpg?1783942782',
    spell: {
      timing: 'sorcery', targets: [],
      effects: [{
        type: 'reveal_top_to_bottom_order',
        amount: 7,
        namedCard: 'Stomping Slabs',
        thenDamage: 7,
      }],
    },
    artId: 182,
    plan: 'Lorwyn',
    support: { status: 'supported', limitations: [] },
  }),

  // =========================================================================
  // Batch 23 (10 kart, 2026-08-08) — lista właściciela
  // Vandalize, Expunge, Shiv's Embrace, Deepwood Denizen, Welder Automaton,
  // Feedback, Vow of Wildness, Greater Tanuki, Scorch Spitter, Turn the Tide.
  // Dane Oracle w docs/cards/scryfall-*.json, artId i plan ze słownika
  // tools/collection-art-ids.csv.
  // =========================================================================

  // 1. Vandalize (DTK) {4}{R} Sorcery — Choose one or both — Destroy artifact, Destroy land.
  // Uproszczenie Oracle "one or both" do 3 trybów (artifact / land / both) — 100% pokrycia wyborów.
  defineCard({
    id: 'vandalize', name: 'Vandalize', set: 'DTK',
    types: ['Sorcery'], colors: ['R'], manaCost: 5,
    oracleText: 'Choose one or both —\n• Destroy target artifact.\n• Destroy target land.',
    imageUri: 'https://cards.scryfall.io/large/front/4/8/48b04f7a-4fd6-47d2-b378-99c7fb0c1809.jpg?1783938584',
    spell: {
      timing: 'sorcery',
      modes: [
        { name: 'Zniszcz artefakt', targets: [{ type: 'artifact' }], effects: [{ type: 'destroy_permanent' }] },
        { name: 'Zniszcz ląd', targets: [{ type: 'land' }], effects: [{ type: 'destroy_permanent' }] },
        { name: 'Zniszcz oba', targets: [{ type: 'artifact' }, { type: 'land' }], effects: [{ type: 'destroy_permanent', targetIndex: 0 }, { type: 'destroy_permanent', targetIndex: 1 }] },
      ],
    },
    artId: 499,
    plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Expunge (USG) {2}{B} Instant — Destroy nonartifact, nonblack creature, can't be regenerated. Cycling {2}.
  defineCard({
    id: 'expunge', name: 'Expunge', set: 'USG',
    types: ['Instant'], colors: ['B'], manaCost: 3,
    oracleText: 'Destroy target nonartifact, nonblack creature. It can\'t be regenerated.\nCycling {2} ({2}, Discard this card: Draw a card.)',
    imageUri: 'https://cards.scryfall.io/large/front/1/b/1b4650f3-f3d5-48b1-9fc9-264d03442021.jpg?1783939291',
    spell: {
      timing: 'instant', targets: [{ type: 'nonartifact_nonblack_creature' }],
      effects: [
        { type: 'cant_be_regenerated_this_turn' },
        { type: 'destroy_permanent' },
      ],
    },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'cycling',
        cost: { mana: 2 },
        cycling: { drawCards: 1 },
      }),
    ],
    artId: 40,
    plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Shiv's Embrace (M11) {2}{R}{R} Aura — Enchant creature, +2/+2 flying, {R}: +1/+0 until EOT.
  defineCard({
    id: 'shivs-embrace', name: "Shiv's Embrace", set: 'M11',
    types: ['Enchantment'], subtypes: ['Aura'], colors: ['R'], manaCost: 4,
    oracleText: "Enchant creature\nEnchanted creature gets +2/+2 and has flying.\n{R}: Enchanted creature gets +1/+0 until end of turn.",
    imageUri: 'https://cards.scryfall.io/large/front/8/a/8a42fcd6-32ce-4a20-af4d-83bd32a7ed3e.jpg?1783939910',
    aura: { pump: { power: 2, toughness: 2 }, keywords: ['flying'] },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 1, colors: ['R'] },
        effect: { type: 'pump_enchanted_creature', power: 1, toughness: 0 },
      }),
    ],
    artId: 496,
    plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
  }),
  // 4. Deepwood Denizen (MH2) {2}{G} 3/2 — Vigilance, {5}{G},{T}: Draw a card, costs {1} less per +1/+1 counter.
  defineCard({
    id: 'deepwood-denizen', name: 'Deepwood Denizen', set: 'MH2',
    types: ['Creature'], subtypes: ['Elf', 'Warrior'], colors: ['G'],
    power: 3, toughness: 2, manaCost: 3, keywords: ['vigilance'],
    oracleText: 'Vigilance\\n{5}{G}, {T}: Draw a card. This ability costs {1} less to activate for each +1/+1 counter on creatures you control.',
    imageUri: 'https://cards.scryfall.io/large/front/3/3/333f02f7-3b8a-41e3-9ae5-2151539e64ad.jpg?1783926833',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 6, colors: ['G'], tap: true },
        costReduction: { perCounter: '+1/+1', amount: 1 },
        effect: { type: 'draw_cards', amount: 1 },
      }),
    ],
    artId: 51,
    plan: 'Śródziemie',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Welder Automaton (AER) {2} 2/1 — {3}{R}: 1 damage to each opponent.
  defineCard({
    id: 'welder-automaton', name: 'Welder Automaton', set: 'AER',
    types: ['Artifact', 'Creature'], subtypes: ['Construct'], colors: [],
    power: 2, toughness: 1, manaCost: 2,
    oracleText: '{3}{R}: This creature deals 1 damage to each opponent.',
    imageUri: 'https://cards.scryfall.io/large/front/9/3/938066de-d111-4df2-87f0-9eb72aa4cdac.jpg?1783933968',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 4, colors: ['R'] },
        effect: { type: 'damage_each_opponent', amount: 1 },
      }),
    ],
    artId: 113,
    plan: 'Kaladesh',
    support: { status: 'supported', limitations: [] },
  }),

  // 6. Feedback (5ED) {2}{U} Aura — Enchant enchantment, upkeep 1 damage to enchanted controller.
  defineCard({
    id: 'feedback', name: 'Feedback', set: '5ED',
    types: ['Enchantment'], subtypes: ['Aura'], colors: ['U'], manaCost: 3,
    oracleText: "Enchant enchantment\\nAt the beginning of the upkeep of enchanted enchantment's controller, this Aura deals 1 damage to that player.",
    imageUri: 'https://cards.scryfall.io/large/front/1/d/1d452de7-3f44-4594-bb24-2178812da9d6.jpg?1783946949',
    aura: { enchant: 'enchantment' },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'upkeep', condition: { enchantedPermanentControllerUpkeep: true } },
        effect: { type: 'damage_enchanted_permanent_controller', amount: 1 },
      }),
    ],
    artId: 249,
    plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),
  // 7. Vow of Wildness (CMR) {2}{G} Aura — +3/+3 trample, can't attack you.
  defineCard({
    id: 'vow-of-wildness', name: 'Vow of Wildness', set: 'CMR',
    types: ['Enchantment'], subtypes: ['Aura'], colors: ['G'], manaCost: 3,
    oracleText: "Enchant creature\\nEnchanted creature gets +3/+3, has trample, and can't attack you or planeswalkers you control.",
    imageUri: 'https://cards.scryfall.io/large/front/7/6/764fa7f1-b92b-42cc-983e-e0b5457369a7.jpg?1783928780',
    aura: { pump: { power: 3, toughness: 3 }, keywords: ['trample'], cantAttackYou: true },
    artId: 396,
    plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
    notes: ['can\'t attack you — w 1v1 stwór przeciwnika z Vow nie może atakować (jedyny przeciwnik to Ty)'],
  }),

  // 8. Greater Tanuki (NEO) {4}{G}{G} 6/5 — Trample, Channel {2}{G}, discard: search basic land tapped.
  defineCard({
    id: 'greater-tanuki', name: 'Greater Tanuki', set: 'NEO',
    types: ['Enchantment', 'Creature'], subtypes: ['Dog'], colors: ['G'],
    power: 6, toughness: 5, manaCost: 6, keywords: ['trample'],
    oracleText: 'Trample\\nChannel — {2}{G}, Discard this card: Search your library for a basic land card, put it onto the battlefield tapped, then shuffle.',
    imageUri: 'https://cards.scryfall.io/large/front/b/4/b4fbaee3-a10f-4b2d-b07e-d041a96a7e27.jpg?1783923849',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 3, colors: ['G'] },
        channel: { searchBasicLandTapped: true },
        effect: { type: 'search_library_to_battlefield_tapped', qualifier: { types: ['Basic', 'Land'] } },
      }),
    ],
    artId: 449,
    plan: 'Kamigawa',
    support: { status: 'supported', limitations: [] },
  }),

  // 9. Scorch Spitter (M20) {R} 1/1 — Whenever attacks, deals 1 damage to defending player.
  defineCard({
    id: 'scorch-spitter', name: 'Scorch Spitter', set: 'M20',
    types: ['Creature'], subtypes: ['Elemental', 'Lizard'], colors: ['R'],
    power: 1, toughness: 1, manaCost: 1,
    oracleText: "Whenever this creature attacks, it deals 1 damage to the player or planeswalker it's attacking.",
    imageUri: 'https://cards.scryfall.io/large/front/b/b/bb701a84-24bd-41ed-9f06-25c8338902a5.jpg?1783932970',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'attacks' },
        effect: { type: 'damage_defending_player', amount: 1 },
      }),
    ],
    artId: 495,
    plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
  }),

  // 10. Turn the Tide (MBS) {1}{U} Instant — Creatures opponents control get -2/-0 until EOT.
  defineCard({
    id: 'turn-the-tide', name: 'Turn the Tide', set: 'MBS',
    types: ['Instant'], colors: ['U'], manaCost: 2,
    oracleText: "Creatures your opponents control get -2/-0 until end of turn.",
    imageUri: 'https://cards.scryfall.io/large/front/b/d/bdc91fc7-7927-4c5d-888a-f40cbf658866.jpg?1783941386',
    spell: {
      timing: 'instant',
      targets: [],
      effects: [{ type: 'buff_opponents_creatures', power: -2, toughness: 0 }],
    },
    artId: 529,
    plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),
]);


/**
 * Karta lochu „The Undercity" (dungeon z inicjatywy, CR 725; karta
 * „Undercity // The Initiative" z CLB). W legacy aplikacji to karta specjalna
 * 990006 („Dungeon: The Undercity"), a jej druk pobiera Scryfall przez
 * `api.scryfall.com/cards/tclb/20?format=image` — używamy tego samego adresu.
 * Nie jest taliowalna; stół renderuje ją jako kartę-obserwator z zaznaczeniem
 * pokoju każdego gracza (M24).
 */
// M68 — token „Day // Night" (TVOW 21): globalny znacznik dnia/nocy (CR 708.9),
// renderowany na stole jak karta lochu — front (Day) gdy dzień, back (Night)
// gdy noc. Pobrane ze Scryfall przez fetch_page.
export const DAY_NIGHT_TOKEN = Object.freeze({
  id: 'day-night',
  name: 'Day // Night',
  typeLine: 'Card // Card',
  imageUriDay: 'https://cards.scryfall.io/large/front/d/c/dc26e13b-7a0f-4e7f-8593-4f22234f4517.jpg?1783924696',
  imageUriNight: 'https://cards.scryfall.io/large/back/d/c/dc26e13b-7a0f-4e7f-8593-4f22234f4517.jpg?1783924696',
});

export const UNDERCITY_DUNGEON = Object.freeze({
  id: 'undercity',
  name: 'The Undercity',
  typeLine: 'Dungeon — Undercity',
  imageUri: 'https://api.scryfall.com/cards/tclb/20?format=image',
});

/**
 * Wirtualne landy podstawowe (rozstrzygnięcie właściciela 2026-08-01): NIE
 * należą do katalogu batchowych kart — to prymitywy gry obecne zawsze, bez
 * procedury Scryfall i bez limitu kopii w talii (deck-validation po polu
 * „Basic"). Są w rejestrze, żeby talie i cycling mogły się do nich odwołać
 * jak do zwykłych obiektów (subtype napędza szukanie typecyclingiem).
 *
 * Ilustracja (decyzja właściciela 2026-08-01, poz. 10.1): druk domyślny
 * Scryfalla przez przekierowanie po nazwie — dokładnie jak w pliku legacy
 * (`getPlaytableFullCardImage` dla ID 990001–990005). Adres jest „stałym
 * drukiem" w tym sensie, że nie zależy od konkretnego setu: Scryfall zwraca
 * swój druk domyślny, a my nie musimy pilnować rotacji setów.
 */
const basicLandImage = (name) =>
  `https://api.scryfall.com/cards/named?exact=${encodeURIComponent(name)}&format=image&version=normal`;

// CR 202.2: kolor obiektu wyznacza jego koszt many. Land nie ma kosztu many,
// wiec KAZDY land jest bezbarwny — takze podstawowy. Podtyp (Plains/Forest)
// mowi, jaka mane produkuje, i to on steruje produkcja (mana-sources.js),
// a nie pole `colors`. Kolor landa jest widoczny w regulach walki:
// „protection from [kolor]”, intimidate i „can't be blocked except by
// [kolor] creatures” patrza na colors blokera — animowany land (Silvanus's
// Invoker) musi byc tam bezbarwny.
export const VIRTUAL_BASIC_LANDS = Object.freeze([
  defineCard({ id: 'basic-plains', name: 'Plains', set: null, types: ['Basic', 'Land'], subtypes: ['Plains'], colors: [], imageUri: basicLandImage('Plains'), support: { status: 'supported' } }),
  defineCard({ id: 'basic-island', name: 'Island', set: null, types: ['Basic', 'Land'], subtypes: ['Island'], colors: [], imageUri: basicLandImage('Island'), support: { status: 'supported' } }),
  defineCard({ id: 'basic-swamp', name: 'Swamp', set: null, types: ['Basic', 'Land'], subtypes: ['Swamp'], colors: [], imageUri: basicLandImage('Swamp'), support: { status: 'supported' } }),
  defineCard({ id: 'basic-mountain', name: 'Mountain', set: null, types: ['Basic', 'Land'], subtypes: ['Mountain'], colors: [], imageUri: basicLandImage('Mountain'), support: { status: 'supported' } }),
  defineCard({ id: 'basic-forest', name: 'Forest', set: null, types: ['Basic', 'Land'], subtypes: ['Forest'], colors: [], imageUri: basicLandImage('Forest'), support: { status: 'supported' } }),
  // =========================================================================
  // Batch 24 (10 kart, 2026-08-08) — lista właściciela
  // Faceless Butcher, Unbreakable Bond, Spinewoods Paladin, Tome Scour,
  // Goblin Battle Jester, Brawler's Plate, Glitch Ghost Surveyor, Mystic
  // Sanctuary, Willbender, Scion Summoner. Dane Oracle w docs/cards/scryfall-*
  // (pobrane z parametrem set= — lekcja M54), artId i plan ze słownika
  // tools/collection-art-ids.csv.
  // =========================================================================

  // 1. Faceless Butcher (TOR) {2}{B}{B} 2/3 — ETB exile another creature, LTB return.
  defineCard({
    id: 'faceless-butcher', name: 'Faceless Butcher', set: 'TOR',
    types: ['Creature'], subtypes: ['Nightmare', 'Horror'], colors: ['B'],
    power: 2, toughness: 3, manaCost: 4,
    oracleText: "When this creature enters, exile another target creature.\nWhen this creature leaves the battlefield, return the exiled card to the battlefield under its owner's control.",
    imageUri: 'https://cards.scryfall.io/large/front/4/0/4073be21-c54a-4eee-9109-f3adfe757c4e.jpg?1783945157',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'creature', notSelf: true } },
        effect: [{ type: 'exile_target_creature' }],
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'leaves_battlefield' },
        effect: [{ type: 'return_exiled_to_battlefield' }],
      }),
    ],
    artId: 313,
    plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Unbreakable Bond (IKO) {4}{B} Sorcery — reanimacja z lifelink counter.
  defineCard({
    id: 'unbreakable-bond', name: 'Unbreakable Bond', set: 'IKO',
    types: ['Sorcery'], colors: ['B'], manaCost: 5,
    oracleText: "Return target creature card from your graveyard to the battlefield with a lifelink counter on it.",
    imageUri: 'https://cards.scryfall.io/large/front/c/9/c9da02a1-7b39-4a0e-8466-6512a02f3e3b.jpg?1783931056',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'creature_card_in_graveyard' }],
      effects: [{ type: 'return_permanent_from_graveyard', counters: { lifelink: 1 } }],
    },
    artId: 446,
    plan: 'Ikoria',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Spinewoods Paladin (OTJ) {4}{G} 5/4 Trample — ETB gain 3 life, Plot {3}{G}.
  defineCard({
    id: 'spinewoods-paladin', name: 'Spinewoods Paladin', set: 'OTJ',
    types: ['Creature'], subtypes: ['Human', 'Knight'], colors: ['G'],
    keywords: ['trample'], power: 5, toughness: 4, manaCost: 5,
    oracleText: "Trample\nWhen this creature enters, you gain 3 life.\nPlot {3}{G} (You may pay {3}{G} and exile this card from your hand. Cast it as a sorcery on a later turn without paying its mana cost. Plot only as a sorcery.)",
    imageUri: 'https://cards.scryfall.io/large/front/1/b/1b2b432d-9e73-4ab2-a098-546d406df6c0.jpg?1783911802',
    // Plot {3}{G} = 4 many z pipem G — koszt niesie kolory (walidacja jak rzut).
    plot: { cost: 4, colors: ['G'] },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{ type: 'gain_life', amount: 3 }],
      }),
    ],
    artId: 277,
    plan: 'Thunder Junction',
    support: { status: 'supported', limitations: [] },
  }),

  // 4. Tome Scour (M11) {U} Sorcery — target player mills five.
  defineCard({
    id: 'tome-scour', name: 'Tome Scour', set: 'M11',
    types: ['Sorcery'], colors: ['U'], manaCost: 1,
    oracleText: 'Target player mills five cards.',
    imageUri: 'https://cards.scryfall.io/large/front/6/4/6445f013-8b50-4ea3-9013-df85289c2605.jpg?1783941820',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'player' }],
      effects: [{ type: 'mill_cards', amount: 5 }],
    },
    artId: 69,
    plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Goblin Battle Jester (M13) {3}{R} 2/2 — red spell → target creature can't block.
  defineCard({
    id: 'goblin-battle-jester', name: 'Goblin Battle Jester', set: 'M13',
    types: ['Creature'], subtypes: ['Goblin'], colors: ['R'],
    power: 2, toughness: 2, manaCost: 4,
    oracleText: "Whenever you cast a red spell, target creature can't block this turn.",
    imageUri: 'https://cards.scryfall.io/large/front/c/1/c13e56b0-becc-4bc2-9ba3-23b3ca8bfe58.jpg?1783940483',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: {
          event: 'when_you_cast_spell',
          condition: { spellColorsInclude: ['R'] },
          requiresTarget: { type: 'creature' },
        },
        effect: [{ type: 'cant_block' }],
      }),
    ],
    artId: 312,
    plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 6. Brawler's Plate (M15) {3} Equipment — +2/+2 trample, Equip {4}.
  defineCard({
    id: 'brawlers-plate', name: "Brawler's Plate", set: 'M15',
    types: ['Artifact'], subtypes: ['Equipment'], colors: [], manaCost: 3,
    oracleText: "Equipped creature gets +2/+2 and has trample. (It can deal excess combat damage to the player or planeswalker it's attacking.)\nEquip {4} ({4}: Attach to target creature you control. Equip only as a sorcery.)",
    imageUri: 'https://cards.scryfall.io/large/front/e/d/eddc4ee6-7855-4dc7-9488-5e019609bd09.jpg?1783939159',
    equipment: { equip: 4, pump: { power: 2, toughness: 2 }, keywords: ['trample'] },
    abilities: [
      // Equip {4} — zdolność aktywowana (jak Cloak of the Bat); koszt czyta
      // deskryptor equipment (equip: 4) — jedno źródło dla oferty i buffu.
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'equip',
        cost: { mana: 4 },
      }),
    ],
    artId: 16,
    plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 7. Glitch Ghost Surveyor (DFT) {2}{U} 2/2 Flying — Start your engines! / Max speed.
  defineCard({
    id: 'glitch-ghost-surveyor', name: 'Glitch Ghost Surveyor', set: 'DFT',
    types: ['Creature'], subtypes: ['Spirit', 'Scout'], colors: ['U'],
    keywords: ['flying'], power: 2, toughness: 2, manaCost: 3,
    oracleText: "Flying\nStart your engines! (If you have no speed, it starts at 1. It increases once on each of your turns when an opponent loses life. Max speed is 4.)\nMax speed — {3}, Exile this card from your graveyard: Draw a card.",
    imageUri: 'https://cards.scryfall.io/large/front/b/9/b9bb89b9-50dd-4b36-aa10-aba585e50246.jpg?1783907909',
    abilities: [
      // „Start your engines!" — speed startuje od 1 (mechanika DFT; speed to
      // cecha GRACZA — trwa po odejściu źródła, wzrost przy obrażeniach
      // przeciwnika w triggers.js, max 4).
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{ type: 'start_engines' }],
      }),
      // „Max speed — {3}, Exile this card from your graveyard: Draw a card."
      createAbility({
        type: ABILITY_TYPE.activated,
        fromGraveyard: true,
        cost: { mana: 3, exileFromGraveyard: true },
        condition: { maxSpeed: true },
        effect: { type: 'draw_cards', amount: 1 },
      }),
    ],
    artId: 104,
    plan: 'Kaladesh',
    support: { status: 'supported', limitations: [] },
    notes: ['speed: start 1 przy ETB, wzrost raz na turę aktywnego gracza przy obrażeniach przeciwnika (max 4); „max speed" bramkuje zdolność z grobu'],
  }),

  // 8. Mystic Sanctuary (ELD) Land — Island, enters tapped unless 3+ other Islands.
  defineCard({
    id: 'mystic-sanctuary', name: 'Mystic Sanctuary', set: 'ELD',
    types: ['Land'], subtypes: ['Island'], colors: [],
    entersTapped: true,
    entersTappedCondition: { type: 'islands_you_control_at_least', amount: 3 },
    oracleText: "({T}: Add {U}.)\nThis land enters tapped unless you control three or more other Islands.\nWhen this land enters untapped, you may put target instant or sorcery card from your graveyard on top of your library.",
    imageUri: 'https://cards.scryfall.io/large/front/1/7/170e792c-80d5-4775-ad95-37614574ab84.jpg?1783932577',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: {
          event: 'enter_battlefield',
          condition: { enteredUntapped: true },
          requiresTarget: { type: 'instant_or_sorcery_card_in_graveyard', controlledBy: 'controller', optional: true },
        },
        effect: [{ type: 'put_graveyard_card_on_top' }],
      }),
    ],
    artId: 4,
    plan: 'Eldraine',
    support: { status: 'supported', limitations: [] },
  }),

  // 9. Willbender (DD2) {1}{U} 1/2 — Morph {1}{U}, face up → change target.
  defineCard({
    id: 'willbender', name: 'Willbender', set: 'DD2',
    types: ['Creature'], subtypes: ['Human', 'Wizard'], colors: ['U'],
    power: 1, toughness: 2, manaCost: 2, keywords: ['morph'],
    oracleText: "Morph {1}{U} (You may cast this card face down as a 2/2 creature for {3}. Turn it face up any time for its morph cost.)\nWhen this creature is turned face up, change the target of target spell or ability with a single target.",
    imageUri: 'https://cards.scryfall.io/large/front/7/c/7c35a94e-4449-4093-9652-5db0ec8b8bdd.jpg?1783942522',
    morph: { cost: 3, morphCost: 2, colors: ['U'] },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'turned_face_up', requiresTarget: { type: 'spell_with_single_target_on_stack' } },
        effect: [{ type: 'redirect_spell_target' }],
      }),
    ],
    artId: 243,
    plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
  }),

  // 10. Scion Summoner (OGW) {2}{G} 2/2 Devoid — ETB token Eldrazi Scion.
  defineCard({
    id: 'scion-summoner', name: 'Scion Summoner', set: 'OGW',
    types: ['Creature'], subtypes: ['Eldrazi', 'Drone'], colors: [],
    power: 2, toughness: 2, manaCost: 3,
    oracleText: "Devoid (This card has no color.)\nWhen this creature enters, create a 1/1 colorless Eldrazi Scion creature token. It has \"Sacrifice this token: Add {C}.\" ({C} represents colorless mana.)",
    imageUri: 'https://cards.scryfall.io/large/front/8/2/826a882e-c4bd-4132-b797-9e1aa2d0bce4.jpg?1783937903',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{
          type: 'create_token', cardId: 'token_eldrazi_scion', name: 'Eldrazi Scion',
          kind: 'creature', power: 1, toughness: 1, colors: [],
          types: ['Creature'], subtypes: ['Eldrazi', 'Scion'],
          abilities: [
            createAbility({
              type: ABILITY_TYPE.activated,
              cost: { sacrificeSelf: true },
              effect: { type: 'add_mana', amount: 1 },
            }),
          ],
        }],
      }),
    ],
    artId: 473,
    plan: 'Zendikar',
    support: { status: 'supported', limitations: [] },
  }),

  // Diament (2026-08-11): token Eldrazi Scion ZAREJESTROWANY — wcześniej tylko
  // inline w create_token (Scion Summoner), więc nameById nie znał nazwy i
  // etykiety pokazywały surowy „token_eldrazi_scion" (audyt żywym testerem).
  defineCard({
    id: 'token_eldrazi_scion', name: 'Eldrazi Scion', set: null,
    imageUri: 'https://cards.scryfall.io/large/front/c/6/c6ee5e2c-d98b-434e-9175-d20f7f713b88.jpg?1783911127', // M157/B: token ze Scryfall
    types: ['Creature', 'Token'], subtypes: ['Eldrazi', 'Scion'], colors: [],
    power: 1, toughness: 1, manaCost: 0,
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { sacrificeSelf: true },
        effect: { type: 'add_mana', amount: 1 },
      }),
    ],
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Scion Summoner'] },
  }),

  // =========================================================================
  // Batch 25 — 10 kart (2026-08-09)
  // =========================================================================

  // 1. Trestle Troll (RTR) — BG 1/4: defender, reach, {1}{B}{G}: Regenerate
  defineCard({
    id: 'trestle-troll', name: 'Trestle Troll', set: 'RTR',
    types: ['Creature'], subtypes: ['Troll'], colors: ['B', 'G'],
    power: 1, toughness: 4, manaCost: 3,
    oracleText: 'Defender\nReach (This creature can block creatures with flying.)\n{1}{B}{G}: Regenerate this creature.',
    imageUri: 'https://cards.scryfall.io/large/front/6/d/6d224279-83f3-4a29-9fd9-86b72407b87a.jpg?1783940330',
    keywords: ['defender', 'reach'],
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 3, colors: ['B', 'G'] },
        keyword: 'regenerate',
        // Efekt pusty: tarczę regeneracji zakłada ścieżka keyword
        // (performActivation → addRegenerationShield, CR 701.12); efekt
        // {type:'regenerate'} nie istnieje w applyEffect — audyt B26 (M65)
        // wykrył, że z nim aktywacja była ODRZUCANA („Nieznany typ efektu").
        effect: [],
      }),
    ],
    artId: 235, plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Lab Rats (STH) — {B} Sorcery: Buyback {4}, Create 1/1 Rat token
  defineCard({
    id: 'lab-rats', name: 'Lab Rats', set: 'STH',
    types: ['Sorcery'], colors: ['B'], manaCost: 1,
    oracleText: 'Buyback {4} (You may pay an additional {4} as you cast this spell. If you do, put this card into your hand as it resolves.)\nCreate a 1/1 black Rat creature token.',
    imageUri: 'https://cards.scryfall.io/large/front/3/1/3132c128-e0bd-4524-9526-914b3c7181fc.jpg?1783946562',
    spell: {
      timing: 'sorcery',
      buyback: { cost: 4 },
      effects: [
        { type: 'create_token', cardId: 'token_rat', name: 'Rat', kind: 'creature', power: 1, toughness: 1, colors: ['B'], types: ['Creature'], subtypes: ['Rat'] },
      ],
    },
    artId: 535, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // Token: 1/1 black Rat (Lab Rats)
  defineCard({
    id: 'token_rat', name: 'Rat', set: null,
    types: ['Creature', 'Token'], subtypes: ['Rat'], colors: ['B'],
    power: 1, toughness: 1, manaCost: 0,
    imageUri: 'https://cards.scryfall.io/large/front/3/1/3132c128-e0bd-4524-9526-914b3c7181fc.jpg?1783946562',
    support: { status: 'limited', limitations: [] },
    notes: ['token'],
  }),

  // 3. Anthem of Champions (FDN) — {G}{W} Enchantment: Creatures you control get +1/+1.
  defineCard({
    id: 'anthem-of-champions', name: 'Anthem of Champions', set: 'FDN',
    types: ['Enchantment'], colors: ['G', 'W'], manaCost: 2,
    oracleText: 'Creatures you control get +1/+1.',
    imageUri: 'https://cards.scryfall.io/large/front/4/2/42fe3a40-9cbe-4235-86f9-32576aaebba8.jpg?1783909093',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.static,
        pump: { power: 1, toughness: 1 },
        scope: { affects: 'all_creatures_you_control' },
      }),
    ],
    artId: 231, plan: 'Theros',
    support: { status: 'supported', limitations: [] },
  }),

  // 4. Goblin Deathraiders (ALA) — {B}{R} 3/1: Trample
  defineCard({
    id: 'goblin-deathraiders', name: 'Goblin Deathraiders', set: 'ALA',
    types: ['Creature'], subtypes: ['Goblin', 'Warrior'], colors: ['B', 'R'],
    power: 3, toughness: 1, manaCost: 2,
    oracleText: 'Trample',
    imageUri: 'https://cards.scryfall.io/large/front/7/6/76fd1253-1af1-42a7-9875-4d6ac9ce722c.jpg?1783942545',
    keywords: ['trample'],
    artId: 8, plan: 'Alara',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Fertile Thicket (BFZ) — Land: enters tapped, ETB reveal top 5 for basic land
  defineCard({
    id: 'fertile-thicket', name: 'Fertile Thicket', set: 'BFZ',
    types: ['Land'], colors: [],
    oracleText: 'This land enters tapped.\nWhen this land enters, you may look at the top five cards of your library. If you do, reveal up to one basic land card from among them, then put that card on top of your library and the rest on the bottom in any order.\n{T}: Add {G}.',
    imageUri: 'https://cards.scryfall.io/large/front/1/5/15231a9b-1956-4ff6-b637-942444d3349f.jpg?1783938175',
    entersTapped: true,
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{ type: 'fertile_thicket_reveal' }],
      }),
      // M193/A: Oracle „{T}: Add {G}" — zdolnosci many NIE BYLO w danych ani
      // w MANA_SOURCE_MAP, wiec land byl zrodlem bezbarwnym: dokladnie objaw
      // ze zgloszenia wlasciciela (pip {G} nie do oplacenia).
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        effect: { type: 'add_mana', amount: 1, colors: ['G'] },
      }),
    ],
    artId: 273, plan: 'Zendikar',
    support: { status: 'supported', limitations: [] },
  }),

  // 6. Reassembling Skeleton (M19) — {1}{B} 1/1: {1}{B}: Return from graveyard tapped
  defineCard({
    id: 'reassembling-skeleton', name: 'Reassembling Skeleton', set: 'M19',
    types: ['Creature'], subtypes: ['Skeleton', 'Warrior'], colors: ['B'],
    power: 1, toughness: 1, manaCost: 2,
    oracleText: '{1}{B}: Return this card from your graveyard to the battlefield tapped.',
    imageUri: 'https://cards.scryfall.io/large/front/a/3/a3d4ac21-2203-45f4-b5f2-dc186ccdbe69.jpg?1783934563',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2, colors: ['B'] },
        fromGraveyard: true,
        effect: { type: 'return_to_battlefield_tapped' },
      }),
    ],
    artId: 248, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 7. Idyllic Grange (ELD) — Land — Plains: enters tapped unless 3+ other Plains,
  //    ETB +1/+1 counter on target creature when enters untapped
  defineCard({
    id: 'idyllic-grange', name: 'Idyllic Grange', set: 'ELD',
    types: ['Land'], subtypes: ['Plains'], colors: [],
    oracleText: '({T}: Add {W}.)\nThis land enters tapped unless you control three or more other Plains.\nWhen this land enters untapped, put a +1/+1 counter on target creature you control.',
    imageUri: 'https://cards.scryfall.io/large/front/c/a/ca2c611c-3a6f-44b0-9daa-837a465845e0.jpg?1783932578',
    // enters tapped UNLESS 3+ inne Plains — flaga obowiązkowa przy warunku
    // (playLand czyta entersTapped; warunek ją tylko uchyla) — bug C 2026-08-10.
    entersTapped: true,
    entersTappedCondition: { minOtherPlains: 3 },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: {
          event: 'enter_battlefield',
          condition: { enteredUntapped: true },
          requiresTarget: { type: 'creature_you_control' },
        },
        effect: [{ type: 'add_counter', counter: '+1/+1', amount: 1 }],
      }),
    ],
    artId: 187, plan: 'Eldraine',
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Deadly Recluse (M10) — {1}{G} 1/2: Reach, Deathtouch
  defineCard({
    id: 'deadly-recluse', name: 'Deadly Recluse', set: 'M10',
    types: ['Creature'], subtypes: ['Spider'], colors: ['G'],
    power: 1, toughness: 2, manaCost: 2,
    oracleText: 'Reach (This creature can block creatures with flying.)\nDeathtouch (Any amount of damage this deals to a creature is enough to destroy it.)',
    imageUri: 'https://cards.scryfall.io/large/front/6/a/6ab810f1-21d6-4a98-b77a-e455370aa6cc.jpg?1783942364',
    keywords: ['reach', 'deathtouch'],
    artId: 375, plan: 'Śródziemie',
    support: { status: 'supported', limitations: [] },
  }),

  // 9. Benevolent Blessing (CMR) — {1}{W} Aura: Flash, Enchant creature,
  //    choose color on entry, protection from chosen color
  defineCard({
    id: 'benevolent-blessing', name: 'Benevolent Blessing', set: 'CMR',
    types: ['Enchantment'], subtypes: ['Aura'], colors: ['W'], manaCost: 2,
    oracleText: 'Flash\nEnchant creature\nAs this Aura enters, choose a color.\nEnchanted creature has protection from the chosen color. This effect doesn\'t remove Auras and Equipment you control that are already attached to it.',
    imageUri: 'https://cards.scryfall.io/large/front/0/d/0d5c2401-da2c-46f9-b850-f37edcbb85cd.jpg?1783928890',
    keywords: ['flash'],
    aura: { enchant: 'creature', chooseColor: true, keepOwnAttachmentsOnProtection: true },
    // Protection from chosen color: when aura enters, player chooses a color.
    // The chosenColor is set on the aura permanent, and effectiveKeywords
    // computes protectionFromColors from it (attachments.js + permanents.js).
    artId: 422, plan: 'Śródziemie',
    support: { status: 'supported', limitations: [] },
  }),

  // 10. Springbloom Druid (MH1) — {2}{G} 1/1: ETB sacrifice land → search 2 basic lands tapped
  defineCard({
    id: 'springbloom-druid', name: 'Springbloom Druid', set: 'MH1',
    types: ['Creature'], subtypes: ['Elf', 'Druid'], colors: ['G'],
    power: 1, toughness: 1, manaCost: 3,
    oracleText: 'When this creature enters, you may sacrifice a land. If you do, search your library for up to two basic land cards, put them onto the battlefield tapped, then shuffle.',
    imageUri: 'https://cards.scryfall.io/large/front/6/1/6161d2ed-7cff-4c90-9e74-1d179a6c1498.jpg?1783933092',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{ type: 'springbloom_sacrifice_search' }],
      }),
    ],
    artId: 470, plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
  }),

  // =========================================================================
  // Batch 26 — 10 kart (2026-08-09)
  // =========================================================================

  // 1. Kabira Vindicator (ROE) — {3}{W} 2/4 Human Knight: Level up {2}{W}, LEVEL 2-4 3/6 other +1/+1, LEVEL 5+ 4/8 other +2/+2
  defineCard({
    id: 'kabira-vindicator', name: 'Kabira Vindicator', set: 'ROE',
    types: ['Creature'], subtypes: ['Human', 'Knight'], colors: ['W'],
    power: 2, toughness: 4, manaCost: 4,
    oracleText: 'Level up {2}{W} ({2}{W}: Put a level counter on this. Level up only as a sorcery.)\nLEVEL 2-4\n3/6\nOther creatures you control get +1/+1.\nLEVEL 5+\n4/8\nOther creatures you control get +2/+2.',
    imageUri: 'https://cards.scryfall.io/large/front/6/d/6d31551a-ab7a-4e49-b545-77afb3be72d3.jpg?1783942007',
    keywords: ['level_up'],
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 3, colors: ['W'] },
        timing: 'sorcery',
        effect: { type: 'add_counter', counter: 'level', amount: 1 },
      }),
      // Self P/T for level 2-4: 2/4 -> 3/6 => +1/+2
      createAbility({
        type: ABILITY_TYPE.static,
        condition: { minLevel: 2, maxLevel: 4 },
        pump: { power: 1, toughness: 2 },
      }),
      // Self P/T for level 5+: 2/4 -> 4/8 => +2/+4
      createAbility({
        type: ABILITY_TYPE.static,
        condition: { minLevel: 5 },
        pump: { power: 2, toughness: 4 },
      }),
      // Other creatures +1/+1 for level 2-4
      createAbility({
        type: ABILITY_TYPE.static,
        condition: { minLevel: 2, maxLevel: 4 },
        pump: { power: 1, toughness: 1 },
        scope: { affects: 'other_creatures_you_control' },
      }),
      // Other creatures +2/+2 for level 5+
      createAbility({
        type: ABILITY_TYPE.static,
        condition: { minLevel: 5 },
        pump: { power: 2, toughness: 2 },
        scope: { affects: 'other_creatures_you_control' },
      }),
    ],
    artId: 143, plan: 'Zendikar',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Great Furnace (MRD) — Artifact Land: {T}: Add {R}
  defineCard({
    id: 'great-furnace', name: 'Great Furnace', set: 'MRD',
    types: ['Artifact', 'Land'], colors: [],
    oracleText: '{T}: Add {R}.',
    imageUri: 'https://cards.scryfall.io/large/front/2/8/2877281d-c85d-4f32-b40d-828b93c4ee8e.jpg?1783944493',
    artId: 97, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Bomat Bazaar Barge (KLD) — {4} 5/5 Vehicle: ETB draw, Crew 3
  defineCard({
    id: 'bomat-bazaar-barge', name: 'Bomat Bazaar Barge', set: 'KLD',
    types: ['Artifact'], subtypes: ['Vehicle'], colors: [],
    power: 5, toughness: 5, manaCost: 4,
    oracleText: 'When this Vehicle enters, draw a card.\nCrew 3 (Tap any number of creatures you control with total power 3 or more: This Vehicle becomes an artifact creature until end of turn.)',
    imageUri: 'https://cards.scryfall.io/large/front/0/f/0f32be75-979d-43a9-9132-2cf013ddaf3b.jpg?1783937161',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: { type: 'draw_cards', amount: 1 },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        // Crew (CR 701.36) — jak wyżej: instant, bez „Activate only as a
        // sorcery" w Oracle (audyt Batchu 26, M65).
        cost: { crewPower: 3 },
        effect: { type: 'animate_permanent_until_end_of_turn', power: 5, toughness: 5, typesAdd: ['Creature'] },
      }),
    ],
    artId: 541, plan: 'Kaladesh',
    support: { status: 'supported', limitations: [] },
  }),

  // 4. Index (APC) — {U} Sorcery: Look at top 5, put back any order
  defineCard({
    id: 'index', name: 'Index', set: 'APC',
    types: ['Sorcery'], colors: ['U'], manaCost: 1,
    oracleText: 'Look at the top five cards of your library, then put them back in any order.',
    imageUri: 'https://cards.scryfall.io/large/front/6/3/637ebd57-ba92-48ff-9ad4-d40dad2ff418.jpg?1783945353',
    spell: {
      timing: 'sorcery',
      effects: [{ type: 'index_look' }],
    },
    artId: 179, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Bladed Sentinel (MBS) — {4} 2/4 Artifact Creature: {W}: vigilance until EOT
  defineCard({
    id: 'bladed-sentinel', name: 'Bladed Sentinel', set: 'MBS',
    types: ['Artifact', 'Creature'], subtypes: ['Construct'], colors: [],
    power: 2, toughness: 4, manaCost: 4,
    oracleText: '{W}: This creature gains vigilance until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/6/9/69959c54-1350-4c64-8e5a-fc8447bb979c.jpg?1783941370',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 1, colors: ['W'] },
        effect: { type: 'grant_keywords_until_end_of_turn', keywords: ['vigilance'] },
      }),
    ],
    artId: 73, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  // 6. Might of the Masses (2XM) — {G} Instant: Target creature +1/+1 per creature you control
  defineCard({
    id: 'might-of-the-masses', name: 'Might of the Masses', set: '2XM',
    types: ['Instant'], colors: ['G'], manaCost: 1,
    oracleText: 'Target creature gets +1/+1 until end of turn for each creature you control.',
    imageUri: 'https://cards.scryfall.io/large/front/9/9/9900f47d-e1ec-411d-92f3-aed8e01ee535.jpg?1783930143',
    spell: {
      timing: 'instant',
      targets: [{ type: 'creature' }],
      effects: [{ type: 'pump_by_creature_count', perCreature: 1 }],
    },
    artId: 268, plan: 'Zendikar',
    support: { status: 'supported', limitations: [] },
  }),

  // 7. Magic Damper (FIN) — {U} Instant: Target creature you control +1/+1 hexproof until EOT, untap it
  defineCard({
    id: 'magic-damper', name: 'Magic Damper', set: 'FIN',
    types: ['Instant'], colors: ['U'], manaCost: 1,
    oracleText: 'Target creature you control gets +1/+1 and gains hexproof until end of turn. Untap it.',
    imageUri: 'https://cards.scryfall.io/large/front/4/4/44921b2e-5938-4f63-92b9-0b719a2f8c68.jpg?1783906635',
    spell: {
      timing: 'instant',
      targets: [{ type: 'creature_you_control' }],
      effects: [
        { type: 'pump', power: 1, toughness: 1 },
        { type: 'grant_keywords_until_end_of_turn', keywords: ['hexproof'] },
        { type: 'untap_permanent' },
      ],
    },
    artId: 283, plan: 'Final Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Hecteyes (FIN) — {1}{B} 1/1 Ooze Horror: ETB each opponent discards 1
  defineCard({
    id: 'hecteyes', name: 'Hecteyes', set: 'FIN',
    types: ['Creature'], subtypes: ['Ooze', 'Horror'], colors: ['B'],
    power: 1, toughness: 1, manaCost: 2,
    oracleText: 'When this creature enters, each opponent discards a card.',
    imageUri: 'https://cards.scryfall.io/large/front/8/6/8680d052-c07b-4d9b-bda9-b5f69f44f424.jpg?1783906618',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: { type: 'discard_each_opponent', amount: 1 },
      }),
    ],
    artId: 439, plan: 'Final Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 9. Carapace Forger (SOM) — {1}{G} 2/2 Elf Artificer: Metalcraft +2/+2 if 3+ artifacts
  defineCard({
    id: 'carapace-forger', name: 'Carapace Forger', set: 'SOM',
    types: ['Creature'], subtypes: ['Elf', 'Artificer'], colors: ['G'],
    power: 2, toughness: 2, manaCost: 2,
    oracleText: 'Metalcraft — This creature gets +2/+2 as long as you control three or more artifacts.',
    imageUri: 'https://cards.scryfall.io/large/front/e/9/e9948e4c-d583-4fde-a305-df926cf00199.jpg?1783941719',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.static,
        condition: { minArtifactsControlled: 3 },
        pump: { power: 2, toughness: 2 },
      }),
    ],
    artId: 488, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  // 10. Lurking Green Dragon (CLB) — {3}{G} 4/4 Dragon Flying, can't attack unless defender has flying
  defineCard({
    id: 'lurking-green-dragon', name: 'Lurking Green Dragon', set: 'CLB',
    types: ['Creature'], subtypes: ['Dragon'], colors: ['G'],
    power: 4, toughness: 4, manaCost: 4, keywords: ['flying'],
    oracleText: 'Flying\nThis creature can\'t attack unless defending player controls a creature with flying.',
    imageUri: 'https://cards.scryfall.io/large/front/6/6/66de5a3e-7b08-438b-866e-9fce1a36b243.jpg?1783922710',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.static,
        cantAttackUnlessDefenderHasFlying: true,
      }),
    ],
    artId: 519, plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
  }),



  // =========================================================================
  // Batch 27 — 10 kart (2026-08-09)
  // =========================================================================

  // 1. Civilized Scholar (ISD) — DFC: {2}{U} 0/1 Human Advisor
  defineCard({
    id: 'civilized-scholar', name: 'Civilized Scholar', set: 'ISD',
    types: ['Creature'], subtypes: ['Human', 'Advisor'], colors: ['U'],
    power: 0, toughness: 1, manaCost: 3, keywords: ['transform'],
    oracleText: '{T}: Draw a card, then discard a card. If a creature card is discarded this way, untap this creature, then transform it.',
    imageUri: 'https://cards.scryfall.io/large/front/7/b/7bf864db-4754-433d-9d77-6695f78f6c09.jpg?1783940983',
    transformTo: 'homicidal-brute',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        // M67: draw 1 → decyzja odrzucenia → po odrzuceniu stwora untap+transform
        // (pendingDiscardChoice.onCreatureDiscard w resolve_discard_choice).
        effect: { type: 'draw_then_discard', amount: 1, transformOnCreatureDiscard: true },
      }),
    ],
    artId: 309, plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),
  // Tył Civilized Scholar — Homicidal Brute (ISD). Limited (nie taliowalna).
  defineCard({
    id: 'homicidal-brute', name: 'Homicidal Brute', set: 'ISD',
    types: ['Creature'], subtypes: ['Human', 'Mutant'], colors: ['R'],
    power: 5, toughness: 1, manaCost: 0, keywords: ['transform'],
    oracleText: 'At the beginning of your end step, if this creature didn\'t attack this turn, tap this creature, then transform it.',
    imageUri: 'https://cards.scryfall.io/large/back/7/b/7bf864db-4754-433d-9d77-6695f78f6c09.jpg?1783940983',
    transformTo: 'civilized-scholar',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'end_step', condition: { didntAttackThisTurn: true } },
        effect: [{ type: 'tap_permanent' }, { type: 'transform' }],
      }),
    ],
    artId: 180, plan: 'Innistrad',
    support: { status: 'limited', limitations: ['tylna strona transform — nie można umieścić w talii'] },
  }),

  // 2. Battle-Rattle Shaman (M21) — {3}{R} 2/2 Goblin Shaman
  defineCard({
    id: 'battle-rattle-shaman', name: 'Battle-Rattle Shaman', set: 'M21',
    types: ['Creature'], subtypes: ['Goblin', 'Shaman'], colors: ['R'],
    power: 2, toughness: 2, manaCost: 4,
    oracleText: 'At the beginning of combat on your turn, you may have target creature get +2/+0 until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/f/a/faca827d-0b35-48d7-acd6-13ecacc32b82.jpg?1783930695',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'beginning_of_combat', requiresTarget: { type: 'creature', optional: true } },
        effect: { type: 'pump', power: 2, toughness: 0 },
      }),
    ],
    artId: 367, plan: 'Zendikar',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Jeskai Devotee (TDM) — {1}{R} 2/2 Orc Monk
  defineCard({
    id: 'jeskai-devotee', name: 'Jeskai Devotee', set: 'TDM',
    types: ['Creature'], subtypes: ['Orc', 'Monk'], colors: ['R'],
    power: 2, toughness: 2, manaCost: 2,
    oracleText: 'Flurry — Whenever you cast your second spell each turn, this creature gets +1/+1 until end of turn.\n{1}: Add {U}, {R}, or {W}. Activate only once each turn.',
    imageUri: 'https://cards.scryfall.io/large/front/2/7/27f31f9c-7149-4608-9b18-b3530a2efd4a.jpg?1783907361',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'you_cast_second_spell_each_turn' },
        effect: { type: 'pump', power: 1, toughness: 1 },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 1 },
        oncePerTurn: true,
        effect: { type: 'add_mana', amount: 1, colors: ['U', 'R', 'W'] },
      }),
    ],
    artId: 20, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),

  // 4. High Stride (BLB) — {G} Instant
  defineCard({
    id: 'high-stride', name: 'High Stride', set: 'BLB',
    types: ['Instant'], colors: ['G'], manaCost: 1,
    oracleText: 'Target creature gets +1/+3 and gains reach until end of turn. Untap it.',
    imageUri: 'https://cards.scryfall.io/large/front/0/9/09c8cf4b-8e65-4a1c-b458-28b5ab56b390.jpg?1783910809',
    spell: {
      timing: 'instant',
      targets: [{ type: 'creature' }],
      effects: [
        { type: 'pump', power: 1, toughness: 3 },
        { type: 'grant_keywords_until_end_of_turn', keywords: ['reach'] },
        { type: 'untap_permanent' },
      ],
    },
    artId: 206, plan: 'Bloomburrow',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Inspiration (8ED) — {3}{U} Instant
  defineCard({
    id: 'inspiration', name: 'Inspiration', set: '8ED',
    types: ['Instant'], colors: ['U'], manaCost: 4,
    oracleText: 'Target player draws two cards.',
    imageUri: 'https://cards.scryfall.io/large/front/b/e/be039716-30fc-4f84-8f84-6019065560e4.jpg?1783944797',
    spell: {
      timing: 'instant',
      targets: [{ type: 'player' }],
      effects: [{ type: 'draw_cards', amount: 2, applyTo: 'target' }],
    },
    artId: 360, plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
  }),

  // 6. Minotaur Abomination (M14) — {4}{B}{B} 4/6 Zombie Minotaur (vanilla)
  defineCard({
    id: 'minotaur-abomination', name: 'Minotaur Abomination', set: 'M14',
    types: ['Creature'], subtypes: ['Zombie', 'Minotaur'], colors: ['B'],
    power: 4, toughness: 6, manaCost: 6,
    oracleText: '',
    imageUri: 'https://cards.scryfall.io/large/front/9/d/9dca75a1-443d-4f8e-b12b-2aada3a8e3e4.jpg?1783939921',
    artId: 296, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 7. Guildsworn Prowler (CLB) — {1}{B} 2/1 Tiefling Rogue Assassin
  defineCard({
    id: 'guildsworn-prowler', name: 'Guildsworn Prowler', set: 'CLB',
    types: ['Creature'], subtypes: ['Tiefling', 'Rogue', 'Assassin'], colors: ['B'],
    power: 2, toughness: 1, manaCost: 2, keywords: ['deathtouch'],
    oracleText: 'Deathtouch\nWhen this creature dies, if it wasn\'t blocking, draw a card.',
    imageUri: 'https://cards.scryfall.io/large/front/d/7/d7efb10f-c760-431c-8ac6-904965d850dc.jpg?1783922760',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'dies', condition: { notBlocking: true } },
        effect: { type: 'draw_cards', amount: 1 },
      }),
    ],
    artId: 311, plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Giant Spider (M19) — {3}{G} 2/4 Spider (reach)
  defineCard({
    id: 'giant-spider', name: 'Giant Spider', set: 'M19',
    types: ['Creature'], subtypes: ['Spider'], colors: ['G'],
    power: 2, toughness: 4, manaCost: 4, keywords: ['reach'],
    oracleText: 'Reach (This creature can block creatures with flying.)',
    imageUri: 'https://cards.scryfall.io/large/front/8/0/80996b0d-cd44-445e-96de-677e0018255c.jpg?1783934535',
    artId: 437, plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
  }),

  // 9. Scroll Thief (M13) — {2}{U} 1/3 Merfolk Rogue
  defineCard({
    id: 'scroll-thief', name: 'Scroll Thief', set: 'M13',
    types: ['Creature'], subtypes: ['Merfolk', 'Rogue'], colors: ['U'],
    power: 1, toughness: 3, manaCost: 3,
    oracleText: 'Whenever this creature deals combat damage to a player, draw a card.',
    imageUri: 'https://cards.scryfall.io/large/front/d/c/dc201a82-fb48-4bb4-b072-e206e6872aa5.jpg?1783940502',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'combat_damage_to_player' },
        effect: { type: 'draw_cards', amount: 1 },
      }),
    ],
    artId: 474, plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
  }),

  // 10. Force Away (KTK) — {1}{U} Instant
  defineCard({
    id: 'force-away', name: 'Force Away', set: 'KTK',
    types: ['Instant'], colors: ['U'], manaCost: 2,
    oracleText: 'Return target creature to its owner\'s hand.\nFerocious — If you control a creature with power 4 or greater, you may draw a card. If you do, discard a card.',
    imageUri: 'https://cards.scryfall.io/large/front/d/d/dda70b3e-4b70-404e-a579-41dd126be084.jpg?1783939088',
    spell: {
      timing: 'instant',
      targets: [{ type: 'creature' }],
      effects: [
        { type: 'bounce_permanent' },
        { type: 'ferocious_draw_discard' },
      ],
    },
    artId: 517, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),


  // =========================================================================
  // Batch 28 — 9 kart (2026-08-10); Moonscarred Werewolf zostaje tyłem DFC
  // =========================================================================

  // 1. Silumgar Butcher (DTK) — {4}{B} 3/3 Zombie Djinn (Exploit)
  defineCard({
    id: 'silumgar-butcher', name: 'Silumgar Butcher', set: 'DTK',
    types: ['Creature'], subtypes: ['Zombie', 'Djinn'], colors: ['B'],
    power: 3, toughness: 3, manaCost: 5,
    oracleText: 'Exploit (When this creature enters, you may sacrifice a creature.)\nWhen this creature exploits a creature, target creature gets -3/-3 until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/4/0/40cb67f7-b4e1-423b-8f55-d44ed383e778.jpg?1783938593',
    // Exploit (CR 702.110): opcjonalne poświęcenie przy wejściu (decyzja
    // kontrolera — resolve_exploit_choice); po poświęceniu trigger „exploits".
    exploit: { },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'exploits', requiresTarget: { type: 'creature' } },
        effect: { type: 'pump', power: -3, toughness: -3 },
      }),
    ],
    artId: 92, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Relic Robber (ZNR) — {2}{R} 2/2 Goblin Rogue (haste)
  defineCard({
    id: 'relic-robber', name: 'Relic Robber', set: 'ZNR',
    types: ['Creature'], subtypes: ['Goblin', 'Rogue'], colors: ['R'],
    power: 2, toughness: 2, manaCost: 3, keywords: ['haste'],
    oracleText: 'Haste\nWhenever this creature deals combat damage to a player, that player creates a 0/1 colorless Goblin Construct artifact creature token with \"This token can\'t block\" and \"At the beginning of your upkeep, this token deals 1 damage to you.\"',
    imageUri: 'https://cards.scryfall.io/large/front/4/5/4540205c-eee8-4db3-8757-710de874b313.jpg?1783929355',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'combat_damage_to_player' },
        // „That player creates a token" — kontroler tokenu to CEL (ofiara);
        // context triggera niesie damagedPlayerId.
        effect: {
          type: 'create_token', cardId: 'token_goblin_construct', name: 'Goblin Construct',
          kind: 'creature', power: 0, toughness: 1, colors: [], types: ['Artifact', 'Creature'],
          subtypes: ['Goblin', 'Construct'], controllerFromEvent: 'damagedPlayerId',
          // „This token can't block" (CR 702.16e — stała cecha tokenu).
          cantBlock: true,
          // „At the beginning of your upkeep, this token deals 1 damage to you."
          abilities: [{
            type: 'triggered', trigger: { event: 'upkeep' },
            effect: { type: 'damage_to_controller', amount: 1 },
          }],
        },
      }),
    ],
    artId: 109, plan: 'Zendikar',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Flurry of Wings (ARB) — {G}{W}{U} Instant
  defineCard({
    id: 'flurry-of-wings', name: 'Flurry of Wings', set: 'ARB',
    types: ['Instant'], colors: ['G', 'W', 'U'], manaCost: 3,
    oracleText: 'Create X 1/1 white Bird Soldier creature tokens with flying, where X is the number of attacking creatures.',
    imageUri: 'https://cards.scryfall.io/large/front/d/b/dbabaf1d-0220-438d-8263-e23d8010fe24.jpg?1783942412',
    spell: {
      timing: 'instant',
      effects: [{
        type: 'create_token', cardId: 'token_bird_soldier', name: 'Bird Soldier',
        kind: 'creature', power: 1, toughness: 1, colors: ['W'],
        types: ['Creature'], subtypes: ['Bird', 'Soldier'], keywords: ['flying'],
        amount: 'attacking_creatures_count',
      }],
    },
    artId: 112, plan: 'Alara',
    support: { status: 'supported', limitations: [] },
  }),

  // 4. Expose to Daylight (RNA) — {2}{W} Instant
  defineCard({
    id: 'expose-to-daylight', name: 'Expose to Daylight', set: 'RNA',
    types: ['Instant'], colors: ['W'], manaCost: 3,
    oracleText: 'Destroy target artifact or enchantment. Scry 1.',
    imageUri: 'https://cards.scryfall.io/large/front/0/9/094c2ac3-040f-41fe-9a37-c037d90baec0.jpg?1783933723',
    spell: {
      timing: 'instant',
      targets: [{ type: 'artifact_or_enchantment' }],
      effects: [
        { type: 'destroy_permanent' },
        { type: 'scry', amount: 1 },
      ],
    },
    artId: 271, plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Etherium Abomination (ARB) — {3}{U}{B} 4/3 Artifact Creature (Unearth)
  defineCard({
    id: 'etherium-abomination', name: 'Etherium Abomination', set: 'ARB',
    types: ['Artifact', 'Creature'], subtypes: ['Horror'], colors: ['B', 'U'],
    power: 4, toughness: 3, manaCost: 5,
    oracleText: 'Unearth {1}{U}{B} ({1}{U}{B}: Return this card from your graveyard to the battlefield. It gains haste. Exile it at the beginning of the next end step or if it would leave the battlefield. Unearth only as a sorcery.)',
    imageUri: 'https://cards.scryfall.io/large/front/3/1/312bbd63-d6ff-4da5-868f-ed68cbc12d43.jpg?1783942438',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        timing: 'sorcery',
        cost: { mana: 2, colors: ['U', 'B'] },
        fromGraveyard: true,
        effect: { type: 'unearth_return' },
      }),
    ],
    artId: 36, plan: 'Alara',
    support: { status: 'supported', limitations: [] },
  }),

  // 6. Awaken the Bear (KTK) — {2}{G} Instant
  defineCard({
    id: 'awaken-the-bear', name: 'Awaken the Bear', set: 'KTK',
    types: ['Instant'], colors: ['G'], manaCost: 3,
    oracleText: 'Target creature gets +3/+3 and gains trample until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/8/0/803a6ac7-9327-4c2f-b023-93f5f65f83b8.jpg?1783939068',
    spell: {
      timing: 'instant',
      targets: [{ type: 'creature' }],
      effects: [
        { type: 'pump', power: 3, toughness: 3 },
        { type: 'grant_keywords_until_end_of_turn', keywords: ['trample'] },
      ],
    },
    artId: 173, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),

  // 7. Security Rhox (SNC) — {2}{R}{G} 5/4 Rhino Warrior (alternatywny koszt ze Skarbów)
  defineCard({
    id: 'security-rhox', name: 'Security Rhox', set: 'SNC',
    types: ['Creature'], subtypes: ['Rhino', 'Warrior'], colors: ['G', 'R'],
    power: 5, toughness: 4, manaCost: 4,
    oracleText: 'You may pay {R}{G} rather than pay this spell\'s mana cost. Spend only mana produced by Treasures to cast it this way.',
    imageUri: 'https://cards.scryfall.io/large/front/0/0/0050dd40-9a18-41e4-97e6-fce5bf220ccf.jpg?1783923072',
    // M69: alternatywny koszt {R}{G} płatny WYŁĄCZNIE maną ze Skarbów.
    treasureAltCost: { mana: 2, colors: ['R', 'G'] },
    artId: 71, plan: 'New Capenna',
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Dreams of Steel and Oil (BRO) — {B} Sorcery
  defineCard({
    id: 'dreams-of-steel-and-oil', name: 'Dreams of Steel and Oil', set: 'BRO',
    types: ['Sorcery'], colors: ['B'], manaCost: 1,
    oracleText: 'Target opponent reveals their hand. You choose an artifact or creature card from it, then choose an artifact or creature card from their graveyard. Exile the chosen cards.',
    imageUri: 'https://cards.scryfall.io/large/front/2/6/261ac92e-c61a-4c11-aa6a-9ae1cb703e5c.jpg?1783920092',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'player', opponent: true }],
      effects: [{ type: 'reveal_hand_choose_exile' }],
    },
    artId: 421, plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
  }),

  // 9. Tenth District Veteran (RNA) — {2}{W} 2/3 Human Soldier (vigilance)
  defineCard({
    id: 'tenth-district-veteran', name: 'Tenth District Veteran', set: 'RNA',
    types: ['Creature'], subtypes: ['Human', 'Soldier'], colors: ['W'],
    power: 2, toughness: 3, manaCost: 3, keywords: ['vigilance'],
    oracleText: 'Vigilance\nWhenever this creature attacks, untap another target creature you control.',
    imageUri: 'https://cards.scryfall.io/large/front/e/f/ef573e92-3106-4b42-90e8-0e165de0659f.jpg?1783933715',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'attacks', requiresTarget: { type: 'creature_you_control' } },
        effect: { type: 'untap_permanent' },
      }),
    ],
    artId: 516, plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
  }),

  // Tokeny Batchu 28
  defineCard({
    id: 'token_bird_soldier', name: 'Bird Soldier', set: null,
    imageUri: 'https://cards.scryfall.io/large/front/b/7/b7b55dcf-ae63-4b84-8d39-80b5a6de3c1a.jpg?1783942409', // M157/B: token ze Scryfall
    types: ['Creature', 'Token'], subtypes: ['Bird', 'Soldier'], colors: ['W'],
    keywords: ['flying'], power: 1, toughness: 1, manaCost: 0,
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Flurry of Wings'] },
  }),
  defineCard({
    id: 'token_goblin_construct', name: 'Goblin Construct', set: null,
    imageUri: 'https://cards.scryfall.io/large/front/b/2/b24a63e2-c2b3-43f8-a15a-68886bec7d60.jpg?1783929495', // M157/B: token ze Scryfall
    types: ['Artifact', 'Creature', 'Token'], subtypes: ['Goblin', 'Construct'], colors: [],
    power: 0, toughness: 1, manaCost: 0,
    oracleText: 'This token can\'t block.\nAt the beginning of your upkeep, this token deals 1 damage to you.',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'upkeep' },
        effect: { type: 'damage_to_controller', amount: 1 },
      }),
    ],
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Relic Robber'] },
  }),

  // =========================================================================
  // Batch 29 (10 kart, 2026-08-11) — lista właściciela
  // Mournful Zombie, Necrosquito, Curiosity, Veiled Ascension, Angelic
  // Benediction, Frontline War-Rager, Lash of the Balrog, Fireball,
  // Spread the Sickness, Warmaker Gunship. Dane Oracle w docs/cards/scryfall-*
  // (set=). artId i plan ze słownika tools/collection-art-ids.csv.
  // =========================================================================

  // 1. Mournful Zombie (APC) {2}{B} 2/1 — {W}, {T}: target player gains 1 life.
  defineCard({
    id: 'mournful-zombie', name: 'Mournful Zombie', set: 'APC',
    types: ['Creature'], subtypes: ['Zombie'], colors: ['B'],
    power: 2, toughness: 1, manaCost: 3,
    oracleText: '{W}, {T}: Target player gains 1 life.',
    imageUri: 'https://cards.scryfall.io/large/front/9/b/9ba12fb1-de8c-46c6-b33f-e0580ed2a3ee.jpg?1783945349',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true, mana: 1, colors: ['W'] },
        targets: [{ type: 'player' }],
        effect: { type: 'gain_life_target', amount: 1 },
      }),
    ],
    artId: 172, plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Necrosquito (ONE) {3}{B} 0/0 flying — enters 2 oil; +1/+1 per oil;
  //    another creature/artifact you control dies -> oil counter.
  defineCard({
    id: 'necrosquito', name: 'Necrosquito', set: 'ONE',
    types: ['Creature'], subtypes: ['Phyrexian', 'Insect'], colors: ['B'],
    keywords: ['flying'], power: 0, toughness: 0, manaCost: 4,
    entersWithCounters: { oil: 2 },
    oracleText: 'Flying\nThis creature enters with two oil counters on it.\nThis creature gets +1/+1 for each oil counter on it.\nWhenever another creature or artifact you control is put into a graveyard from the battlefield, put an oil counter on this creature.',
    imageUri: 'https://cards.scryfall.io/large/front/7/2/72af72d2-5995-4cad-82f1-e2d0c465d6f1.jpg?1783918044',
    abilities: [
      // Static: „This creature gets +1/+1 for each oil counter on it."
      // (CR 604.3) — dynamiczny pump liczony w staticBonuses (oil_counters);
      // sam licznik oil nie daje P/T (audyt PR #41, B5).
      createAbility({
        type: ABILITY_TYPE.static,
        pump: { power: 'oil_counters', toughness: 'oil_counters' },
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'other_permanent_you_control_dies' },
        effect: { type: 'add_counter', counter: 'oil', amount: 1 },
      }),
    ],
    artId: 346, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Curiosity (ISD) {U} Aura — Enchant creature; enchanted creature deals
  //    damage to an opponent -> you may draw a card.
  defineCard({
    id: 'curiosity', name: 'Curiosity', set: 'ISD',
    types: ['Enchantment'], subtypes: ['Aura'], colors: ['U'], manaCost: 1,
    oracleText: 'Enchant creature\nWhenever enchanted creature deals damage to an opponent, you may draw a card.',
    imageUri: 'https://cards.scryfall.io/large/front/c/5/c5a0be10-c20f-4ac0-89a5-1770ecf48aad.jpg?1783930457',
    aura: { enchant: 'creature' },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enchanted_creature_damage_to_opponent', mayFire: true },
        effect: { type: 'draw_cards', amount: 1 },
      }),
    ],
    artId: 428, plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
  }),

  // 4. Veiled Ascension (MKC) {3}{W} Enchantment — enters: flying counter on
  //    each face-down creature you control; face-down enter with flying counter;
  //    upkeep: you may cloak top card.
  defineCard({
    id: 'veiled-ascension', name: 'Veiled Ascension', set: 'MKC',
    types: ['Enchantment'], colors: ['W'], manaCost: 4,
    oracleText: 'When this enchantment enters, put a flying counter on each face-down creature you control.\nFace-down creatures you control enter with a flying counter on them.\nAt the beginning of your upkeep, you may cloak the top card of your library.',
    imageUri: 'https://cards.scryfall.io/large/front/5/1/5196eb5b-9330-46f7-b6f7-9c1164ea27d7.jpg?1783913050',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: { type: 'add_flying_counter_to_face_down_you_control' },
      }),
      createAbility({
        type: ABILITY_TYPE.static,
        faceDownEnterFlyingCounter: true,
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'upkeep', mayFire: true },
        effect: { type: 'cloak' },
      }),
    ],
    artId: 57, plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Angelic Benediction (ALA) {3}{W} Enchantment — Exalted; attacks alone
  //    -> you may tap target creature.
  defineCard({
    id: 'angelic-benediction', name: 'Angelic Benediction', set: 'ALA',
    types: ['Enchantment'], colors: ['W'], manaCost: 4,
    keywords: ['exalted'],
    oracleText: 'Exalted (Whenever a creature you control attacks alone, that creature gets +1/+1 until end of turn.)\nWhenever a creature you control attacks alone, you may tap target creature.',
    imageUri: 'https://cards.scryfall.io/large/front/a/2/a2a782a3-cc30-47c2-aab3-18abcda3df0a.jpg?1783938785',
    abilities: [
      // Exalted: atakujący samotnie dostaje +1/+1 do końca tury.
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'attacks_alone' },
        effect: { type: 'exalted_pump', power: 1, toughness: 1 },
      }),
      // Druga zdolność: „you may tap target creature" przy samotnym ataku.
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'attacks_alone', requiresTarget: { type: 'creature', optional: true } },
        effect: { type: 'tap_permanent' },
      }),
    ],
    artId: 87, plan: 'Alara',
    support: { status: 'supported', limitations: [] },
  }),

  // 6. Frontline War-Rager (EOE) {2}{R} 2/3 — your end step: if 2+ tapped
  //    creatures you control, +1/+1 counter.
  defineCard({
    id: 'frontline-war-rager', name: 'Frontline War-Rager', set: 'EOE',
    types: ['Creature'], subtypes: ['Kavu', 'Soldier'], colors: ['R'],
    power: 2, toughness: 3, manaCost: 3,
    oracleText: 'At the beginning of your end step, if you control two or more tapped creatures, put a +1/+1 counter on this creature.',
    imageUri: 'https://cards.scryfall.io/large/front/f/a/fa232943-818b-4944-be60-2d80c806bf62.jpg?1783905954',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'end_step', condition: { minTappedCreaturesControlled: 2 } },
        effect: { type: 'add_counter', counter: '+1/+1', amount: 1 },
      }),
    ],
    artId: 358, plan: 'The Edge',
    support: { status: 'supported', limitations: [] },
  }),

  // 7. Lash of the Balrog (LTR) {B} Sorcery — additional cost sacrifice a
  //    creature OR pay {4}; destroy target creature.
  defineCard({
    id: 'lash-of-the-balrog', name: 'Lash of the Balrog', set: 'LTR',
    types: ['Sorcery'], colors: ['B'], manaCost: 1,
    oracleText: 'As an additional cost to cast this spell, sacrifice a creature or pay {4}.\nDestroy target creature.',
    imageUri: 'https://cards.scryfall.io/large/front/8/1/812fee97-e145-4458-b495-bc6ad227335b.jpg?1783916302',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'creature' }],
      additionalCost: { sacrificeCreature: true, orPayMana: 4 },
      effects: [{ type: 'destroy_permanent' }],
    },
    artId: 257, plan: 'Śródziemie',
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Fireball (X-cost, any number of targets, divided damage).
  defineCard({
    id: 'fireball', name: 'Fireball', set: 'JVC',
    types: ['Sorcery'], colors: ['R'], manaCost: 1,
    oracleText: 'This spell costs {1} more to cast for each target beyond the first.\nFireball deals X damage divided evenly, rounded down, among any number of targets.',
    imageUri: 'https://cards.scryfall.io/large/front/d/f/df45a43e-a5b7-4fd4-873b-7b3c021be198.jpg?1783922739',
    spell: { timing: 'sorcery', fireball: true, effects: [{ type: 'fireball_resolve' }] },
    artId: 436, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 9. Spread the Sickness (MBS) {4}{B} Sorcery — destroy target creature,
  //    then proliferate.
  defineCard({
    id: 'spread-the-sickness', name: 'Spread the Sickness', set: 'MBS',
    types: ['Sorcery'], colors: ['B'], manaCost: 5,
    oracleText: 'Destroy target creature, then proliferate.',
    imageUri: 'https://cards.scryfall.io/large/front/0/0/003bc8f1-f282-491c-984d-1ce7ac027053.jpg?1783938409',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'creature' }],
      effects: [
        { type: 'destroy_permanent' },
        { type: 'proliferate' },
      ],
    },
    artId: 506, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
    notes: ['proliferate kolejkuje pendingProliferate po destroy; gracz wybiera cele'],
  }),

  // =========================================================================
  // Batch 30 (10 kart, 2026-08-11) — lista właściciela
  // Banishment Decree, Crew Captain, Consume Spirit, Altar of the Goyf,
  // Instant Ramen, Inspiring Bard, Seismic Monstrosaur, Epic Experiment,
  // Gurmag Drowner, Wavecrash Triton. Dane Oracle ze Scryfall (set=),
  // artId ze słownika kolekcji.
  // =========================================================================

  // 1. Banishment Decree (MBS) {3}{W}{W} Instant — bounce to owner's library top
  defineCard({
    id: 'banishment-decree', name: 'Banishment Decree', set: 'MBS',
    types: ['Instant'], colors: ['W'], manaCost: 5,
    oracleText: "Put target artifact, creature, or enchantment on top of its owner's library.",
    imageUri: 'https://cards.scryfall.io/large/front/2/c/2c5f605c-9d16-493e-bc44-0e15bdf8c0bf.jpg?1783941394',
    spell: {
      timing: 'instant',
      targets: [{ type: 'artifact_or_creature_or_enchantment' }],
      effects: [{ type: 'bounce_to_library_top' }],
    },
    artId: 476, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Crew Captain (SNC) {B}{R}{G} 4/2 — Haste; indestructible while entered this turn
  defineCard({
    id: 'crew-captain', name: 'Crew Captain', set: 'SNC',
    types: ['Creature'], subtypes: ['Human', 'Warrior'], colors: ['B', 'G', 'R'],
    power: 4, toughness: 2, manaCost: 3, keywords: ['haste'],
    oracleText: 'Haste\nThis creature has indestructible as long as it entered this turn.',
    imageUri: 'https://cards.scryfall.io/large/front/9/9/99806615-2f4a-4fe4-82f8-83445ae93a97.jpg?1783923089',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.static,
        condition: { enteredThisTurn: true },
        keywords: ['indestructible'],
      }),
    ],
    artId: 14, plan: 'New Capenna',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Consume Spirit (MRD) {X}{1}{B} Sorcery — X damage to any target, gain X life
  defineCard({
    id: 'consume-spirit', name: 'Consume Spirit', set: 'MRD',
    types: ['Sorcery'], colors: ['B'], manaCost: 2,
    oracleText: 'Spend only black mana on X.\nConsume Spirit deals X damage to any target and you gain X life.',
    imageUri: 'https://cards.scryfall.io/large/front/f/3/f375a49c-806a-4d8b-9513-6b4afc19497b.jpg?1783944549',
    spell: {
      timing: 'sorcery',
      xCost: { cap: 15, black: true },
      targets: [{ type: 'any_target' }],
      effects: [
        { type: 'damage', amount: 'X' },
        { type: 'gain_life', amount: 'X' },
      ],
    },
    artId: 370, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  // 4. Altar of the Goyf (MH2) {5} Kindred Artifact — attacks alone pump + Lhurgoyf trample
  defineCard({
    id: 'altar-of-the-goyf', name: 'Altar of the Goyf', set: 'MH2',
    types: ['Kindred', 'Artifact'], subtypes: ['Lhurgoyf'], colors: [], manaCost: 5,
    oracleText: 'Whenever a creature you control attacks alone, it gets +X/+X until end of turn, where X is the number of card types among cards in all graveyards.\nLhurgoyf creatures you control have trample.',
    imageUri: 'https://cards.scryfall.io/large/front/e/0/e0b3a98f-2b3c-438b-b78c-eef8d917f68e.jpg?1783926806',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'attacks_alone' },
        effect: { type: 'buff_creature_until_end_of_turn', power: 'card_types_in_all_graveyards', toughness: 'card_types_in_all_graveyards' },
      }),
      createAbility({
        type: ABILITY_TYPE.static,
        scope: { affects: 'creatures_with_subtype', subtype: 'Lhurgoyf' },
        keywords: ['trample'],
      }),
    ],
    artId: 184, plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Instant Ramen (FIN) {2} Artifact — Food; Flash; ETB draw; {2},{T},sac: gain 3
  defineCard({
    id: 'instant-ramen', name: 'Instant Ramen', set: 'FIN',
    types: ['Artifact'], subtypes: ['Food'], colors: [], manaCost: 2,
    keywords: ['flash'],
    oracleText: 'Flash\nWhen this artifact enters, draw a card.\n{2}, {T}, Sacrifice this artifact: You gain 3 life.',
    imageUri: 'https://cards.scryfall.io/large/front/e/f/ef7011f4-fc08-4b15-973d-d15357cbe744.jpg?1783906556',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: { type: 'draw_cards', amount: 1 },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true, mana: 2, sacrificeSelf: true },
        effect: { type: 'gain_life', amount: 3 },
      }),
    ],
    artId: 500, plan: 'Final Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 6. Inspiring Bard (AFR) {3}{G} 3/3 — ETB choose one: +2/+2 target or gain 3 life
  defineCard({
    id: 'inspiring-bard', name: 'Inspiring Bard', set: 'AFR',
    types: ['Creature'], subtypes: ['Elf', 'Bard'], colors: ['G'],
    power: 3, toughness: 3, manaCost: 4,
    oracleText: 'When this creature enters, choose one —\n• Bardic Inspiration — Target creature gets +2/+2 until end of turn.\n• Song of Rest — You gain 3 life.',
    imageUri: 'https://cards.scryfall.io/large/front/0/b/0b33db66-d205-4164-b168-6084df562ebb.jpg?1783926461',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: {
          event: 'enter_battlefield',
          modes: [
            { name: 'Inspiracja barda', targets: [{ type: 'creature' }], effects: [{ type: 'pump', power: 2, toughness: 2 }] },
            { name: 'Pieśń odpoczynku', effects: [{ type: 'gain_life', amount: 3 }] },
          ],
        },
        effect: [],
      }),
    ],
    artId: 253, plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
  }),

  // 7. Seismic Monstrosaur (LCI) {4}{R}{R} 6/5 — Trample; {2}{R}, sac a land: draw; Mountaincycling {2}
  defineCard({
    id: 'seismic-monstrosaur', name: 'Seismic Monstrosaur', set: 'LCI',
    types: ['Creature'], subtypes: ['Dinosaur'], colors: ['R'],
    power: 6, toughness: 5, manaCost: 6, keywords: ['trample'],
    oracleText: 'Trample\n{2}{R}, Sacrifice a land: Draw a card.\nMountaincycling {2} ({2}, Discard this card: Search your library for a Mountain card, reveal it, put it into your hand, then shuffle.)',
    imageUri: 'https://cards.scryfall.io/large/front/9/8/98aeb9dc-18f9-4120-ac3d-226c62a1dc1d.jpg?1783913754',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 3, colors: ['R'], sacrificeLand: true },
        effect: { type: 'draw_cards', amount: 1 },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'cycling',
        cost: { mana: 2 },
        cycling: { subtypes: ['Mountain'] },
        effect: [],
      }),
    ],
    artId: 211, plan: 'Ixalan',
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Epic Experiment (OTC) {X}{U}{R} Sorcery — exile top X, cast inst/sorc MV<=X free, rest to grave
  defineCard({
    id: 'epic-experiment', name: 'Epic Experiment', set: 'OTC',
    types: ['Sorcery'], colors: ['R', 'U'], manaCost: 2,
    oracleText: "Exile the top X cards of your library. You may cast instant and sorcery spells with mana value X or less from among them without paying their mana costs. Then put all cards exiled this way that weren't cast into your graveyard.",
    imageUri: 'https://cards.scryfall.io/large/front/d/3/d3ad9626-3124-4ad6-9cac-49aa9c3ce88c.jpg?1783911901',
    spell: {
      timing: 'sorcery',
      xCost: { cap: 15 },
      targets: [],
      effects: [{ type: 'epic_experiment', amount: 'X' }],
    },
    artId: 434, plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
  }),

  // 9. Gurmag Drowner (DTK) {3}{U} 2/4 — Exploit; when exploits, look top 4, one to hand rest to grave
  defineCard({
    id: 'gurmag-drowner', name: 'Gurmag Drowner', set: 'DTK',
    types: ['Creature'], subtypes: ['Snake', 'Wizard'], colors: ['U'],
    power: 2, toughness: 4, manaCost: 4,
    oracleText: 'Exploit (When this creature enters, you may sacrifice a creature.)\nWhen this creature exploits a creature, look at the top four cards of your library. Put one of them into your hand and the rest into your graveyard.',
    imageUri: 'https://cards.scryfall.io/large/front/5/0/5087a664-6ed7-43a1-8851-71bbee204eb1.jpg?1783938607',
    exploit: {},
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'exploits' },
        effect: { type: 'look_top_put_one_hand_rest_grave', amount: 4 },
      }),
    ],
    artId: 465, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),

  // 10. Wavecrash Triton (THS) {2}{U} 1/4 — Heroic: tap creature opponent controls (no untap)
  defineCard({
    id: 'wavecrash-triton', name: 'Wavecrash Triton', set: 'THS',
    types: ['Creature'], subtypes: ['Merfolk', 'Wizard'], colors: ['U'],
    power: 1, toughness: 4, manaCost: 3,
    oracleText: "Heroic — Whenever you cast a spell that targets this creature, tap target creature an opponent controls. That creature doesn't untap during its controller's next untap step.",
    imageUri: 'https://cards.scryfall.io/large/front/7/3/7336ca1e-13ef-4e49-a526-3f285bc339bb.jpg?1783939786',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'spell_targets_this_creature', requiresTarget: { type: 'creature_opponent_controls' } },
        effect: [{ type: 'tap_permanent' }, { type: 'dont_untap_next_untap_step' }],
      }),
    ],
    artId: 508, plan: 'Theros',
    support: { status: 'supported', limitations: [] },
  }),

  // 10. Warmaker Gunship (EOE) {2}{R} 4/3 Artifact Spacecraft — enters: deals
  //     damage = artifacts you control to target creature an opponent controls;
  //     Station (tap another creature: charge = its power; 6+ artifact creature);
  //     6+ Flying.
  defineCard({
    id: 'warmaker-gunship', name: 'Warmaker Gunship', set: 'EOE',
    types: ['Artifact'], subtypes: ['Spacecraft'], colors: ['R'],
    power: 4, toughness: 3, manaCost: 3,
    station: { threshold: 6, keywords: ['flying'] },
    oracleText: 'When this Spacecraft enters, it deals damage equal to the number of artifacts you control to target creature an opponent controls.\nStation (Tap another creature you control: Put charge counters equal to its power on this Spacecraft. Station only as a sorcery. It\'s an artifact creature at 6+.)\n6+ | Flying',
    imageUri: 'https://cards.scryfall.io/large/front/9/e/9e5957f4-1cae-4989-8b40-27fc6e2fcf5e.jpg?1783905944',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'creature_opponent_controls' } },
        effect: { type: 'damage', amount: 'artifacts_you_control' },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'station',
        cost: { tapOtherCreature: true },
        timing: 'sorcery',
        effect: [{ type: 'station_counters', counter: 'charge' }],
      }),
    ],
    artId: 515, plan: 'The Edge',
    support: { status: 'supported', limitations: [] },
  }),

  // =========================================================================
  // Batch 31 (10 kart, 2026-08-13) — lista właściciela
  // Furious Forebear, Jwari Shapeshifter, Floodhound, Inspire Awe,
  // Cogwork Assembler, Dread Warlock, Steel Sabotage, Warrior's Sword,
  // Awaken the Sleeper, Impact Tremors. Dane Oracle ze Scryfall (set=),
  // artId ze słownika kolekcji.
  // =========================================================================

  // 1. Furious Forebear (TDM) {1}{W} 3/1 Spirit Warrior — dies-in-graveyard
  defineCard({
    id: 'furious-forebear', name: 'Furious Forebear', set: 'TDM',
    types: ['Creature'], subtypes: ['Spirit', 'Warrior'], colors: ['W'],
    power: 3, toughness: 1, manaCost: 2,
    oracleText: "Whenever a creature you control dies while this card is in your graveyard, you may pay {1}{W}. If you do, return this card from your graveyard to your hand.",
    imageUri: 'https://cards.scryfall.io/large/front/a/4/a4f247b6-8212-4e78-a452-d2d3be228d8e.jpg?1783907413',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        // Trigger żyje na karcie w GROBIE; odpala się na śmierć kontrolowanego
        // stwora (skan w fireDeathTriggers). Opcjonalna płatność {1}{W}.
        trigger: { event: 'other_creature_you_control_dies', payMana: 2, payColors: ['W'] },
        effect: { type: 'return_source_from_graveyard_to_hand' },
      }),
    ],
    artId: 225, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Jwari Shapeshifter (WWK) {1}{U} 0/0 — copy Ally on enter
  defineCard({
    id: 'jwari-shapeshifter', name: 'Jwari Shapeshifter', set: 'WWK',
    types: ['Creature'], subtypes: ['Shapeshifter', 'Ally'], colors: ['U'],
    power: 0, toughness: 0, manaCost: 2,
    oracleText: 'You may have this creature enter as a copy of any Ally creature on the battlefield.',
    imageUri: 'https://cards.scryfall.io/large/front/5/8/587f91f6-b46e-4dd5-a86d-1048054dd3c0.jpg?1783942061',
    // „enter as a copy" — rozstrzygane przy wejściu (przed SBA), inaczej 0/0
    // ginie, zanim trigger ETB by się odpalił (CR 707 / 704.5e).
    enterAsCopy: { subtype: 'Ally' },
    artId: 227, plan: 'Zendikar',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Floodhound (MH2) {U} 1/2 — Investigate
  defineCard({
    id: 'floodhound', name: 'Floodhound', set: 'MH2',
    types: ['Creature'], subtypes: ['Elemental', 'Dog'], colors: ['U'],
    power: 1, toughness: 2, manaCost: 1,
    oracleText: "{3}, {T}: Investigate. (Create a Clue token. It's an artifact with \"{2}, Sacrifice this token: Draw a card.\")",
    imageUri: 'https://cards.scryfall.io/large/front/a/5/a5b1ac05-bd87-4605-8443-0469276e1e3a.jpg?1783926879',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 3, tap: true },
        effect: { type: 'investigate', amount: 1 },
      }),
    ],
    artId: 193, plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
  }),

  // 4. Inspire Awe (THB) {3}{G} Instant — prevent combat damage except enchanted/enchantment creatures + scry 2
  defineCard({
    id: 'inspire-awe', name: 'Inspire Awe', set: 'THB',
    types: ['Instant'], colors: ['G'], manaCost: 4,
    oracleText: 'Prevent all combat damage that would be dealt this turn except combat damage that would be dealt by enchanted creatures and enchantment creatures. Scry 2.',
    imageUri: 'https://cards.scryfall.io/large/front/b/2/b23c8b5a-2e18-4dd8-b236-5b1fd356f867.jpg?1783931537',
    spell: {
      timing: 'instant', targets: [],
      effects: [
        { type: 'prevent_combat_damage_except_enchanted' },
        { type: 'scry', amount: 2 },
      ],
    },
    artId: 433, plan: 'Theros',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Cogwork Assembler (2XM) {3} 2/3 — copy artifact token, haste, delayed exile
  defineCard({
    id: 'cogwork-assembler', name: 'Cogwork Assembler', set: '2XM',
    types: ['Artifact', 'Creature'], subtypes: ['Assembly-Worker'], colors: [],
    power: 2, toughness: 3, manaCost: 3,
    oracleText: "{7}: Create a token that's a copy of target artifact. That token gains haste. Exile it at the beginning of the next end step.",
    imageUri: 'https://cards.scryfall.io/large/front/e/4/e4bfde3f-f7d3-4902-b3cd-23f3fa53eff4.jpg?1783930116',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 7 },
        targets: [{ type: 'artifact' }],
        effect: { type: 'create_copy_token' },
      }),
    ],
    artId: 186, plan: 'Kaladesh',
    support: { status: 'supported', limitations: [] },
  }),

  // 6. Dread Warlock (M10) {1}{B}{B} 2/2 — can't be blocked except by black creatures
  defineCard({
    id: 'dread-warlock', name: 'Dread Warlock', set: 'M10',
    types: ['Creature'], subtypes: ['Human', 'Wizard', 'Warlock'], colors: ['B'],
    power: 2, toughness: 2, manaCost: 3,
    oracleText: "This creature can't be blocked except by black creatures.",
    imageUri: 'https://cards.scryfall.io/large/front/4/f/4f964660-c2db-4995-bb16-65383362cf19.jpg?1783942384',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.static,
        cantBeBlockedExceptByColors: ['B'],
      }),
    ],
    artId: 245, plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
  }),

  // 7. Steel Sabotage (2XM) {U} Instant — modal counter artifact spell / return artifact
  defineCard({
    id: 'steel-sabotage', name: 'Steel Sabotage', set: '2XM',
    types: ['Instant'], colors: ['U'], manaCost: 1,
    oracleText: 'Choose one —\n• Counter target artifact spell.\n• Return target artifact to its owner\'s hand.',
    imageUri: 'https://cards.scryfall.io/large/front/c/2/c227437d-1fc7-4a00-ace5-80795adc51d3.jpg?1783930190',
    spell: {
      timing: 'instant',
      modes: [
        { name: 'Kontra', targets: [{ type: 'artifact_spell_on_stack' }],
          effects: [{ type: 'counter_spell' }] },
        // M202/E (uwaga właściciela): „Odbicie” sugerowało kontrę; Oracle mówi
        // „Return target artifact to its owner's hand” — więc „Zwrot do ręki”.
        { name: 'Zwrot do ręki', targets: [{ type: 'artifact' }],
          effects: [{ type: 'bounce_permanent' }] },
      ],
    },
    artId: 168, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Warrior's Sword (FIN) {3}{R} Equipment — Job select, +3/+2 Warrior, Equip {5}
  defineCard({
    id: 'warriors-sword', name: "Warrior's Sword", set: 'FIN',
    types: ['Artifact'], subtypes: ['Equipment'], colors: ['R'], manaCost: 4,
    equipment: { equip: 5, pump: { power: 3, toughness: 2 }, subtypes: ['Warrior'] },
    oracleText: "Job select (When this Equipment enters, create a 1/1 colorless Hero creature token, then attach this to it.)\nEquipped creature gets +3/+2 and is a Warrior in addition to its other types.\nEquip {5} ({5}: Attach to target creature you control. Equip only as a sorcery.)",
    imageUri: 'https://cards.scryfall.io/large/front/c/b/cb98a7dd-542e-4448-b3bb-ff5d67a36535.jpg?1783906593',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: { type: 'job_select' },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'equip',
        cost: { mana: 5 },
        effect: [],
      }),
    ],
    artId: 435, plan: 'Final Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 9. Awaken the Sleeper (ONE) {3}{R} Sorcery — gain control until EOT + untap + haste + destroy equipment
  defineCard({
    id: 'awaken-the-sleeper', name: 'Awaken the Sleeper', set: 'ONE',
    types: ['Sorcery'], colors: ['R'], manaCost: 4,
    oracleText: "Gain control of target creature until end of turn. Untap that creature. It gains haste until end of turn. If it's equipped, you may destroy all Equipment attached to that creature.",
    imageUri: 'https://cards.scryfall.io/large/front/3/b/3b92f866-2522-4f2a-a5ca-7d01ad79b927.jpg?1783918036',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'creature' }],
      effects: [
        { type: 'gain_control_until_end_of_turn' },
        { type: 'destroy_equipment_attached' },
      ],
    },
    artId: 490, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  // 10. Impact Tremors (DTK) {1}{R} Enchantment — creature you control enters → 1 dmg each opponent
  defineCard({
    id: 'impact-tremors', name: 'Impact Tremors', set: 'DTK',
    types: ['Enchantment'], colors: ['R'], manaCost: 2,
    oracleText: 'Whenever a creature you control enters, this enchantment deals 1 damage to each opponent.',
    imageUri: 'https://cards.scryfall.io/large/front/5/6/56fb4035-197b-4d28-9bf7-bb62c304067e.jpg?1783938589',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'creature_you_control_enters' },
        effect: { type: 'damage_each_opponent', amount: 1 },
      }),
    ],
    artId: 479, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),


  // =========================================================================
  // Batch 32 (10 kart, 2026-08-13) — lista właściciela
  // Dream Twist, Voice of the Vermin, Setessan Skirmisher, Fathom Fleet
  // Cutthroat, Fierce Empath, Soulbright Flamekin, Rustvine Cultivator,
  // Trained Arynx, Nature's Embrace, Ballista Watcher. Dane Oracle ze Scryfall.
  // =========================================================================

  defineCard({
    id: 'dream-twist', name: 'Dream Twist', set: 'ISD',
    types: ['Instant'], colors: ['U'], manaCost: 1,
    oracleText: "Target player mills three cards.\\nFlashback {1}{U} (You may cast this card from your graveyard for its flashback cost. Then exile it.)",
    imageUri: 'https://cards.scryfall.io/large/front/d/5/d5dd8790-bfdf-427d-8e8d-a5c3a64a3063.jpg?1783940975',
    spell: {
      timing: 'instant',
      targets: [{ type: 'player' }],
      effects: [{ type: 'mill_cards', amount: 3 }],
      flashback: { cost: 2, colors: ['U'] },
    },
    artId: 50, plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'voice-of-the-vermin', name: 'Voice of the Vermin', set: 'SNC',
    types: ['Creature'], subtypes: ['Human', 'Citizen'], colors: ['G'],
    power: 2, toughness: 2, manaCost: 4,
    entersWithCounters: { shield: 1 },
    oracleText: "This creature enters with a shield counter on it.\\nWhenever this creature attacks, target creature you control has base power and toughness 4/4 until end of turn.",
    imageUri: 'https://cards.scryfall.io/large/front/b/f/bfe4e0eb-23a5-46a5-b719-5a6f9a1fc4ce.jpg?1783923096',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'attacks', requiresTarget: { type: 'creature_you_control' } },
        effect: { type: 'set_base_pt_until_end_of_turn', power: 4, toughness: 4 },
      }),
    ],
    artId: 96, plan: 'New Capenna',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'setessan-skirmisher', name: 'Setessan Skirmisher', set: 'THB',
    types: ['Creature'], subtypes: ['Human', 'Warrior'], colors: ['G'],
    power: 2, toughness: 1, manaCost: 2,
    oracleText: "Constellation — Whenever an enchantment you control enters, this creature gets +1/+1 until end of turn.",
    imageUri: 'https://cards.scryfall.io/large/front/4/6/46739993-6afe-428d-bf63-b57649e38a65.jpg?1783931527',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enchantment_you_control_enters' },
        effect: { type: 'pump', power: 1, toughness: 1 },
      }),
    ],
    artId: 454, plan: 'Theros',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'fathom-fleet-cutthroat', name: 'Fathom Fleet Cutthroat', set: 'M20',
    types: ['Creature'], subtypes: ['Human', 'Pirate'], colors: ['B'],
    power: 3, toughness: 3, manaCost: 4,
    oracleText: "When this creature enters, destroy target creature an opponent controls that was dealt damage this turn.",
    imageUri: 'https://cards.scryfall.io/large/front/6/5/65a7004c-1952-41df-b645-b34bcbc3e401.jpg?1783932994',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'creature_opponent_damaged_this_turn' } },
        effect: { type: 'destroy_permanent' },
      }),
    ],
    artId: 498, plan: 'Ixalan',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'fierce-empath', name: 'Fierce Empath', set: '2XM',
    types: ['Creature'], subtypes: ['Elf'], colors: ['G'],
    power: 1, toughness: 1, manaCost: 3,
    oracleText: "When this creature enters, you may search your library for a creature card with mana value 6 or greater, reveal it, put it into your hand, then shuffle.",
    imageUri: 'https://cards.scryfall.io/large/front/f/1/f13ddd38-397c-4119-8d55-50c7407883f9.jpg?1783930147',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: { type: 'search_library_to_hand', qualifier: { types: ['Creature'], minManaValue: 6 } },
      }),
    ],
    artId: 33, plan: 'Śródziemie',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'soulbright-flamekin', name: 'Soulbright Flamekin', set: 'MM2',
    types: ['Creature'], subtypes: ['Elemental', 'Shaman'], colors: ['R'],
    power: 2, toughness: 1, manaCost: 2,
    oracleText: "{2}: Target creature gains trample until end of turn. If this is the third time this ability has resolved this turn, you may add {R}{R}{R}{R}{R}{R}{R}{R}.",
    imageUri: 'https://cards.scryfall.io/large/front/6/d/6d622758-b182-4a2d-9746-9b03611c1212.jpg?1783938403',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2 },
        targets: [{ type: 'creature' }],
        effect: { type: 'grant_keywords_until_end_of_turn', keywords: ['trample'] },
        onNthResolve: { n: 3, may: true, effect: { type: 'add_mana', amount: 8, colors: ['R'] } },
      }),
    ],
    artId: 290, plan: 'Lorwyn',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'rustvine-cultivator', name: 'Rustvine Cultivator', set: 'ONE',
    types: ['Creature'], subtypes: ['Phyrexian', 'Elf', 'Druid'], colors: ['G'],
    power: 1, toughness: 2, manaCost: 1,
    oracleText: "{T}: Put an oil counter on this creature.\\n{T}, Remove an oil counter from this creature: Untap target land.",
    imageUri: 'https://cards.scryfall.io/large/front/6/b/6b71fd8f-e688-4210-bc5b-a3f19b5b3497.jpg?1783918010',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        effect: { type: 'add_counter', counter: 'oil', amount: 1 },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true, removeCounter: { name: 'oil', amount: 1 } },
        targets: [{ type: 'land' }],
        effect: { type: 'untap_permanent' },
      }),
    ],
    artId: 289, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'trained-arynx', name: 'Trained Arynx', set: 'OTJ',
    types: ['Creature'], subtypes: ['Cat', 'Beast', 'Mount'], colors: ['W'],
    power: 3, toughness: 1, manaCost: 2,
    oracleText: "Whenever this creature attacks while saddled, it gains first strike until end of turn. Scry 1.\\nSaddle 2 (Tap any number of other creatures you control with total power 2 or more: This Mount becomes saddled until end of turn. Saddle only as a sorcery.)",
    imageUri: 'https://cards.scryfall.io/large/front/e/f/ef32a5f8-f69d-47dc-a800-4f0ddf4eada5.jpg?1783911851',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'attacks', condition: { saddled: true } },
        effect: [
          { type: 'grant_keywords_until_end_of_turn', keywords: ['first_strike'] },
          { type: 'scry', amount: 1 },
        ],
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'saddle',
        timing: 'sorcery',
        cost: { saddlePower: 2 },
        effect: { type: 'set_saddled' },
      }),
    ],
    artId: 458, plan: 'Thunder Junction',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'natures-embrace', name: "Nature's Embrace", set: 'VOW',
    types: ['Enchantment'], subtypes: ['Aura'], colors: ['G'], manaCost: 3,
    oracleText: "Enchant creature or land\\nAs long as enchanted permanent is a creature, it gets +2/+2.\\nAs long as enchanted permanent is a land, it has \"{T}: Add two mana of any one color.\"",
    imageUri: 'https://cards.scryfall.io/large/front/3/9/39d757af-86fd-4f99-a09a-0f3898ed95f6.jpg?1783924808',
    aura: { enchantType: 'creature_or_land', pump: { power: 2, toughness: 2 }, grantMana: { amount: 2 } },
    artId: 491, plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'ballista-watcher', name: 'Ballista Watcher', set: 'VOW',
    types: ['Creature'], subtypes: ['Human', 'Soldier', 'Werewolf'], colors: ['R'],
    power: 4, toughness: 3, manaCost: 4, keywords: ['daybound'],
    oracleText: "{2}{R}, {T}: This creature deals 1 damage to any target.\\nDaybound (If a player casts no spells during their own turn, it becomes night next turn.)",
    imageUri: 'https://cards.scryfall.io/large/front/6/3/63d96c52-66ce-4b46-9a0b-7cd9a43f9253.jpg?1783924852',
    transformTo: 'ballista-wielder',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 3, tap: true, colors: ['R'] },
        targets: [{ type: 'any_target' }],
        effect: { type: 'damage', amount: 1 },
      }),
    ],
    artId: 504, plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'ballista-wielder', name: 'Ballista Wielder', set: 'VOW',
    types: ['Creature'], subtypes: ['Werewolf'], colors: ['R'],
    power: 5, toughness: 5, manaCost: 4, keywords: ['nightbound'],
    oracleText: "{2}{R}: This creature deals 1 damage to any target. A creature dealt damage this way can't block this turn.\\nNightbound (If a player casts at least two spells during their own turn, it becomes day next turn.)",
    imageUri: 'https://cards.scryfall.io/large/back/6/3/63d96c52-66ce-4b46-9a0b-7cd9a43f9253.jpg?1783924852',
    transformTo: 'ballista-watcher',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 3, colors: ['R'] },
        targets: [{ type: 'any_target' }],
        effect: [
          { type: 'damage', amount: 1 },
          { type: 'cant_block', ifDealtDamage: true },
        ],
      }),
    ],
    artId: 505, plan: 'Wiedźmin',
    support: { status: 'limited', limitations: ['tylna strona daybound/nightbound — nie można umieścić w talii'] },
  }),

  // =========================================================================
  // Batch 33 (2026-08-16, lista właściciela) — TRANSZA 1.
  // Somberwald Spider, Murder of Crows, Kazuul's Toll Collector.
  // Dane Oracle ze Scryfall (zweryfikowane w tej sesji). Pozostałe karty
  // z listy (Sagittars' Volley, Nightsnare, Spreading Insurrection, Tiller of
  // Flesh, Diplomatic Relations, Chill of the Grave, Spare from Evil)
  // wymagają nowych mechanik i mają rozpisane wdrożenie w
  // docs/plans/2026-08-16-m108-batch33.md.
  // =========================================================================
  defineCard({
    id: 'somberwald-spider', name: 'Somberwald Spider', set: 'ISD',
    types: ['Creature'], subtypes: ['Spider'], colors: ['G'],
    power: 2, toughness: 4, manaCost: 5, keywords: ['reach'],
    oracleText: 'Reach\nMorbid — This creature enters with two +1/+1 counters on it if a creature died this turn.',
    imageUri: 'https://cards.scryfall.io/large/front/4/3/43003ad7-2f42-4c85-8b00-77cbf3f50a7b.jpg?1783940910',
    // Morbid (CR 614.1c): liczniki WARUNKOWE przy wejściu — deskryptor
    // generyczny, warunek liczony w chwili wejścia (state.creatureDiedThisTurn).
    entersWithCountersIf: { morbid: true, counters: { '+1/+1': 2 } },
    artId: 107, plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'murder-of-crows', name: 'Murder of Crows', set: 'ISD',
    types: ['Creature'], subtypes: ['Bird'], colors: ['U'],
    power: 4, toughness: 4, manaCost: 5, keywords: ['flying'],
    oracleText: 'Flying\nWhenever another creature dies, you may draw a card. If you do, discard a card.',
    imageUri: 'https://cards.scryfall.io/large/front/1/c/1c7dc810-c4cb-4dca-ae06-d79daf8e1477.jpg',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        // „ANOTHER creature dies" — excludeSelf wyłącza własną śmierć źródła
        // (any_creature_dies odpala się domyślnie także dla niego).
        // „You may draw ... If you do, discard" = jedna opcjonalna decyzja.
        trigger: { event: 'any_creature_dies', excludeSelf: true, mayFire: true },
        effect: { type: 'draw_then_discard', amount: 1 },
      }),
    ],
    artId: 42, plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'kazuuls-toll-collector', name: "Kazuul's Toll Collector", set: '2XM',
    types: ['Creature'], subtypes: ['Ogre', 'Warrior'], colors: ['R'],
    power: 3, toughness: 2, manaCost: 3,
    oracleText: "{0}: Attach target Equipment you control to this creature. Activate only as a sorcery.",
    imageUri: 'https://cards.scryfall.io/large/front/7/3/7377e5a7-b479-48cc-8fbb-01af87c62566.jpg?1783930163',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 0 },
        timing: 'sorcery',
        targets: [{ type: 'equipment_you_control' }],
        effect: { type: 'attach_equipment_to_source' },
      }),
    ],
    artId: 472, plan: 'Zendikar',
    support: { status: 'supported', limitations: [] },
  }),

  // =========================================================================
  // Batch 33 — TRANSZA 2 (M109). Karty wymagające nowych mechanik silnika;
  // analiza: docs/plans/2026-08-16-m108-batch33.md.
  // =========================================================================

  defineCard({
    id: 'chill-of-the-grave', name: 'Chill of the Grave', set: 'VOW',
    types: ['Instant'], colors: ['U'], manaCost: 3,
    oracleText: "This spell costs {1} less to cast if you control a Zombie.\nTap target creature. It doesn't untap during its controller's next untap step.\nDraw a card.",
    imageUri: 'https://cards.scryfall.io/large/front/6/0/60222e91-a688-4113-a8c2-ab08f52bb6e1.jpg?1783924898',
    spell: {
      timing: 'instant',
      targets: [{ type: 'creature' }],
      // Warunkowa obniżka kosztu (CR 601.2f) — warunek generyczny
      // `controlsSubtype`, nie nazwa karty (ADR 0002).
      costReduction: { amount: 1, condition: { controlsSubtype: 'Zombie' } },
      effects: [
        { type: 'tap_permanent' },
        { type: 'dont_untap_next_untap_step' },
        { type: 'draw_cards', amount: 1 },
      ],
    },
    artId: 399, plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'diplomatic-relations', name: 'Diplomatic Relations', set: 'EOE',
    types: ['Instant'], colors: ['G'], manaCost: 3,
    oracleText: 'Target creature you control gets +1/+0 and gains vigilance until end of turn. It deals damage equal to its power to target creature an opponent controls.',
    imageUri: 'https://cards.scryfall.io/large/front/1/4/143e5853-9a31-4c8d-b21d-5ef120eb6952.jpg?1783904003',
    spell: {
      timing: 'instant',
      // DWA cele w jednym czarze: slot 0 (twój stwór) i slot 1 (stwór
      // przeciwnika); efekty wskazują slot przez targetIndex.
      targets: [{ type: 'creature_you_control' }, { type: 'creature_opponent_controls' }],
      effects: [
        { type: 'pump', power: 1, toughness: 0 },
        { type: 'grant_keywords_until_end_of_turn', keywords: ['vigilance'] },
        { type: 'damage_from_target_power', sourceTargetIndex: 0, targetIndex: 1 },
      ],
    },
    artId: 56, plan: 'The Edge',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'sagittars-volley', name: "Sagittars' Volley", set: 'RNA',
    types: ['Instant'], colors: ['G'], manaCost: 3,
    oracleText: "Destroy target creature with flying. Sagittars' Volley deals 1 damage to each creature with flying your opponents control.",
    imageUri: 'https://cards.scryfall.io/large/front/d/3/d3104cad-e684-4bd7-b26b-5aa862f7a2b3.jpg?1783933665',
    spell: {
      timing: 'instant',
      targets: [{ type: 'creature_with_keyword', keyword: 'flying' }],
      effects: [
        { type: 'destroy_permanent' },
        { type: 'damage_creatures_with_keyword', keyword: 'flying', amount: 1, opponentsOnly: true },
      ],
    },
    artId: 304, plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'nightsnare', name: 'Nightsnare', set: 'ORI',
    types: ['Sorcery'], colors: ['B'], manaCost: 4,
    oracleText: "Target opponent reveals their hand. You may choose a nonland card from it. If you do, that player discards that card. If you don't, that player discards two cards.",
    imageUri: 'https://cards.scryfall.io/large/front/3/9/391a1023-69e7-425c-ac54-987ba366f8f4.jpg?1783938338',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'opponent' }],
      effects: [{ type: 'reveal_hand_choose_discard', declineAmount: 2 }],
    },
    artId: 78, plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'tiller-of-flesh', name: 'Tiller of Flesh', set: 'MOM',
    types: ['Creature'], subtypes: ['Phyrexian', 'Knight'], colors: ['W'],
    power: 2, toughness: 4, manaCost: 4,
    oracleText: 'Whenever you cast a spell that targets one or more permanents, incubate 2. (Create an Incubator token with two +1/+1 counters on it and "{2}: Transform this token." It transforms into a 0/0 Phyrexian artifact creature.)',
    imageUri: 'https://cards.scryfall.io/large/front/4/9/49e206f2-1647-4456-8f2f-b67d053413e2.jpg?1783917044',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'you_cast_spell_targeting_permanent' },
        effect: { type: 'incubate', amount: 2 },
      }),
    ],
    artId: 201, plan: 'Ikoria',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'spare-from-evil', name: 'Spare from Evil', set: 'ISD',
    types: ['Instant'], colors: ['W'], manaCost: 2,
    oracleText: 'Creatures you control gain protection from non-Human creatures until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/d/0/d01b5d97-b5ae-42a7-944a-feb12febd63c.jpg?1783940984',
    spell: {
      timing: 'instant',
      targets: [],
      // Ochrona przed JAKOŚCIĄ (CR 702.16): deskryptor generyczny —
      // „stwór, który nie jest Człowiekiem".
      effects: [{
        type: 'grant_protection_until_end_of_turn',
        protection: { notSubtype: 'Human', kind: 'creature' },
      }],
    },
    artId: 478, plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'spreading-insurrection', name: 'Spreading Insurrection', set: 'MH2',
    types: ['Sorcery'], colors: ['R'], manaCost: 5,
    oracleText: 'Gain control of target creature you don\'t control until end of turn. Untap that creature. It gains haste until end of turn.\nStorm (When you cast this spell, copy it for each spell cast before it this turn. You may choose new targets for the copies.)',
    imageUri: 'https://cards.scryfall.io/large/front/f/1/f1c1918b-2f7a-4cab-9547-029ebc589000.jpg?1783926838',
    spell: {
      timing: 'sorcery',
      storm: true,
      targets: [{ type: 'creature_opponent_controls' }],
      effects: [{ type: 'gain_control_until_end_of_turn' }],
    },
    artId: 513, plan: 'Ixalan',
    support: { status: 'supported', limitations: [] },
  }),

  // =========================================================================
  // Batch 34 (2026-08-17, lista właściciela) — transza A: karty oparte
  // o mechaniki już obecne w silniku. Oracle ze Scryfalla.
  // =========================================================================

  defineCard({
    id: 'akrasan-squire', name: 'Akrasan Squire', set: 'ALA',
    types: ['Creature'], subtypes: ['Human', 'Soldier'], colors: ['W'],
    power: 1, toughness: 1, manaCost: 1, keywords: ['exalted'],
    oracleText: 'Exalted (Whenever a creature you control attacks alone, that creature gets +1/+1 until end of turn.)',
    imageUri: 'https://cards.scryfall.io/large/front/5/9/59fdc045-b938-4321-aec3-51685cbbaa52.jpg?1783942584',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'attacks_alone' },
        effect: { type: 'exalted_pump', power: 1, toughness: 1 },
      }),
    ],
    artId: 274, plan: 'Alara',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'elgaud-inquisitor', name: 'Elgaud Inquisitor', set: 'DKA',
    types: ['Creature'], subtypes: ['Human', 'Cleric'], colors: ['W'],
    power: 2, toughness: 2, manaCost: 4, keywords: ['lifelink'],
    oracleText: 'Lifelink (Damage dealt by this creature also causes you to gain that much life.)\nWhen this creature dies, create a 1/1 white Spirit creature token with flying.',
    imageUri: 'https://cards.scryfall.io/large/front/c/3/c342e1da-7ab9-4e29-96e6-77d820a45ede.jpg?1783940857',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'dies' },
        effect: {
          type: 'create_token', cardId: 'token_spirit_flying', name: 'Spirit',
          kind: 'creature', power: 1, toughness: 1, colors: ['W'],
          types: ['Creature'], subtypes: ['Spirit'], keywords: ['flying'],
        },
      }),
    ],
    artId: 453, plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),

  // Token Spirit 1/1 z lataniem (Elgaud Inquisitor). Istniejący token_spirit
  // (endure) jest BEZ latania — to inny token, więc osobna definicja.
  defineCard({
    id: 'token_spirit_flying', name: 'Spirit', set: null,
    imageUri: 'https://cards.scryfall.io/large/front/6/f/6f5a5786-e2be-4bb0-b971-81d1d5cc8f52.jpg?1783903574', // M157/B: token ze Scryfall
    types: ['Creature', 'Token'], subtypes: ['Spirit'], colors: ['W'],
    keywords: ['flying'], power: 1, toughness: 1, manaCost: 0,
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii'] },
  }),

  defineCard({
    id: 'fledgling-imp', name: 'Fledgling Imp', set: 'ODY',
    types: ['Creature'], subtypes: ['Imp'], colors: ['B'],
    power: 2, toughness: 2, manaCost: 3,
    oracleText: '{B}, Discard a card: This creature gains flying until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/d/1/d11770ee-dcf0-4dd4-ab43-b98f1133cec7.jpg?1783945246',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        // Oracle NIE ma tapnięcia w koszcie — {B} plus odrzucenie karty.
        cost: { mana: 1, colors: ['B'], discardCard: true },
        effect: { type: 'grant_keywords_until_end_of_turn', keywords: ['flying'] },
      }),
    ],
    artId: 114, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'chained-throatseeker', name: 'Chained Throatseeker', set: 'NPH',
    types: ['Creature'], subtypes: ['Phyrexian', 'Horror'], colors: ['U'],
    power: 5, toughness: 5, manaCost: 6, keywords: ['infect'],
    oracleText: "Infect (This creature deals damage to creatures in the form of -1/-1 counters and to players in the form of poison counters.)\nThis creature can't attack unless defending player is poisoned.",
    imageUri: 'https://cards.scryfall.io/large/front/3/a/3a7bb447-c2b0-429e-bf82-02d6a966fe73.jpg?1783941321',
    abilities: [
      createAbility({ type: ABILITY_TYPE.static, cantAttackUnlessDefenderPoisoned: true }),
    ],
    artId: 469, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'sterling-keykeeper', name: 'Sterling Keykeeper', set: 'OTJ',
    types: ['Creature'], subtypes: ['Human', 'Mercenary'], colors: ['W'],
    power: 2, toughness: 2, manaCost: 2,
    oracleText: '{2}, {T}: Tap target non-Mount creature.',
    imageUri: 'https://cards.scryfall.io/large/front/0/1/019d539f-04c2-43f1-8677-6d6fbb0e94f7.jpg?1783911850',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2, tap: true },
        targets: [{ type: 'creature_without_subtype', subtype: 'Mount' }],
        effect: { type: 'tap_permanent' },
      }),
    ],
    artId: 229, plan: 'Thunder Junction',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'circle-of-the-land-druid', name: 'Circle of the Land Druid', set: 'CLB',
    types: ['Creature'], subtypes: ['Gnome', 'Druid'], colors: ['G'],
    power: 1, toughness: 1, manaCost: 2,
    oracleText: 'When this creature enters, you may mill four cards. (You may put the top four cards of your library into your graveyard.)\nNatural Recovery — When this creature dies, return target land card from your graveyard to your hand.',
    imageUri: 'https://cards.scryfall.io/large/front/1/e/1e84fc74-5b33-423a-82c7-983320fce7a3.jpg?1783922718',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        // „You MAY mill" — opcjonalny trigger (decyzja gracza, nie automat).
        trigger: { event: 'enter_battlefield', mayFire: true },
        effect: { type: 'mill_cards', amount: 4 },
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'dies', requiresTarget: { type: 'land_card_in_graveyard' } },
        effect: { type: 'return_card_from_graveyard_to_hand', cardKind: 'land' },
      }),
    ],
    artId: 438, plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'academy-journeymage', name: 'Academy Journeymage', set: 'DOM',
    types: ['Creature'], subtypes: ['Human', 'Wizard'], colors: ['U'],
    power: 3, toughness: 2, manaCost: 5,
    oracleText: "This spell costs {1} less to cast if you control a Wizard.\nWhen this creature enters, return target creature an opponent controls to its owner's hand.",
    imageUri: 'https://cards.scryfall.io/large/front/a/4/a46a65e0-66a3-4896-8acc-0ad5e9927c40.jpg?1783935034',
    // CR 601.2f: warunkowa obniżka na poziomie KARTY (permanent nie ma
    // deskryptora czaru); warunek generyczny — kontrolowany podtyp.
    costReduction: { amount: 1, condition: { controlsSubtype: 'Wizard' } },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'creature_opponent_controls' } },
        effect: { type: 'bounce_permanent' },
      }),
    ],
    artId: 5, plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'chronic-flooding', name: 'Chronic Flooding', set: 'RTR',
    types: ['Enchantment'], subtypes: ['Aura'], colors: ['U'], manaCost: 2,
    oracleText: 'Enchant land\nWhenever enchanted land becomes tapped, its controller mills three cards.',
    imageUri: 'https://cards.scryfall.io/large/front/1/a/1a757425-3cf2-4aca-b415-5ec2d5f753fe.jpg?1783940370',
    // „Enchant land" — gospodarzem jest LAND (dotąd aury zaczarowywały stwora,
    // gracza, enchantment albo stwora/ląd).
    aura: { enchant: 'land' },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enchanted_permanent_tapped' },
        effect: { type: 'mill_cards', amount: 3, applyTo: 'enchanted_controller' },
      }),
    ],
    artId: 315, plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'krumar-initiate', name: 'Krumar Initiate', set: 'TDM',
    types: ['Creature'], subtypes: ['Human', 'Cleric'], colors: ['B'],
    power: 2, toughness: 2, manaCost: 2,
    oracleText: '{X}{B}, {T}, Pay X life: This creature endures X. Activate only as a sorcery. (Put X +1/+1 counters on it or create an X/X white Spirit creature token.)',
    imageUri: 'https://cards.scryfall.io/large/front/b/c/bc66680f-24ab-433a-8197-feac3a174075.jpg?1783907376',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        // {X}{B} + tapnięcie + zapłata X życia; X wybiera gracz (warianty
        // komendy), a endure X to WYBÓR kontrolera przy rozstrzyganiu.
        cost: { manaX: true, mana: 1, colors: ['B'], tap: true, payLifeX: true },
        timing: 'sorcery',
        effect: { type: 'endure_x' },
      }),
    ],
    artId: 95, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),

  defineCard({
    id: 'cuombajj-witches', name: 'Cuombajj Witches', set: 'CMR',
    types: ['Creature'], subtypes: ['Human', 'Wizard'], colors: ['B'],
    power: 1, toughness: 3, manaCost: 2,
    oracleText: "{T}: This creature deals 1 damage to any target and 1 damage to any target of an opponent's choice.",
    imageUri: 'https://cards.scryfall.io/large/front/6/a/6a26e910-275a-4981-831b-bfed936a7e3f.jpg?1783928842',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        targets: [{ type: 'any_target' }],
        // DRUGI cel wskazuje przeciwnik (CR 601.2c) — aktywacja czeka na jego
        // decyzję, zanim zapłaci koszty.
        opponentChoosesTarget: { type: 'any_target' },
        effect: [
          { type: 'damage', amount: 1, targetIndex: 0 },
          { type: 'damage', amount: 1, targetIndex: 1 },
        ],
      }),
    ],
    artId: 246, plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
  }),

  // Token Incubator (incubate, CR 701.47) — artefakt z licznikami +1/+1
  // i zdolnością „{2}: Transform this token"; druga strona to token_phyrexian.
  defineCard({
    id: 'token_incubator', name: 'Incubator', set: null,
    imageUri: 'https://cards.scryfall.io/large/front/c/5/c5229eb0-9356-43a6-9b1b-6366f3c1e405.jpg?1783905793', // M157/B: token ze Scryfall
    types: ['Artifact', 'Token'], subtypes: ['Incubator'], colors: [],
    manaCost: 0,
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2 },
        effect: { type: 'transform' },
      }),
    ],
    transformTo: 'token_phyrexian',
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii'] },
  }),

  // Token Phyrexian — tylna strona Incubatora: 0/0 artefaktowy stwór
  // (na stole żywy dzięki licznikom +1/+1 przeniesionym z przedniej strony).
  defineCard({
    id: 'token_phyrexian', name: 'Phyrexian', set: null,
    imageUri: 'https://cards.scryfall.io/large/back/c/5/c5229eb0-9356-43a6-9b1b-6366f3c1e405.jpg?1783905793', // M157/B: token ze Scryfall
    types: ['Artifact', 'Creature', 'Token'], subtypes: ['Phyrexian'], colors: [],
    power: 0, toughness: 0, manaCost: 0,
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii'] },
  }),

  // Token Clue (Investigate — Floodhound): {2}, Sacrifice: draw a card.
  defineCard({
    id: 'token_clue', name: 'Clue', set: null,
    types: ['Artifact', 'Token'], subtypes: ['Clue'], colors: [],
    manaCost: 0,
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2, sacrificeSelf: true },
        effect: { type: 'draw_cards', amount: 1 },
      }),
    ],
    imageUri: 'https://cards.scryfall.io/large/front/e/b/eb129b0d-1349-4e88-a6a7-b7968b26ee7e.jpg?1783926587',
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii'] },
  }),

  // =========================================================================
  // Batch 35 (2026-08-18, lista z planu Batch 35; Oracle ze Scryfalla).
  // Transza E2: karty bez nowej mechaniki — reuse pump+scry, aura, token_wolf,
  // unearth_return.
  // =========================================================================

  // 1. Titan's Strength (ORI) {R} Instant — +3/+1, Scry 1
  defineCard({
    id: 'titans-strength', name: "Titan's Strength", set: 'ORI',
    types: ['Instant'], colors: ['R'], manaCost: 1,
    oracleText: 'Target creature gets +3/+1 until end of turn. Scry 1. (Look at the top card of your library. You may put that card on the bottom.)',
    imageUri: 'https://cards.scryfall.io/large/front/0/e/0e48f309-8e56-4741-a9ff-e899dafb333a.jpg?1783938325',
    spell: {
      timing: 'instant',
      targets: [{ type: 'creature' }],
      effects: [
        { type: 'pump', power: 3, toughness: 1 },
        { type: 'scry', amount: 1 },
      ],
    },
    artId: 22, plan: 'Theros',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Wolfkin Bond (M20) {4}{G} Aura — ETB token Wolf 2/2, enchanted +2/+2
  defineCard({
    id: 'wolfkin-bond', name: 'Wolfkin Bond', set: 'M20',
    types: ['Enchantment'], subtypes: ['Aura'], colors: ['G'], manaCost: 5,
    oracleText: 'Enchant creature\nWhen this Aura enters, create a 2/2 green Wolf creature token.\nEnchanted creature gets +2/+2.',
    imageUri: 'https://cards.scryfall.io/large/front/2/c/2c419a2b-4389-49bc-91f1-a613ffcbfa0b.jpg?1783932954',
    aura: { pump: { power: 2, toughness: 2 } },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: {
          type: 'create_token', cardId: 'token_wolf', name: 'Wolf',
          kind: 'creature', power: 2, toughness: 2, colors: ['G'],
          types: ['Creature'], subtypes: ['Wolf'],
        },
      }),
    ],
    artId: 514, plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Mark of the Vampire (M14) {3}{B} Aura — +2/+2 i lifelink
  defineCard({
    id: 'mark-of-the-vampire', name: 'Mark of the Vampire', set: 'M14',
    types: ['Enchantment'], subtypes: ['Aura'], colors: ['B'], manaCost: 4,
    oracleText: 'Enchant creature\nEnchanted creature gets +2/+2 and has lifelink.',
    imageUri: 'https://cards.scryfall.io/large/front/7/1/71c2f0fb-3291-489c-92cf-8d326f2e6735.jpg?1783939922',
    aura: { pump: { power: 2, toughness: 2 }, keywords: ['lifelink'] },
    artId: 221, plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),

  // 4. Simian Simulacrum (BRO) {3} Artifact Creature Ape 2/1
  //    ETB: 2x +1/+1 na twojego stwora; Unearth {2}{G}{G}
  defineCard({
    id: 'simian-simulacrum', name: 'Simian Simulacrum', set: 'BRO',
    types: ['Artifact', 'Creature'], subtypes: ['Ape'], colors: [],
    power: 2, toughness: 1, manaCost: 3,
    oracleText: 'When this creature enters, put two +1/+1 counters on target creature you control.\nUnearth {2}{G}{G} ({2}{G}{G}: Return this card from your graveyard to the battlefield. It gains haste. Exile it at the beginning of the next end step or if it would leave the battlefield. Unearth only as a sorcery.)',
    imageUri: 'https://cards.scryfall.io/large/front/c/8/c85e2a35-cb55-434c-bbd7-54c3438345c1.jpg?1783920033',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'creature_you_control' } },
        effect: { type: 'add_counter', counter: '+1/+1', amount: 2 },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        timing: 'sorcery',
        cost: { mana: 4, colors: ['G', 'G'] },
        fromGraveyard: true,
        effect: { type: 'unearth_return' },
      }),
    ],
    artId: 362, plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
  }),

  // =========================================================================
  // Batch 35 transza E3 (2026-08-18): pozostałe 5 kart (bez suspend — Mindstab).
  // Oracle ze Scryfalla (docs/cards/scryfall-*.json, ADR 0010 §2a).
  // =========================================================================

  // 5. Trade Route Envoy (TDM) {3}{G} Creature — Dog Soldier 4/3
  //    ETB: dobierz, jeśli kontrolujesz stwora z licznikiem; inaczej +1/+1.
  defineCard({
    id: 'trade-route-envoy', name: 'Trade Route Envoy', set: 'TDM',
    types: ['Creature'], subtypes: ['Dog', 'Soldier'], colors: ['G'],
    power: 4, toughness: 3, manaCost: 4,
    oracleText: 'When this creature enters, draw a card if you control a creature with a counter on it. If you don\'t draw a card this way, put a +1/+1 counter on this creature.',
    imageUri: 'https://cards.scryfall.io/large/front/f/0/f0c89d95-d697-4cfa-9dfa-52d7adb96176.jpg',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        // Generyczny if/then/else (effects.js `conditional`): warunek wspólny
        // z triggers.js (controlsCreatureWithCounter — Delta Bloodflies).
        effect: {
          type: 'conditional',
          condition: 'controlsCreatureWithCounter',
          then: { type: 'draw_cards', amount: 1 },
          else: { type: 'add_counter', counter: '+1/+1', amount: 1 },
        },
      }),
    ],
    artId: 123, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),

  // 6. Twiddle (8ED) {U} Instant — „You may tap or untap target artifact,
  //    creature, or land" (modalny wybór tap/untap).
  defineCard({
    id: 'twiddle', name: 'Twiddle', set: '8ED',
    types: ['Instant'], colors: ['U'], manaCost: 1,
    oracleText: 'You may tap or untap target artifact, creature, or land.',
    imageUri: 'https://cards.scryfall.io/large/front/1/b/1b25858a-ab2d-441a-a3fe-6d5ecd7f05be.jpg',
    spell: {
      timing: 'instant',
      modes: [
        {
          name: 'Tapnięcie',
          targets: [{ type: 'artifact_or_creature_or_land' }],
          effects: [{ type: 'tap_permanent' }],
        },
        {
          name: 'Odkręcenie',
          targets: [{ type: 'artifact_or_creature_or_land' }],
          effects: [{ type: 'untap_permanent' }],
        },
      ],
    },
    artId: 19, plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
  }),

  // 7. Steelfin Whale (MH2) {5}{U} Creature — Whale 3/4
  //    Affinity for artifacts; artifact ETB → untap.
  defineCard({
    id: 'steelfin-whale', name: 'Steelfin Whale', set: 'MH2',
    types: ['Creature'], subtypes: ['Whale'], colors: ['U'],
    power: 3, toughness: 4, manaCost: 6,
    oracleText: 'Affinity for artifacts (This spell costs {1} less to cast for each artifact you control.)\nWhenever an artifact you control enters, untap this creature.',
    imageUri: 'https://cards.scryfall.io/large/front/7/e/7e7ca8b6-d7e0-4af2-a578-bf45a8731c19.jpg',
    // Affinity (CR 702.42): obniżka PER artefakt — `amount` mnożona przez
    // liczbę kontrolowanych artefaktów (mana-cost.conditionalCostReduction).
    costReduction: { amount: 1, condition: { affinityToArtifacts: true } },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'artifact_you_control_enters' },
        effect: { type: 'untap_permanent' },
      }),
    ],
    artId: 99, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Blazing Torch (ISD) {1} Artifact — Equipment
  //    Nosiciel nie może być blokowany przez Vampiry/Zombie; nosiciel ma
  //    „{T}, Sacrifice Blazing Torch: 2 damage to any target"; Equip {1}.
  defineCard({
    id: 'blazing-torch', name: 'Blazing Torch', set: 'ISD',
    types: ['Artifact'], subtypes: ['Equipment'], colors: [], manaCost: 1,
    oracleText: 'Equipped creature can\'t be blocked by Vampires or Zombies.\nEquipped creature has "{T}, Sacrifice Blazing Torch: Blazing Torch deals 2 damage to any target."\nEquip {1} ({1}: Attach to target creature you control. Equip only as a sorcery.)',
    imageUri: 'https://cards.scryfall.io/large/front/4/e/4e14fc60-f300-40f0-b712-4e339dc27929.jpg',
    equipment: {
      equip: 1,
      // Zdolności NADANE nosicielowi (CR 301.5c): statyczna restrykcja
      // blokowania (combat czyta je z attachmentsAttachedTo) oraz aktywowana
      // zdolność z kosztem {T} nosiciela + poświęceniem samego sprzętu.
      grantedAbilities: [
        createAbility({
          type: ABILITY_TYPE.static,
          cantBeBlockedBySubtypes: ['Vampire', 'Zombie'],
        }),
        createAbility({
          type: ABILITY_TYPE.activated,
          cost: { tapHost: true, sacrificeSelf: true },
          targets: [{ type: 'any_target' }],
          effect: { type: 'damage', amount: 2 },
        }),
      ],
    },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'equip',
        cost: { mana: 1 },
        effect: [],
      }),
    ],
    artId: 122, plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),

  // 9. Basilisk Gate (CLB) Land — Gate
  //    {T}: Add {C}; {2},{T}: +X/+X, X = liczba kontrolowanych Gates (sorcery).
  defineCard({
    id: 'basilisk-gate', name: 'Basilisk Gate', set: 'CLB',
    types: ['Land'], subtypes: ['Gate'], colors: [],
    oracleText: '{T}: Add {C}.\n{2}, {T}: Target creature gets +X/+X until end of turn, where X is the number of Gates you control. Activate only as a sorcery.',
    imageUri: 'https://cards.scryfall.io/large/front/4/a/4a306025-d429-4006-b7ed-bdb287e83f57.jpg',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        timing: 'sorcery',
        cost: { mana: 2, tap: true },
        targets: [{ type: 'creature' }],
        effect: { type: 'pump_by_gates' },
      }),
    ],
    artId: 466, plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
  }),

  // 10. Mindstab (TSP) {5}{B} Sorcery — target player discards 3; Suspend 4—{B}
  defineCard({
    id: 'mindstab', name: 'Mindstab', set: 'TSP',
    types: ['Sorcery'], colors: ['B'], manaCost: 6,
    oracleText: 'Target player discards three cards.\nSuspend 4—{B} (Rather than cast this card from your hand, you may pay {B} and exile it with four time counters on it. At the beginning of your upkeep, remove a time counter. When the last is removed, you may cast it without paying its mana cost.)',
    imageUri: 'https://cards.scryfall.io/large/front/3/e/3efd28ef-77db-4e7b-a69d-5a089e016737.jpg',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'player' }],
      effects: [{ type: 'discard_cards', amount: 3, applyTo: 'target' }],
    },
    // Suspend (CR 702.62): koszt zawieszenia + liczba liczników czasu.
    // Uproszczenie: po zdjęciu ostatniego licznika karta zostaje w exile jako
    // gotowa do rzutu bez kosztu (nie wygasa po jednym oknie priorytetu).
    suspend: { cost: 1, colors: ['B'], timeCounters: 4 },
    artId: 7, plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
    notes: ['suspend: po zdjęciu ostatniego licznika zdolność wyzwalana otwiera JEDNORAZOWĄ decyzję — rzuć za darmo albo zostaw w exile na stałe (CR 702.62a)'],
  }),

  // =========================================================================
  // Batch 36 (2026-08-19, lista właściciela). Oracle ze Scryfalla
  // (docs/cards/scryfall-*.json, ADR 0010 §2a). Transza E1: reuse mechanik.
  // =========================================================================

  // 2. Omenspeaker (THS) {1}{U} 1/3 Human Wizard — ETB Scry 2
  defineCard({
    id: 'omenspeaker', name: 'Omenspeaker', set: 'THS',
    types: ['Creature'], subtypes: ['Human', 'Wizard'], colors: ['U'],
    power: 1, toughness: 3, manaCost: 2,
    oracleText: 'When this creature enters, scry 2. (Look at the top two cards of your library, then put any number of them on the bottom and the rest on top in any order.)',
    imageUri: 'https://cards.scryfall.io/large/front/f/3/f347eb88-7d1d-4ed5-b841-2bf81f00d5f0.jpg',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: { type: 'scry', amount: 2 },
      }),
    ],
    artId: 452, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 7. Feral Invocation (THS) {2}{G} Aura (flash) — +2/+2
  defineCard({
    id: 'feral-invocation', name: 'Feral Invocation', set: 'THS',
    types: ['Enchantment'], subtypes: ['Aura'], colors: ['G'], manaCost: 3,
    keywords: ['flash'],
    oracleText: 'Flash (You may cast this spell any time you could cast an instant.)\nEnchant creature\nEnchanted creature gets +2/+2.',
    imageUri: 'https://cards.scryfall.io/large/front/5/c/5c1f15a2-0058-4188-9696-385fa6974bd4.jpg',
    aura: { pump: { power: 2, toughness: 2 } },
    artId: 272, plan: 'Theros',
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Grizzled Leotau (ARB) {G}{W} 1/5 Cat — bez zdolności
  defineCard({
    id: 'grizzled-leotau', name: 'Grizzled Leotau', set: 'ARB',
    types: ['Creature'], subtypes: ['Cat'], colors: ['G', 'W'],
    power: 1, toughness: 5, manaCost: 2,
    oracleText: '',
    imageUri: 'https://cards.scryfall.io/large/front/2/b/2b388381-9e13-4ce7-b5b3-56a74cc23d93.jpg',
    artId: 297, plan: 'Alara',
    support: { status: 'supported', limitations: [] },
  }),

  // 9. Survivor of Korlis (BRO) {W} 1/1 Human Soldier — first strike;
  //    {1}{W}, wygnaj z grobu: Scry 2 (Goldmeadow Nomad wzorzec).
  defineCard({
    id: 'survivor-of-korlis', name: 'Survivor of Korlis', set: 'BRO',
    types: ['Creature'], subtypes: ['Human', 'Soldier'], colors: ['W'],
    power: 1, toughness: 1, manaCost: 1, keywords: ['first_strike'],
    oracleText: 'First strike\n{1}{W}, Exile this card from your graveyard: Scry 2.',
    imageUri: 'https://cards.scryfall.io/large/front/8/1/817bcc8d-a5b7-448c-a3eb-825dc65944ec.jpg',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2, exileFromGraveyard: true, colors: ['W'] },
        fromGraveyard: true,
        effect: { type: 'scry', amount: 2 },
      }),
    ],
    artId: 441, plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
  }),

  // =========================================================================
  // Batch 36 transza E2 (2026-08-19): Ghoulcaller's Bell + Emerald Oryx.
  // =========================================================================

  // 6. Ghoulcaller's Bell (ISD) {1} Artifact — {T}: each player mills a card
  defineCard({
    id: 'ghoulcallers-bell', name: "Ghoulcaller's Bell", set: 'ISD',
    types: ['Artifact'], colors: [], manaCost: 1,
    oracleText: '{T}: Each player mills a card.',
    imageUri: 'https://cards.scryfall.io/large/front/8/6/863e7c2a-698c-4dce-a10b-ca58e4affa57.jpg',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        effect: { type: 'mill_both_players', amount: 1 },
      }),
    ],
    artId: 163, plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),

  // 10. Emerald Oryx (M10) {3}{G} 2/3 Antelope — forestwalk
  defineCard({
    id: 'emerald-oryx', name: 'Emerald Oryx', set: 'M10',
    types: ['Creature'], subtypes: ['Antelope'], colors: ['G'],
    power: 2, toughness: 3, manaCost: 4,
    oracleText: "Forestwalk (This creature can't be blocked as long as defending player controls a Forest.)",
    imageUri: 'https://cards.scryfall.io/large/front/1/0/10bf14b5-31d0-42e3-a319-2622b489f7c4.jpg',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.static,
        landwalk: { subtype: 'Forest' },
      }),
    ],
    artId: 511, plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
  }),

  // =========================================================================
  // Batch 36 transza E3 (2026-08-19): Wretched Banquet + Mysteries of the Deep.
  // =========================================================================

  // 1. Wretched Banquet (CON) {B} Sorcery — destroy if least power
  defineCard({
    id: 'wretched-banquet', name: 'Wretched Banquet', set: 'CON',
    types: ['Sorcery'], colors: ['B'], manaCost: 1,
    oracleText: 'Destroy target creature if it has the least power or is tied for least power among creatures on the battlefield.',
    imageUri: 'https://cards.scryfall.io/large/front/3/b/3bdaf55b-2de3-4c8a-90ae-9c88c9d00fd7.jpg',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'creature' }],
      effects: [{ type: 'destroy_if_least_power' }],
    },
    artId: 354, plan: 'Alara',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Mysteries of the Deep (WWK) {4}{U} Instant — Draw 2; Landfall: Draw 3
  defineCard({
    id: 'mysteries-of-the-deep', name: 'Mysteries of the Deep', set: 'WWK',
    types: ['Instant'], colors: ['U'], manaCost: 5,
    oracleText: 'Draw two cards.\nLandfall — If you had a land enter the battlefield under your control this turn, draw three cards instead.',
    imageUri: 'https://cards.scryfall.io/large/front/1/9/1907b1e9-ae1e-43fb-9033-3c4322277fff.jpg',
    spell: {
      timing: 'instant',
      effects: [{
        type: 'conditional',
        condition: 'landEnteredThisTurn',
        then: { type: 'draw_cards', amount: 3 },
        else: { type: 'draw_cards', amount: 2 },
      }],
    },
    artId: 306, plan: 'Zendikar',
    support: { status: 'supported', limitations: [] },
  }),

  // =========================================================================
  // Batch 36 transza E4 (2026-08-19): Molten Nursery + Piercing Rays.
  // =========================================================================

  // 2. Molten Nursery (BFZ) {2}{R} Enchantment, Devoid —
  //    whenever you cast a colorless spell, 1 dmg to any target.
  defineCard({
    id: 'molten-nursery', name: 'Molten Nursery', set: 'BFZ',
    types: ['Enchantment'], colors: [], manaCost: 3,
    keywords: ['devoid'],
    oracleText: 'Devoid (This card has no color.)\nWhenever you cast a colorless spell, this enchantment deals 1 damage to any target.',
    imageUri: 'https://cards.scryfall.io/large/front/3/d/3db8aaf5-e2bf-40ea-bd5d-663017cfd4a6.jpg',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: {
          event: 'when_you_cast_spell',
          condition: { spellIsColorless: true },
          requiresTarget: { type: 'any_target' },
        },
        effect: { type: 'damage', amount: 1 },
      }),
    ],
    artId: 387, plan: 'Zendikar',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Piercing Rays (MH2) {1}{W} Sorcery —
  //    exile target tapped creature; Forecast {2}{W}: tap target untapped.
  defineCard({
    id: 'piercing-rays', name: 'Piercing Rays', set: 'MH2',
    types: ['Sorcery'], colors: ['W'], manaCost: 2,
    oracleText: 'Exile target tapped creature.\nForecast — {2}{W}, Reveal this card from your hand: Tap target untapped creature. (Activate this ability only during your upkeep and only once each turn.)',
    imageUri: 'https://cards.scryfall.io/large/front/e/a/eaeb9fd0-c46a-4246-838f-a5b7a8ea8eef.jpg',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'tapped_creature' }],
      effects: [{ type: 'exile_permanent' }],
    },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        forecast: true,
        cost: { mana: 3, colors: ['W'] },
        targets: [{ type: 'untapped_creature' }],
        effect: { type: 'tap_permanent' },
      }),
    ],
    artId: 45, plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
  }),

  // =========================================================================
  // Batch 37 (2026-08-19, lista właściciela). Oracle ze Scryfalla
  // (docs/cards/scryfall-*.json, ADR 0010 §2a), artId i plan ze słownika
  // tools/collection-art-ids.csv. Transza A: reuse mechanik.
  // =========================================================================

  // 1. Returned Centaur (ORI) {3}{B} 2/4 Zombie Centaur — ETB: target player mills 4
  defineCard({
    id: 'returned-centaur', name: 'Returned Centaur', set: 'ORI',
    types: ['Creature'], subtypes: ['Zombie', 'Centaur'], colors: ['B'],
    power: 2, toughness: 4, manaCost: 4,
    oracleText: 'When this creature enters, target player mills four cards.',
    imageUri: 'https://cards.scryfall.io/large/front/1/0/103b369c-da58-40e7-98aa-5a5471434bca.jpg',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'player', prefer: 'opponent' } },
        effect: { type: 'mill_cards', amount: 4 },
      }),
    ],
    artId: 120, plan: 'Theros',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Liliana's Triumph (WAR) {1}{B} Instant — each opponent sacrifices a creature
  defineCard({
    id: 'lilianas-triumph', name: "Liliana's Triumph", set: 'WAR',
    types: ['Instant'], colors: ['B'], manaCost: 2,
    oracleText: "Each opponent sacrifices a creature of their choice. If you control a Liliana planeswalker, each opponent also discards a card.",
    imageUri: 'https://cards.scryfall.io/large/front/8/4/84803db8-fdb0-462b-92f6-33d591593d2d.jpg',
    spell: {
      timing: 'instant',
      // „Each opponent\" w formacie 1v1 = jedyny przeciwnik. Wybór poświęcanego
      // stwora należy do CELU (blokująca decyzja resolve_sacrifice_choice).
      // M203/2: deskryptor niesie `opponent: true` (jak Dreams of Steel and
      // Oil) — bez niego rzucający był legalnym celem własnego „each
      // opponent", czyli cel niezgodny z Oracle (CR 115.2: cel musi spełniać
      // deskryptor celu). Dotąd „poprawny" cel brał się z kolejności ofert.
      targets: [{ type: 'player', opponent: true }],
      effects: [
        { type: 'player_sacrifices_creature' },
        // Klauzula warunkowa (decyzja właściciela 2026-08-19): efekt kodujemy
        // z WYPRZEDZENIEM — generyczny warunek po typie Planeswalker i podtypie
        // Liliana (effects.js `conditional`). Działa od razu, gdy w katalogu
        // pojawi się jakikolwiek planeswalker Liliana; dziś (brak planeswalkerów)
        // `else` nie zachodzi, więc nic się nie dzieje — karta jest kompletna
        // względem Oracle, a nie „czeka na przyszłość\".
        {
          type: 'conditional',
          condition: 'controlsPlaneswalkerWithSubtype',
          subtype: 'Liliana',
          then: { type: 'discard_each_opponent', amount: 1 },
          else: null,
        },
      ],
    },
    artId: 38, plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
    notes: ['„Each opponent\" w 1v1 = celowy przeciwnik; poświęcenie „of their choice\" przez resolve_sacrifice_choice', 'dyskard za Lilianę warunkowy (controlsPlaneswalkerWithSubtype); planeswalkerów nie ma w katalogu, więc dziś nie zachodzi — zakodowane z wyprzedzeniem (decyzja właściciela)'],
  }),

  // 3. Palace Familiar (DTK) {1}{U} 1/1 Bird — Flying; dies: draw a card
  defineCard({
    id: 'palace-familiar', name: 'Palace Familiar', set: 'DTK',
    types: ['Creature'], subtypes: ['Bird'], colors: ['U'],
    keywords: ['flying'], power: 1, toughness: 1, manaCost: 2,
    oracleText: 'Flying\\nWhen this creature dies, draw a card.',
    imageUri: 'https://cards.scryfall.io/large/front/f/c/fc0c17c9-54af-4dd4-8d4a-fd5a7b8c3c77.jpg',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'dies' },
        effect: { type: 'draw_cards', amount: 1 },
      }),
    ],
    artId: 146, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),

  // 4. Thornhide Wolves (M19) {4}{G} 4/5 Wolf — bez zdolności
  defineCard({
    id: 'thornhide-wolves', name: 'Thornhide Wolves', set: 'M19',
    types: ['Creature'], subtypes: ['Wolf'], colors: ['G'],
    power: 4, toughness: 5, manaCost: 5,
    oracleText: '',
    imageUri: 'https://cards.scryfall.io/large/front/f/c/fc0f3812-bb6c-4d99-b505-9dfd84e3fd95.jpg',
    artId: 450, plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),

  // =========================================================================
  // Batch 37 transza B (2026-08-19): nowe generyczne mechaniki (ADR 0002).
  // =========================================================================

  // 5. Village Bell-Ringer (ISD) {2}{W} 1/4 Human Scout — Flash;
  //    ETB: untap all creatures you control.
  defineCard({
    id: 'village-bell-ringer', name: 'Village Bell-Ringer', set: 'ISD',
    types: ['Creature'], subtypes: ['Human', 'Scout'], colors: ['W'],
    keywords: ['flash'], power: 1, toughness: 4, manaCost: 3,
    oracleText: 'Flash (You may cast this spell any time you could cast an instant.)\\nWhen this creature enters, untap all creatures you control.',
    imageUri: 'https://cards.scryfall.io/large/front/c/b/cb6912b3-bab9-4937-afdd-3711e6d792a0.jpg',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: { type: 'untap_all_creatures_you_control' },
      }),
    ],
    artId: 317, plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Ojutai's Breath (DTK) {2}{U} Instant — tap, doesn't untap; Rebound
  defineCard({
    id: 'ojutais-breath', name: "Ojutai's Breath", set: 'DTK',
    types: ['Instant'], colors: ['U'], manaCost: 3,
    oracleText: "Tap target creature. It doesn't untap during its controller's next untap step.\\nRebound (If you cast this spell from your hand, exile it as it resolves. At the beginning of your next upkeep, you may cast this card from exile without paying its mana cost.)",
    imageUri: 'https://cards.scryfall.io/large/front/a/f/af51e5a1-7d46-4dad-a25c-6767cbd03dff.jpg',
    spell: {
      timing: 'instant',
      rebound: true,
      targets: [{ type: 'creature' }],
      effects: [
        { type: 'tap_permanent' },
        { type: 'dont_untap_next_untap_step' },
      ],
    },
    artId: 538, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),

  // 6. Static Net (BRO) {3}{W} Enchantment —
  //    ETB: exile target nonland permanent an opponent controls until leaves;
  //    ETB: gain 2 life and create a tapped Powerstone token.
  defineCard({
    id: 'static-net', name: 'Static Net', set: 'BRO',
    types: ['Enchantment'], colors: ['W'], manaCost: 4,
    oracleText: "When this enchantment enters, exile target nonland permanent an opponent controls until this enchantment leaves the battlefield.\\nWhen this enchantment enters, you gain 2 life and create a tapped Powerstone token.",
    imageUri: 'https://cards.scryfall.io/large/front/5/a/5ab5cb30-3ced-4450-a3c4-b519f3762620.jpg',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'nonland_permanent', opponentControls: true } },
        effect: { type: 'exile_nonland_permanent_linked' },
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [
          { type: 'gain_life', amount: 2 },
          {
            type: 'create_token', cardId: 'token_powerstone', name: 'Powerstone',
            kind: 'artifact', colors: [], types: ['Artifact'], subtypes: ['Powerstone'],
            // Druk tokenu Powerstone: „{T}: Add {C}. This mana can't be spent
            // to cast a nonartifact spell." Ograniczenie jest DESKRYPTOREM
            // (`spendOnly`), więc przyszłe źródła many warunkowej (Sol Grail,
            // powerstone'y z BRO) pójdą tą samą ścieżką (ADR 0002).
            abilities: [createAbility({
              type: ABILITY_TYPE.activated,
              cost: { tap: true },
              effect: { type: 'add_mana', amount: 1, colors: [], spendOnly: 'artifact' },
            })],
            tapped: true,
          },
        ],
      }),
      // Linked exile return (CR 400.7): „until this enchantment leaves the
      // battlefield\" — LTB przywraca wygnany permanent pod kontrolą właściciela.
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'leaves_battlefield' },
        effect: { type: 'return_exiled_to_battlefield' },
      }),
    ],
    artId: 497, plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
    notes: ['exile linked: id wygnanego zapisane na źródle (exiledCardIds), LTB przywraca (jak Faceless Butcher); Powerstone produkuje {C} z restrykcją „only to cast artifact spells\" (M214 — restrictedPool)'],
  }),

  // Token Powerstone (BRO): artefakt „{T}: Add {C} — spend only to cast
  // artifact spells\" (CR 106.3 — restrykcja many). Produkcja bezbarwna w
  // MANA_SOURCE_MAP; restrykcja artefaktowa nieimplementowana (notes).
  defineCard({
    id: 'token_powerstone', name: 'Powerstone', set: null,
    imageUri: 'https://cards.scryfall.io/large/front/d/4/d45fe4b6-aeaf-4f84-b660-c7b482ed8512.jpg?1783919908', // M157/B: token ze Scryfall
    types: ['Artifact', 'Token'], subtypes: ['Powerstone'], colors: [],
    manaCost: 0,
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Static Net'] },
    notes: ['{T}: Add {C}; restrykcja „only to cast artifact spells\" (M214 — restrictedPool)'],
  }),

  // 4. Satyr Wayfinder (M15) {1}{G} 1/1 Satyr —
  //    ETB: reveal top 4, may take a land to hand, rest to grave.
  defineCard({
    id: 'satyr-wayfinder', name: 'Satyr Wayfinder', set: 'M15',
    types: ['Creature'], subtypes: ['Satyr'], colors: ['G'],
    power: 1, toughness: 1, manaCost: 2,
    oracleText: "When this creature enters, reveal the top four cards of your library. You may put a land card from among them into your hand. Put the rest into your graveyard.",
    imageUri: 'https://cards.scryfall.io/large/front/7/b/7be07e97-2ffc-40ad-a676-a74b8b680ea1.jpg',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: { type: 'reveal_top_pick_land_rest_grave', amount: 4 },
      }),
    ],
    artId: 322, plan: 'Theros',
    support: { status: 'supported', limitations: [] },
    notes: ['decyzja kontrolera: może wziąć ląd z odsłoniętych do ręki albo zrezygnować (you may); reszta zawsze do grobu'],
  }),

  // 5. Strandwalker (MBS) {5} Artifact — Equipment: Living weapon;
  //    +2/+4 and reach; Equip {4}.
  defineCard({
    id: 'strandwalker', name: 'Strandwalker', set: 'MBS',
    types: ['Artifact'], subtypes: ['Equipment'], colors: [], manaCost: 5,
    oracleText: "Living weapon (When this Equipment enters, create a 0/0 black Phyrexian Germ creature token, then attach this to it.)\\nEquipped creature gets +2/+4 and has reach.\\nEquip {4}",
    imageUri: 'https://cards.scryfall.io/large/front/d/0/d0d7ff8f-7733-4323-8575-c50b3e730dbc.jpg',
    equipment: { equip: 4, pump: { power: 2, toughness: 4 }, keywords: ['reach'] },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: { type: 'living_weapon' },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'equip',
        cost: { mana: 4 },
        effect: [],
      }),
    ],
    artId: 228, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  // Token Germ (Strandwalker — Living weapon): 0/0 czarny Phyrexian Germ
  // (żyje dzięki +2/+4 z equipmentu).
  defineCard({
    id: 'token_germ', name: 'Germ', set: null,
    imageUri: 'https://cards.scryfall.io/large/front/6/5/65c65445-1016-4fd3-963e-1c9eb252d4a6.jpg?1783903574', // M157/B: token ze Scryfall
    types: ['Creature', 'Token'], subtypes: ['Phyrexian', 'Germ'], colors: ['B'],
    power: 0, toughness: 0, manaCost: 0,
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; tworzony przez Strandwalker (living weapon)'] },
  }),

  // 7. Urza's Mine (2XM) Land — Urza's Mine: {T}: Add {C}; tron (CR 702.??):
  //    jeśli kontrolujesz Urza's Power-Plant i Urza's Tower → {C}{C}.
  //    Produkcja many przez MANA_SOURCE_MAP (mana-sources.js), gdzie tron
  //    jest już zakodowany generycznie (tronRequired). Karta to dane — wystarczy
  //    w przyszłości dodać urza-s-power-plant i urza-s-tower, by tron zadziałał.
  defineCard({
    id: 'urza-s-mine', name: "Urza's Mine", set: '2XM',
    types: ['Land'], subtypes: ['Urza\'s Mine'], colors: [], manaCost: 0,
    oracleText: "{T}: Add {C}. If you control an Urza's Power-Plant and an Urza's Tower, add {C}{C} instead.",
    imageUri: 'https://cards.scryfall.io/large/front/0/8/08dea8f6-bd32-44a3-bec4-93a5607819df.jpg',
    artId: 220, plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
    notes: ['tron (Power-Plant + Tower) nie jest w katalogu — produkcja {C} zawsze; warunek zakodowany w mana-sources.js (tronRequired), zadziała po dodaniu pozostałych lądów Urzy (decyzja właściciela 2026-08-19)'],
  }),

  // =========================================================================
  // Batch 38 (2026-08-19, lista właściciela). Oracle ze Scryfalla
  // (docs/cards/scryfall-*.json, ADR 0010 §2a), artId i plan ze słownika
  // tools/collection-art-ids.csv. Transza A: reuse mechanik + nowe generyczne.
  // =========================================================================

  // 1. Divine Offering (MBS) {1}{W} Instant — destroy target artifact,
  //    gain life = its mana value.
  defineCard({
    id: 'divine-offering', name: 'Divine Offering', set: 'MBS',
    types: ['Instant'], colors: ['W'], manaCost: 2,
    oracleText: 'Destroy target artifact. You gain life equal to its mana value.',
    imageUri: 'https://cards.scryfall.io/large/front/f/e/fe7c7a65-5a96-4986-877b-b34583092bb6.jpg?1783941393',
    spell: {
      timing: 'instant',
      targets: [{ type: 'artifact' }],
      effects: [{ type: 'destroy_artifact_gain_life_mana_value' }],
    },
    artId: 47,
    plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Colossodon Yearling (DTK) {2}{G} 2/4 Beast — bez zdolności.
  defineCard({
    id: 'colossodon-yearling', name: 'Colossodon Yearling', set: 'DTK',
    types: ['Creature'], subtypes: ['Beast'], colors: ['G'],
    power: 2, toughness: 4, manaCost: 3,
    oracleText: '',
    imageUri: 'https://cards.scryfall.io/large/front/f/2/f2c60e63-0b86-4100-a932-bb9e9b197610.jpg?1783938581',
    artId: 444, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Fortify (TSP) {2}{W} Instant — choose one: your creatures +2/+0 OR +0/+2.
  defineCard({
    id: 'fortify', name: 'Fortify', set: 'TSP',
    types: ['Instant'], colors: ['W'], manaCost: 3,
    oracleText: 'Choose one —\n• Creatures you control get +2/+0 until end of turn.\n• Creatures you control get +0/+2 until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/b/4/b47af529-6ba1-4900-a6f6-7647c9632e11.jpg?1783927882',
    spell: {
      timing: 'instant',
      modes: [
        { name: 'Ofensywa (+2/+0)', effects: [{ type: 'buff_creatures_you_control', power: 2, toughness: 0 }] },
        { name: 'Obrona (+0/+2)', effects: [{ type: 'buff_creatures_you_control', power: 0, toughness: 2 }] },
      ],
    },
    artId: 94, plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
  }),

  // 6. Mysidian Elder (FIN) {2}{R} 1/3 Human Wizard — ETB: create 0/1 black
  //    Wizard token with "Whenever you cast a noncreature spell, this token
  //    deals 1 damage to each opponent."
  defineCard({
    id: 'mysidian-elder', name: 'Mysidian Elder', set: 'FIN',
    types: ['Creature'], subtypes: ['Human', 'Wizard'], colors: ['R'],
    power: 1, toughness: 3, manaCost: 3,
    oracleText: 'When this creature enters, create a 0/1 black Wizard creature token with \"Whenever you cast a noncreature spell, this token deals 1 damage to each opponent.\"',
    imageUri: 'https://cards.scryfall.io/large/front/6/b/6bc39af4-be19-4889-b930-df7ebf7b9481.jpg?1783906602',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: {
          type: 'create_token', cardId: 'token_wizard', name: 'Wizard',
          kind: 'creature', power: 0, toughness: 1, colors: ['B'],
          types: ['Creature'], subtypes: ['Wizard'],
          abilities: [
            createAbility({
              type: ABILITY_TYPE.triggered,
              trigger: { event: 'you_cast_noncreature_spell' },
              effect: { type: 'damage_each_opponent', amount: 1 },
            }),
          ],
        },
      }),
    ],
    artId: 59, plan: 'Final Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 7. Pristine Talisman (NPH) {3} Artifact — {T}: Add {C}. You gain 1 life.
  defineCard({
    id: 'pristine-talisman', name: 'Pristine Talisman', set: 'NPH',
    types: ['Artifact'], colors: [], manaCost: 3,
    oracleText: '{T}: Add {C}. You gain 1 life.',
    imageUri: 'https://cards.scryfall.io/large/front/6/b/6b6307f3-bc63-463c-8ffc-a8b8b829e5d7.jpg?1783927507',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        effect: [
          { type: 'add_mana', amount: 1 },
          { type: 'gain_life', amount: 1 },
        ],
      }),
    ],
    artId: 347, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Chatter of the Squirrel (2XM) {G} Sorcery — create 1/1 green Squirrel
  //    token; Flashback {1}{G}.
  defineCard({
    id: 'chatter-of-the-squirrel', name: 'Chatter of the Squirrel', set: '2XM',
    types: ['Sorcery'], colors: ['G'], manaCost: 1,
    oracleText: 'Create a 1/1 green Squirrel creature token.\nFlashback {1}{G} (You may cast this card from your graveyard for its flashback cost. Then exile it.)',
    imageUri: 'https://cards.scryfall.io/large/front/5/f/5f7e1991-9ffa-4a57-b8eb-ebe542a47f09.jpg?1783930150',
    spell: {
      timing: 'sorcery',
      targets: [],
      effects: [{
        type: 'create_token', cardId: 'token_squirrel', name: 'Squirrel',
        kind: 'creature', power: 1, toughness: 1, colors: ['G'],
        types: ['Creature'], subtypes: ['Squirrel'],
      }],
      flashback: { cost: 2, colors: ['G'] },
    },
    artId: 310, plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
  }),

  // 9. Silken Strength (DFT) {1}{G} Aura (flash) — Enchant creature or Vehicle;
  //    ETB untap enchanted; enchanted gets +1/+2 and has reach.
  defineCard({
    id: 'silken-strength', name: 'Silken Strength', set: 'DFT',
    types: ['Enchantment'], subtypes: ['Aura'], colors: ['G'], manaCost: 2,
    keywords: ['flash'],
    oracleText: 'Flash\nEnchant creature or Vehicle\nWhen this Aura enters, untap enchanted permanent.\nEnchanted permanent gets +1/+2 and has reach.',
    imageUri: 'https://cards.scryfall.io/large/front/c/e/ce0e1ded-9b00-4d7b-884c-70a429783b1f.jpg?1783907865',
    aura: { enchantType: 'creature_or_vehicle', pump: { power: 1, toughness: 2 }, keywords: ['reach'] },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: { type: 'untap_enchanted_permanent' },
      }),
    ],
    artId: 457, plan: 'Kaladesh',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Weftblade Enhancer (EOE) {5}{W} 3/4 Drix Artificer — ETB: +1/+1 counter
  //    on up to two target creatures; Warp {2}{W}.
  defineCard({
    id: 'weftblade-enhancer', name: 'Weftblade Enhancer', set: 'EOE',
    types: ['Creature'], subtypes: ['Drix', 'Artificer'], colors: ['W'],
    power: 3, toughness: 4, manaCost: 6,
    oracleText: 'When this creature enters, put a +1/+1 counter on each of up to two target creatures.\nWarp {2}{W} (You may cast this card from your hand for its warp cost. Exile this creature at the beginning of the next end step, then you may cast it from exile on a later turn.)',
    imageUri: 'https://cards.scryfall.io/large/front/8/d/8d72b00c-5043-4630-949a-fc17eeb962bc.jpg?1783905986',
    // Warp (CR EOE): alternatywny koszt {2}{W} z ręki; przy wejściu zbroimy
    // opóźniony trigger wygnania w najbliższym kroku końcowym; po wygnaniu
    // (warpReady) można rzucić z exile za koszt warp w późniejszej turze.
    warp: { cost: 3, colors: ['W'] },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        // ADR 0022 / M157 F4(a): „each of up to two target creatures" —
        // pełne Oracle: dwa cele (count: 2, upTo — może być mniej/zero).
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'creature', count: 2, upTo: true } },
        effect: { type: 'add_counter', counter: '+1/+1', amount: 1 },
      }),
    ],
    artId: 286, plan: 'The Edge',
    support: { status: 'supported', limitations: [] },
    notes: ['Warp: rzut z ręki za {2}{W}, wygnanie w najbliższym kroku końcowym (warpReady), rzut z exile za {2}{W} w późniejszej turze'],
  }),

  // 4. Talion's Messenger (WOE) {2}{U} 1/3 Faerie Noble Flying — attack with a
  //    Faerie → draw, discard, +1/+1 counter on target Faerie you control.
  defineCard({
    id: 'talions-messenger', name: "Talion's Messenger", set: 'WOE',
    types: ['Creature'], subtypes: ['Faerie', 'Noble'], colors: ['U'],
    keywords: ['flying'], power: 1, toughness: 3, manaCost: 3,
    oracleText: 'Flying\nWhenever you attack with one or more Faeries, draw a card, then discard a card. When you discard a card this way, put a +1/+1 counter on target Faerie you control.',
    imageUri: 'https://cards.scryfall.io/large/front/3/5/35fb0640-5b04-4687-b863-46a8b8d36809.jpg?1783915114',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'faerie_attacks', requiresTarget: { type: 'creature_you_control', subtype: 'Faerie' } },
        effect: [
          { type: 'draw_cards', amount: 1 },
          { type: 'discard_cards', amount: 1 },
          { type: 'add_counter', counter: '+1/+1', amount: 1 },
        ],
      }),
    ],
    artId: 166,
    plan: 'Eldraine',
    support: { status: 'supported', limitations: [] },
    notes: ['faerie_attacks: odpala się raz na combat, gdy atakujący kontroler atakuje z ≥1 Faerie; licznik na docelowym Faerie (requiresTarget creature_you_control+subtype)', '„when you discard a card this way” uproszczone: zawsze dobiera+odrzuca, więc licznik zawsze się pojawia (po wyborze Faerie)'],
  }),

  // 10. Lotusguard Disciple (DFT) {2}{W} 2/2 Bird Cleric Flying — ETB: target
  //     creature or Vehicle gains lifelink and indestructible until end of turn.
  defineCard({
    id: 'lotusguard-disciple', name: 'Lotusguard Disciple', set: 'DFT',
    types: ['Creature'], subtypes: ['Bird', 'Cleric'], colors: ['W'],
    keywords: ['flying'], power: 2, toughness: 2, manaCost: 3,
    oracleText: 'Flying\nWhen this creature enters, target creature or Vehicle gains lifelink and indestructible until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/8/0/80645651-3804-481f-8f8f-ade762a011e1.jpg?1783907916',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'creature_or_vehicle' } },
        effect: { type: 'grant_keywords_until_end_of_turn', keywords: ['lifelink', 'indestructible'] },
      }),
    ],
    artId: 18, plan: 'Amonkhet',
    support: { status: 'supported', limitations: [] },
  }),

  // ---- Batch 39 (lista właściciela 2026-08-20) — transza A: czyste reuse ----
  defineCard({
    id: 'merfolk-mesmerist', name: 'Merfolk Mesmerist', set: 'M12',
    types: ['Creature'], subtypes: ['Merfolk', 'Wizard'], colors: ['U'],
    power: 1, toughness: 2, manaCost: 2,
    oracleText: '{U}, {T}: Target player mills two cards.',
    imageUri: 'https://cards.scryfall.io/large/front/2/2/220dede5-472c-4a09-bdf0-73e722d9d4d2.jpg?1783941089',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 1, colors: ['U'], tap: true },
        targets: [{ type: 'player' }],
        effect: { type: 'mill_cards', amount: 2 },
      }),
    ],
    artId: 115,
    plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'knight-of-the-skyward-eye', name: 'Knight of the Skyward Eye', set: 'ALA',
    types: ['Creature'], subtypes: ['Human', 'Knight'], colors: ['W'],
    power: 2, toughness: 2, manaCost: 2,
    oracleText: '{3}{G}: This creature gets +3/+3 until end of turn. Activate only once each turn.',
    imageUri: 'https://cards.scryfall.io/large/front/1/d/1d56e2bf-1937-42c1-8f61-1fd93e84cef7.jpg?1783942581',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 4, colors: ['G'] },
        effect: { type: 'pump', power: 3, toughness: 3 },
        oncePerTurn: true,
      }),
    ],
    artId: 242,
    plan: 'Alara',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'breaching-hippocamp', name: 'Breaching Hippocamp', set: 'THS',
    types: ['Creature'], subtypes: ['Horse', 'Fish'], colors: ['U'],
    keywords: ['flash'], power: 3, toughness: 2, manaCost: 4,
    oracleText: 'Flash (You may cast this spell any time you could cast an instant.)\nWhen this creature enters, untap another target creature you control.',
    imageUri: 'https://cards.scryfall.io/large/front/8/8/8841c01e-015e-4541-942a-f8859dd03fea.jpg?1783939802',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'creature_you_control', notSelf: true } },
        effect: { type: 'untap_permanent' },
      }),
    ],
    artId: 133,
    plan: 'Theros',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'squires-lightblade', name: "Squire's Lightblade", set: 'EOE',
    types: ['Artifact'], subtypes: ['Equipment'], colors: ['W'], manaCost: 1,
    keywords: ['flash'],
    oracleText: 'Flash\nWhen this Equipment enters, attach it to target creature you control. That creature gains first strike until end of turn.\nEquipped creature gets +1/+0.\nEquip {3}',
    imageUri: 'https://cards.scryfall.io/large/front/2/a/2a0accba-85d4-4aa4-a70c-80fcce48c261.jpg?1783905989',
    equipment: { equip: 3, pump: { power: 1, toughness: 0 } },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'creature_you_control' } },
        effect: [
          { type: 'attach_self_to_target' },
          { type: 'grant_keywords_until_end_of_turn', keywords: ['first_strike'] },
        ],
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'equip',
        cost: { mana: 3 },
        effect: [],
      }),
    ],
    artId: 524,
    plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // ---- Batch 39 — transza B: proste nowe mechaniki ----
  defineCard({
    id: 'exterminator-magmarch', name: 'Exterminator Magmarch', set: 'M3C',
    types: ['Artifact', 'Creature'], subtypes: ['Phyrexian', 'Construct'], colors: ['B', 'R'],
    power: 5, toughness: 3, manaCost: 4,
    oracleText: 'Whenever you cast an instant or sorcery spell that targets only a single nonland permanent an opponent controls, if another opponent controls one or more nonland permanents that spell could target, choose one of those permanents. Copy that spell. The copy targets the chosen permanent.\n{1}{B}: Regenerate this creature.',
    imageUri: 'https://cards.scryfall.io/large/front/2/e/2e600de8-6afa-46d8-ba87-552798cdb040.jpg?1783911405',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        // Trigger multiplayer: w 1v1 warunek „another opponent" jest martwy
        // z definicji formatu (decyzja ADR 0022 — fakt formatu, jak brak
        // strefy dowodzenia). Działa od razu, gdy engine pozna >2 graczy.
        trigger: { event: 'when_you_cast_spell', condition: { anotherOpponentExists: true } },
        effect: [],
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2, colors: ['B'] },
        effect: { type: 'regenerate' },
      }),
    ],
    artId: 501,
    plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
    notes: ['trigger kopiowania wymaga DRUGIEGO przeciwnika — w 1v1 nigdy się nie odpala (fakt formatu, jak brak command zone); {1}{B}: Regenerate = tarcza regeneracji do końca tury (CR 701.12)'],
  }),
  defineCard({
    id: 'dire-fleet-ravager', name: 'Dire Fleet Ravager', set: 'OTC',
    types: ['Creature'], subtypes: ['Orc', 'Pirate', 'Wizard'], colors: ['B'],
    keywords: ['menace', 'deathtouch'], power: 4, toughness: 4, manaCost: 5,
    oracleText: 'Menace, deathtouch\nWhen this creature enters, each player loses a third of their life, rounded up.',
    imageUri: 'https://cards.scryfall.io/large/front/0/d/0d114e88-c5bd-416d-b9f1-25be1432c98c.jpg?1783911931',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: { type: 'each_player_loses_life_fraction', numerator: 1, denominator: 3 },
      }),
    ],
    artId: 177,
    plan: 'Ixalan',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'wishful-merfolk', name: 'Wishful Merfolk', set: 'ELD',
    types: ['Creature'], subtypes: ['Merfolk'], colors: ['U'],
    keywords: ['defender'], power: 3, toughness: 2, manaCost: 2,
    oracleText: 'Defender\n{1}{U}: This creature loses defender and becomes a Human until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/f/9/f9358d5d-726e-43e0-a58e-4cfe7c755913.jpg?1783932647',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2, colors: ['U'] },
        effect: { type: 'becomes_subtype_until_end_of_turn', subtypes: ['Human'], losesKeywords: ['defender'] },
      }),
    ],
    artId: 432,
    plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
  }),

  // ---- Batch 39 — transza C: wielocelowy czar „each of up to N" ----
  defineCard({
    id: 'wrap-in-flames', name: 'Wrap in Flames', set: 'MM2',
    types: ['Sorcery'], colors: ['R'], manaCost: 4,
    oracleText: 'Wrap in Flames deals 1 damage to each of up to three target creatures. Those creatures can\'t block this turn.',
    imageUri: 'https://cards.scryfall.io/large/front/8/2/82e1dcb2-9471-48d9-98c8-12194e3a88ac.jpg?1783938401',
    spell: {
      timing: 'sorcery',
      modes: [{
        name: 'Owinięcie w płomienie',
        variableTargets: { max: 3, min: 0 },
        effects: [{
          type: 'apply_to_each_target',
          effects: [
            { type: 'damage', amount: 1 },
            { type: 'cant_block' },
          ],
        }],
      }],
    },
    artId: 116,
    plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // ---- Batch 39 — transza D: Saga z rozdziałami warunkowymi ----
  defineCard({
    id: 'invasion-of-the-giants', name: 'Invasion of the Giants', set: 'KHM',
    types: ['Enchantment'], subtypes: ['Saga'], colors: ['R', 'U'], manaCost: 2,
    oracleText: '(As this Saga enters and after your draw step, add a lore counter. Sacrifice after III.)\nI — Scry 2.\nII — Draw a card. Then you may reveal a Giant card from your hand. When you do, this Saga deals 2 damage to target opponent or planeswalker.\nIII — The next Giant spell you cast this turn costs {2} less to cast.',
    imageUri: 'https://cards.scryfall.io/large/front/7/f/7f5075a0-c72a-474c-937c-95dc9205d14f.jpg?1783928196',
    saga: {
      chapters: [
        // I — Scry 2.
        [{ type: 'scry', amount: 2 }],
        // II — dobierz + opcjonalne ujawnienie Olbrzyma za 2 obrażenia
        // przeciwnika (pendingRevealChoice; w 1v1 planeswalker nie istnieje).
        [{ type: 'draw_cards', amount: 1 }, { type: 'reveal_subtype_deal_damage', subtype: 'Giant', amount: 2 }],
        // III — następny czar Olbrzyma w tej turze tańszy o {2} (rabat
        // konsumowany przez rzut; w katalogu nie ma jeszcze Olbrzymów —
        // decyzja właściciela 2026-08-19: efekty warunkowe kodujemy TERAZ).
        [{ type: 'next_spell_discount', amount: 2, subtype: 'Giant' }],
      ],
    },
    artId: 330,
    plan: 'Kaldheim',
    support: { status: 'supported', limitations: [] },
    notes: ['II: planeswalker-cel nie istnieje w 1v1 — obrażenia idą w przeciwnika', 'III: zadziała od razu po dodaniu pierwszej karty z podtypem Giant'],
  }),

  // ---- Batch 39 — transza E: Madness (CR 702.34) ----
  defineCard({
    id: 'revolutionist', name: 'Revolutionist', set: 'MH2',
    types: ['Creature'], subtypes: ['Human', 'Wizard'], colors: ['R'],
    power: 3, toughness: 3, manaCost: 6,
    oracleText: 'When this creature enters, return target instant or sorcery card from your graveyard to your hand.\nMadness {3}{R} (If you discard this card, discard it into exile. When you do, cast it for its madness cost or put it into your graveyard.)',
    imageUri: 'https://cards.scryfall.io/large/front/b/b/bb8f3008-a3ba-4f73-afa6-ad81074b3196.jpg?1783926839',
    madness: { cost: 4, colors: ['R'] },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: {
          event: 'enter_battlefield',
          // M159/F3 (audyt PR #66, ADR 0022): cel OBOWIĄZKOWY — Oracle mówi
          // „return target instant or sorcery card...”, bez „you may”
          // (inaczej niż Mystic Sanctuary, które „you may” MA — tam optional
          // zostaje). Brak legalnych celów = trigger nie robi nic (CR 608.2b).
          requiresTarget: { type: 'instant_or_sorcery_card_in_graveyard', controlledBy: 'controller' },
        },
        effect: { type: 'return_card_from_graveyard_to_hand' },
      }),
    ],
    // M167/H: artId ze słownika kolekcji (tools/collection-art-ids.csv: 314MH2).
    artId: 314, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
    notes: ['Madness: odrzucenie trafia do exile z jednorazową decyzją rzutu za {3}{R} (timing ignorowany — CR 702.34a) albo przełożenia do grobu'],
  }),

  // =========================================================================
  // Batch 40 (10 kart, lista właściciela 2026-08-20) — transza A: reuse.
  // Dane Scryfall: docs/cards/scryfall-*.json (ADR 0010 §2a).
  // =========================================================================

  // 1. Blade-Blizzard Kitsune (NEO) {2}{W} 2/2 Fox Ninja — ninjutsu {3}{W}
  //    + double strike (oba istnieją: Kappa Batch 1, double strike Batch 21).
  defineCard({
    id: 'blade-blizzard-kitsune', name: 'Blade-Blizzard Kitsune', set: 'NEO',
    types: ['Creature'], subtypes: ['Fox', 'Ninja'], colors: ['W'],
    keywords: ['double_strike'], power: 2, toughness: 2, manaCost: 3,
    oracleText: 'Ninjutsu {3}{W} ({3}{W}, Return an unblocked attacker you control to hand: Put this card onto the battlefield from your hand tapped and attacking.)\nDouble strike',
    imageUri: 'https://cards.scryfall.io/large/front/d/8/d8419d27-8c6e-4f38-98b4-60dd9a910c43.jpg?1783923926',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'ninjutsu',
        cost: { mana: 4, colors: ['W'] },
      }),
    ],
    artId: 105, plan: 'Kamigawa',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Knockout Maneuver (TDM) {2}{G} Sorcery — licznik +1/+1 na swoim
  //    stworze, POTEM zadaje obrażenia równe mocy (z licznikiem — efekty
  //    sekwencyjne, damage_from_target_power czyta effectivePower) w stwora
  //    przeciwnika (wzorzec Diplomatic Relations, Batch 38).
  defineCard({
    id: 'knockout-maneuver', name: 'Knockout Maneuver', set: 'TDM',
    types: ['Sorcery'], colors: ['G'], manaCost: 3,
    oracleText: 'Put a +1/+1 counter on target creature you control, then it deals damage equal to its power to target creature an opponent controls.',
    imageUri: 'https://cards.scryfall.io/large/front/9/d/9d218831-2a41-46a3-8e9d-93462cae5cab.jpg?1783907340',
    spell: {
      timing: 'sorcery',
      // CR 608.2b: „then" — sekwencja: licznik najpierw (cel 0), obrażenia
      // = moc PO liczniku (effectivePower czyta +1/+1 wliczone).
      targets: [{ type: 'creature_you_control' }, { type: 'creature_opponent_controls' }],
      effects: [
        { type: 'add_counter', counter: '+1/+1', amount: 1, targetIndex: 0 },
        { type: 'damage_from_target_power', sourceTargetIndex: 0, targetIndex: 1 },
      ],
    },
    artId: 463, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Krotiq Nestguard (TDM) {2}{G} 4/4 Insect — defender; {2}{G}: może
  //    atakować w tej turze jakby nie miał defendera (lostKeywordsUntilEOT —
  //    warstwa z Wishful Merfolk; cleanup końca tury przywraca).
  defineCard({
    id: 'krotiq-nestguard', name: 'Krotiq Nestguard', set: 'TDM',
    types: ['Creature'], subtypes: ['Insect'], colors: ['G'],
    keywords: ['defender'], power: 4, toughness: 4, manaCost: 3,
    oracleText: 'Defender\n{2}{G}: This creature can attack this turn as though it didn\'t have defender.',
    imageUri: 'https://cards.scryfall.io/large/front/a/5/a5d0a9fb-1068-478d-a78c-6fd77cc313f0.jpg?1783907339',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 3, colors: ['G'] },
        // „attack as though it didn't have defender" = utrata defendera
        // do końca tury (przenośnik generyczny becomes_subtype_until_end_of_
        // turn bez nadpisywania podtypów — niesie wyłącznie losesKeywords).
        effect: [{ type: 'becomes_subtype_until_end_of_turn', losesKeywords: ['defender'] }],
      }),
    ],
    artId: 81, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
    notes: ['aktywacja odsuwa defendera do końca tury (cleanup przywraca) — atak legalny po aktywacji, w następnej turze znów nie'],
  }),

  // ---- Batch 40 — transza B: nowe słowa kluczowe proste ----

  // 4. Cacophodon (RIX) {3}{G} 2/5 Dinosaur — Enrage: gdy otrzyma obrażenia,
  //    odkręć celowany permanent (NOWY trigger event 'dealt_damage';
  //    untap_permanent istnieje — Twiddle, M146).
  defineCard({
    id: 'cacophodon', name: 'Cacophodon', set: 'RIX',
    types: ['Creature'], subtypes: ['Dinosaur'], colors: ['G'],
    power: 2, toughness: 5, manaCost: 4,
    oracleText: 'Enrage — Whenever this creature is dealt damage, untap target permanent.',
    imageUri: 'https://cards.scryfall.io/large/front/3/5/351b213e-b23e-4287-947a-6bd81f1cf751.jpg?1783935290',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'dealt_damage', requiresTarget: { type: 'permanent' } },
        effect: { type: 'untap_permanent' },
      }),
    ],
    artId: 468, plan: 'Ixalan',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Feed the Infection (ONE) {3}{B} Sorcery — draw 3, lose 3; Corrupted:
  //    każdy przeciwnik z >=3 poison traci 3 życia (NOWY efekt
  //    opponents_lose_life_if_poison; poison w stanie gry od M157/F).
  defineCard({
    id: 'feed-the-infection', name: 'Feed the Infection', set: 'ONE',
    types: ['Sorcery'], colors: ['B'], manaCost: 4,
    oracleText: 'You draw three cards and you lose 3 life.\nCorrupted — Each opponent who has three or more poison counters loses 3 life.',
    imageUri: 'https://cards.scryfall.io/large/front/9/f/9f013a1a-d4b9-4380-9802-c299ee6c4492.jpg?1783918046',
    spell: {
      timing: 'sorcery',
      targets: [],
      effects: [
        { type: 'draw_cards', amount: 3 },
        // "you lose 3 life" — scope controller (lose_life domyślnie celuje przeciwników).
        { type: 'lose_life', amount: 3, scope: 'controller' },
        { type: 'opponents_lose_life_if_poison', min: 3, amount: 3 },
      ],
    },
    artId: 207, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  // 6. Mosquito Guard (MOR) {W} 1/1 Kithkin Soldier — first strike +
  //    Reinforce 1—{1}{W} (NOWE słowo: zdolność z RĘKI, koszt mana + discard,
  //    licznik +1/+1 na celu stworze; wzorzec cycling/channel + cele forecast).
  defineCard({
    id: 'mosquito-guard', name: 'Mosquito Guard', set: 'MOR',
    types: ['Creature'], subtypes: ['Kithkin', 'Soldier'], colors: ['W'],
    keywords: ['first_strike'], power: 1, toughness: 1, manaCost: 1,
    oracleText: 'First strike\nReinforce 1—{1}{W} ({1}{W}, Discard this card: Put a +1/+1 counter on target creature.)',
    imageUri: 'https://cards.scryfall.io/large/front/5/e/5e5bca35-5098-4100-815b-de141c82eb6a.jpg?1783942803',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2, colors: ['W'] },
        reinforce: { amount: 1 },
        targets: [{ type: 'creature' }],
        effect: [{ type: 'add_counter', counter: '+1/+1', amount: 1, targetIndex: 0 }],
      }),
    ],
    artId: 106, plan: 'Lorwyn',
    support: { status: 'supported', limitations: [] },
  }),

  // ---- Batch 40 — transza C: płatność/warunki ----

  // 7. Locthwain Paladin (ELD) {3}{B} 3/2 Human Knight — menace + Adamant:
  //    >=3 czarnej many wydanej na rzut -> ETB z +1/+1 (breakdown kolorów
  //    many z spendMana; entersWithCountersIf.adamant).
  defineCard({
    id: 'locthwain-paladin', name: 'Locthwain Paladin', set: 'ELD',
    types: ['Creature'], subtypes: ['Human', 'Knight'], colors: ['B'],
    keywords: ['menace'], power: 3, toughness: 2, manaCost: 4,
    oracleText: 'Menace (This creature can\'t be blocked except by two or more creatures.)\nAdamant — If at least three black mana was spent to cast this spell, this creature enters with a +1/+1 counter on it.',
    imageUri: 'https://cards.scryfall.io/large/front/d/a/da6f21a8-3dd0-42af-8a93-84f98968c781.jpg?1783932637',
    entersWithCountersIf: { adamant: { color: 'B', min: 3 }, counters: { '+1/+1': 1 } },
    artId: 445, plan: 'Eldraine',
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Sarkhan's Rage (DTK) {4}{R} Instant — 5 obrażeń w dowolny cel;
  //    bez kontrolowanego Smoka 2 obrażenia w rzucającego (warunek
  //    generyczny controlsNoCreatureSubtype + damage_to_controller).
  defineCard({
    id: 'sarkhans-rage', name: "Sarkhan's Rage", set: 'DTK',
    types: ['Instant'], colors: ['R'], manaCost: 5,
    oracleText: "Sarkhan's Rage deals 5 damage to any target. If you control no Dragons, Sarkhan's Rage deals 2 damage to you.",
    imageUri: 'https://cards.scryfall.io/large/front/4/7/4787924f-3186-4e18-b53c-dd67c5f42220.jpg?1783938586',
    spell: {
      timing: 'instant',
      targets: [{ type: 'any_target' }],
      effects: [
        { type: 'damage', amount: 5 },
        { type: 'conditional', condition: 'controlsNoCreatureSubtype', subtype: 'Dragon',
          then: { type: 'damage_to_controller', amount: 2 } },
      ],
    },
    artId: 287, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),

  // 9. Inferno Titan (LTC) {4}{R}{R} 6/6 Giant — {R}: +1/+0 EOT; przy
  //    wejściu i ataku: 3 obrażenia DZIELONE DOWOLNIE na 1-3 celów
  //    (multi-target M157/F4a + NOWA decyzja kwot resolve_damage_division).
  defineCard({
    id: 'inferno-titan', name: 'Inferno Titan', set: 'LTC',
    types: ['Creature'], subtypes: ['Giant'], colors: ['R'],
    power: 6, toughness: 6, manaCost: 6,
    oracleText: '{R}: This creature gets +1/+0 until end of turn.\nWhenever this creature enters or attacks, it deals 3 damage divided as you choose among one, two, or three targets.',
    imageUri: 'https://cards.scryfall.io/large/front/d/b/db61b57c-b870-41af-87b7-037ec52fe063.jpg?1783915930',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 1, colors: ['R'] },
        effect: { type: 'pump', power: 1, toughness: 0 },
      }),
      // Jeden wiersz Oracle = dwa zdarzenia triggera (wejście + atak);
      // behavior tożsamy z CR 603.2 (trigger „whenever enters or attacks").
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'any_target', count: 3, upTo: true } },
        effect: { type: 'damage_divided', amount: 3 },
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'attacks', requiresTarget: { type: 'any_target', count: 3, upTo: true } },
        effect: { type: 'damage_divided', amount: 3 },
      }),
    ],
    artId: 202, plan: 'Śródziemie',
    support: { status: 'supported', limitations: [] },
    notes: ['podział obrażeń: cele (1-3) wybierane w decyzji multi-target, kwoty w JEDNEJ komendzie resolve_damage_division (kompozycje 3=[3]|[2,1]|[1,1,1])'],
  }),

  // 10. Cenn's Tactician (MOR) {W} 1/1 Kithkin Soldier — {W},{T}: licznik
  //     +1/+1 na celu Soldierze; statyka: każdy stwór z licznikiem +1/+1
  //     blokuje DODATKOWEGO stwora w każdym combacie (blockSlotsFor w
  //     combat.js — walidacja i enumeracja).
  defineCard({
    id: 'cenns-tactician', name: "Cenn's Tactician", set: 'MOR',
    types: ['Creature'], subtypes: ['Kithkin', 'Soldier'], colors: ['W'],
    power: 1, toughness: 1, manaCost: 1,
    oracleText: '{W}, {T}: Put a +1/+1 counter on target Soldier creature.\nEach creature you control with a +1/+1 counter on it can block an additional creature each combat.',
    imageUri: 'https://cards.scryfall.io/large/front/d/9/d998c949-4791-477f-ab8d-e625199623ad.jpg?1783942807',
    abilities: [
      createAbility({ type: ABILITY_TYPE.static, grantsExtraBlockWithCounter: '+1/+1' }),
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 1, colors: ['W'], tap: true },
        targets: [{ type: 'creature_with_subtypes', subtypes: ['Soldier'] }],
        effect: [{ type: 'add_counter', counter: '+1/+1', amount: 1, targetIndex: 0 }],
      }),
    ],
    artId: 442, plan: 'Lorwyn',
    support: { status: 'supported', limitations: [] },
  }),

// =========================================================================
  // Batch 41 (10 kart, lista właściciela 2026-08-21) — transza A: reuse.
  // Dane Scryfall: docs/cards/scryfall-*.json (ADR 0010 §2a).
  // =========================================================================

  // 1. Spin Out (DFT) {1}{B}{B} Instant — „Destroy target creature or
  //    Vehicle." (cel creature_or_vehicle — M154; destroy_permanent).
  defineCard({
    id: 'spin-out', name: 'Spin Out', set: 'DFT',
    types: ['Instant'], colors: ['B'], manaCost: 3,
    oracleText: 'Destroy target creature or Vehicle.',
    imageUri: 'https://cards.scryfall.io/large/front/b/e/be722ac5-e8c4-4180-aed0-7c28895afc0d.jpg?1783907889',
    spell: {
      timing: 'instant',
      targets: [{ type: 'creature_or_vehicle' }],
      effects: [{ type: 'destroy_permanent' }],
    },
    artId: 119, plan: 'Kaladesh',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Stall Out (DFT) {1}{U} Sorcery — tap + 3 liczniki stun na stworze
  //    lub Vehicle; Cycling {2} (wszystko reuse: stun M?, cycling generic).
  defineCard({
    id: 'stall-out', name: 'Stall Out', set: 'DFT',
    types: ['Sorcery'], colors: ['U'], manaCost: 2,
    oracleText: 'Tap target creature or Vehicle, then put three stun counters on it. (If a permanent with a stun counter would become untapped, remove one from it instead.)\nCycling {2} ({2}, Discard this card: Draw a card.)',
    imageUri: 'https://cards.scryfall.io/large/front/4/e/4ea0e0d3-833f-4353-b648-57b0b657cc1c.jpg?1783907902',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'creature_or_vehicle' }],
      // CR 608.2c „then": najpierw tap, potem liczniki — oba na tym samym celu.
      effects: [
        { type: 'tap_permanent', targetIndex: 0 },
        { type: 'add_counter', counter: 'stun', amount: 3, targetIndex: 0 },
      ],
    },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'cycling',
        cost: { mana: 2 },
        cycling: { drawCards: 1 },
        effect: [],
      }),
    ],
    artId: 61, plan: 'Kaladesh',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Horizon Spellbomb (SOM) {1} Artifact — bliźniak Panic Spellbomba
  //    (ten sam cykl SOM): {2},{T},sac: szukaj basic land DO RĘKI;
  //    dies: „you may pay {G} → draw" (trigger dies + payMana/payColors).
  defineCard({
    id: 'horizon-spellbomb', name: 'Horizon Spellbomb', set: 'SOM',
    types: ['Artifact'], colors: [], manaCost: 1,
    oracleText: '{2}, {T}, Sacrifice this artifact: Search your library for a basic land card, reveal it, put it into your hand, then shuffle.\nWhen this artifact is put into a graveyard from the battlefield, you may pay {G}. If you do, draw a card.',
    imageUri: 'https://cards.scryfall.io/large/front/9/d/9d93378e-1de2-4954-9458-dd3306f2996e.jpg?1783941707',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2, tap: true, sacrificeSelf: true },
        effect: [{ type: 'search_library_to_hand', qualifier: { types: ['Basic', 'Land'] } }],
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'dies', payMana: 1, payColors: ['G'] },
        effect: [{ type: 'draw_cards', amount: 1 }],
      }),
    ],
    artId: 230, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

// ---- Batch 41 — transza B: discard/amass ----

  // 4. Immersturm Skullcairn (KHM) — Land: wchodzi zatapiony; {T}: {B};
  //    {1}{B}{R}{R},{T},sac (sorcery): 3 obrażenia w GRACZA + ten gracz
  //    odrzuca kartę (discard_cards applyTo target — wzorzec Mindstab).
  defineCard({
    id: 'immersturm-skullcairn', name: 'Immersturm Skullcairn', set: 'KHM',
    // CR 202.2: land bez kosztu many jest BEZBARWNY (Scryfall: colors: []).
    // Produkcje {B} niesie mana-sources.js, nie pole `colors`.
    types: ['Land'], colors: [], entersTapped: true,
    oracleText: 'This land enters tapped.\n{T}: Add {B}.\n{1}{B}{R}{R}, {T}, Sacrifice this land: It deals 3 damage to target player. That player discards a card. Activate only as a sorcery.',
    imageUri: 'https://cards.scryfall.io/large/front/1/2/12ed97de-736d-43d8-977b-308ac54f88f4.jpg?1783928173',
    abilities: [
      // „{T}: Add {B}" — deskryptor produkcji many wprost z Oracle (M193/A:
      // kolory zna zdolność karty, nie pole `colors` ani ręczna mapa).
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        effect: { type: 'add_mana', amount: 1, colors: ['B'] },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        timing: 'sorcery',
        cost: { mana: 4, colors: ['B', 'R', 'R'], tap: true, sacrificeSelf: true },
        targets: [{ type: 'player' }],
        effect: [
          { type: 'damage', amount: 3 },
          { type: 'discard_cards', amount: 1, applyTo: 'target' },
        ],
      }),
    ],
    artId: 224, plan: 'Kaldheim',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Toll of the Invasion (WAR) {2}{B} Sorcery — odsłoń rękę wroga,
  //    rzucający WYBIERA nonland (obowiązkowo — mandatory), odrzucenie;
  //    Amass Zombies 1 (token Zombie Army — pierwszy amass „Zombies").
  defineCard({
    id: 'toll-of-the-invasion', name: 'Toll of the Invasion', set: 'WAR',
    types: ['Sorcery'], colors: ['B'], manaCost: 3,
    oracleText: 'Target opponent reveals their hand. You choose a nonland card from it. That player discards that card.\nAmass Zombies 1. (Put a +1/+1 counter on an Army you control. It\'s also a Zombie. If you don\'t control an Army, create a 0/0 black Zombie Army creature token first.)',
    imageUri: 'https://cards.scryfall.io/large/front/4/4/4471c2a5-aa2c-47e2-8238-1eb366c8adc9.jpg?1783933438',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'opponent' }],
      effects: [
        { type: 'reveal_hand_choose_discard', mandatory: true },
        {
          type: 'amass', amount: 1, subtype: 'Zombie', name: 'Zombie Army',
          cardId: 'token_zombie_army', colors: ['B'],
        },
      ],
    },
    artId: 9, plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
  }),

  // Token Zombie Army (TWAR 10) — amass Zombies (Toll of the Invasion).
  defineCard({
    id: 'token_zombie_army', name: 'Zombie Army', set: null,
    types: ['Creature', 'Token'], subtypes: ['Zombie', 'Army'], colors: ['B'],
    power: 0, toughness: 0, manaCost: 0,
    imageUri: 'https://cards.scryfall.io/large/front/1/2/12742d1f-eb2e-4262-88e2-403c9ae6c431.jpg?1783933351',  // twar
    support: { status: 'limited', limitations: ['token — nie można umieścić w talii; statystyki rosną przez amass'] },
  }),

// ---- Batch 41 — transza C: pierwszy CZAR z madness ----

  // 6. Terminal Agony (MH2) {2}{B}{R} Sorcery — „Destroy target creature.
  //    Madness {B}{R}." PIERWSZA karta czarowa z madness w katalogu —
  //    ścieżka castMadnessSpell (M161/O1) dostaje realny przypadek:
  //    discard → exile (madnessReady) → decyzja rzutu za {B}{R} z celem
  //    (oferta per cel — playerView) albo grób. Zakres castMadnessSpell:
  //    bez additionalCost/X/modes — Terminal Agony mieści się w całości.
  defineCard({
    id: 'terminal-agony', name: 'Terminal Agony', set: 'MH2',
    types: ['Sorcery'], colors: ['B', 'R'], manaCost: 4,
    oracleText: 'Destroy target creature.\nMadness {B}{R} (If you discard this card, discard it into exile. When you do, cast it for its madness cost or put it into your graveyard.)',
    imageUri: 'https://cards.scryfall.io/large/front/3/1/314e94ad-0e12-48bb-aae1-2c842943114a.jpg?1783926810',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'creature' }],
      effects: [{ type: 'destroy_permanent' }],
    },
    madness: { cost: 2, colors: ['B', 'R'] },
    artId: 534, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
    notes: ['madness: odrzucenie trafia do exile z decyzją rzutu za {B}{R} (timing ignorowany — CR 702.34e, także sorcery poza main fazą); cel wybierany przy rzucie'],
  }),

// ---- Batch 41 — transza D: triggery bojowe + intimidate ----

  // 7. Burning-Yard Trainer (ELD) {4}{R} 3/3 Human Knight — trample+haste;
  //    ETB: INNY celowany Rycerz pod twoją kontrolą +2/+2 + trample+haste
  //    do końca tury (spec creature_you_control + notSelf + subtype — M154).
  defineCard({
    id: 'burning-yard-trainer', name: 'Burning-Yard Trainer', set: 'ELD',
    types: ['Creature'], subtypes: ['Human', 'Knight'], colors: ['R'],
    keywords: ['trample', 'haste'], power: 3, toughness: 3, manaCost: 5,
    oracleText: 'Trample, haste\nWhen this creature enters, another target Knight you control gets +2/+2 and gains trample and haste until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/1/7/17755d1b-3a56-4362-a534-85b35ceb1802.jpg?1783932628',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: {
          event: 'enter_battlefield',
          requiresTarget: { type: 'creature_you_control', notSelf: true, subtype: 'Knight' },
        },
        effect: [
          { type: 'buff_creature_until_end_of_turn', power: 2, toughness: 2 },
          { type: 'grant_keywords_until_end_of_turn', keywords: ['trample', 'haste'] },
        ],
      }),
    ],
    artId: 209, plan: 'Eldraine',
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Downwind Ambusher (BLB) {3}{B} 4/2 Skunk Assassin — Flash; ETB modal:
  //    −1/−1 na stworze wroga ALBO destroy stwora wroga ranionego w tej turze
  //    (modal trigger z celami per tryb — wzorzec Inspiring Bard).
  defineCard({
    id: 'downwind-ambusher', name: 'Downwind Ambusher', set: 'BLB',
    types: ['Creature'], subtypes: ['Skunk', 'Assassin'], colors: ['B'],
    keywords: ['flash'], power: 4, toughness: 2, manaCost: 4,
    oracleText: 'Flash\nWhen this creature enters, choose one —\n\u2022 Target creature an opponent controls gets -1/-1 until end of turn.\n\u2022 Destroy target creature an opponent controls that was dealt damage this turn.',
    imageUri: 'https://cards.scryfall.io/large/front/5/5/55cfd628-933a-4d3d-b2e5-70bc86960d1c.jpg?1783910835',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: {
          event: 'enter_battlefield',
          modes: [
            {
              name: 'Osłabienie',
              targets: [{ type: 'creature_opponent_controls' }],
              effects: [{ type: 'buff_creature_until_end_of_turn', power: -1, toughness: -1 }],
            },
            {
              name: 'Dobicie rannego',
              targets: [{ type: 'creature_opponent_damaged_this_turn' }],
              effects: [{ type: 'destroy_permanent' }],
            },
          ],
        },
        effect: [],
      }),
    ],
    artId: 451, plan: 'Bloomburrow',
    support: { status: 'supported', limitations: [] },
    notes: ['tryb bez legalnego celu nie jest oferowany (jak modalny czar \u201echoose one\u201d)'],
  }),

  // 9. Predator\'s Gambit (AVR) {B} Aura — +2/+1; intimidate PÓKI kontroler
  //    nie ma innych stworów (conditionalKeywords — wzorzec Hunter\'s
  //    Blowgun; intimidate w canBlock: artefakty/wspólny kolor, CR 702.13).
  defineCard({
    id: 'predators-gambit', name: "Predator's Gambit", set: 'AVR',
    types: ['Enchantment'], subtypes: ['Aura'], colors: ['B'], manaCost: 1,
    oracleText: 'Enchant creature\nEnchanted creature gets +2/+1.\nEnchanted creature has intimidate as long as its controller controls no other creatures. (It can\'t be blocked except by artifact creatures and/or creatures that share a color with it.)',
    imageUri: 'https://cards.scryfall.io/large/front/8/8/88810a96-d5f8-4030-93f1-e2ad0d480317.jpg?1783940692',
    aura: {
      pump: { power: 2, toughness: 1 },
      conditionalKeywords: [
        { condition: { controlsNoOtherCreatures: true }, keywords: ['intimidate'] },
      ],
    },
    artId: 159, plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),

// ---- Batch 41 — transza E: Halo Forager ----

  // 10. Halo Forager (MOM) {1}{U}{B} 3/1 Faerie Rogue — Flying; ETB:
  //     „you may pay {X} → cast target instant or sorcery card with mana
  //     value X from a graveyard without paying its mana cost; if it would
  //     be put into a graveyard, exile it instead." Model decyzji: jedna
  //     komenda (karta = X + cele) albo rezygnacja — wzorzec madness/Epic;
  //     zakres jak castMadnessSpell (bez additionalCost/X/fireball).
  defineCard({
    id: 'halo-forager', name: 'Halo Forager', set: 'MOM',
    types: ['Creature'], subtypes: ['Faerie', 'Rogue'], colors: ['U', 'B'],
    keywords: ['flying'], power: 3, toughness: 1, manaCost: 3,
    oracleText: 'Flying\nWhen this creature enters, you may pay {X}. When you do, you may cast target instant or sorcery card with mana value X from a graveyard without paying its mana cost. If that spell would be put into a graveyard, exile it instead.',
    imageUri: 'https://cards.scryfall.io/large/front/e/d/edb5f0cc-c826-4e7b-882c-63f6e51fa932.jpg?1783916950',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{ type: 'pay_x_cast_from_graveyard' }],
      }),
    ],
    artId: 35, plan: 'Eldraine',
    support: { status: 'supported', limitations: [] },
    notes: ['M203: X jest częścią decyzji i musi równać się MV rzucanej karty (druk „with mana value X"); jedyną wydaną maną jest zapłata {X} — koszt many czaru wynosi {0} (CR 118.9a), a zapłata za czar nie-artefaktowy nie może pochodzić z many ograniczonej drukiem (M202/N1). Decyzja liczona żywo: dowolny grób, X = MV karty, budżet per karta. Czar z kosztem dodatkowym/X/Fireball pozostaje poza zakresem tej ścieżki'],
  }),


// ---- Batch 42 — transza A ----

  // 1. Swooping Protector (SNC) {3}{W} 2/1 Bird Citizen — Flash, Flying,
  //    wchodzi z licznikiem shield (PEŁNY REUSE — wzorzec Voice of the
  //    Vermin; shield przy damage/destroy już w silniku).
  defineCard({
    id: 'swooping-protector', name: 'Swooping Protector', set: 'SNC',
    types: ['Creature'], subtypes: ['Bird', 'Citizen'], colors: ['W'],
    power: 2, toughness: 1, manaCost: 4, keywords: ['flash', 'flying'],
    entersWithCounters: { shield: 1 },
    oracleText: 'Flash\nFlying\nThis creature enters with a shield counter on it. (If it would be dealt damage or destroyed, remove a shield counter from it instead.)',
    imageUri: 'https://cards.scryfall.io/large/front/8/7/8713498f-a467-4a11-9de2-53a1bbd0b18b.jpg?1783923149',
    artId: 379, plan: 'New Capenna',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. You're Not Alone (FIN) {W} Instant — +2/+2 EOT; przy 3+ własnych
  //    stworach ZAMIAST tego +4/+4 (warunek przy rozstrzyganiu — CR 608.2).
  defineCard({
    id: 'youre-not-alone', name: "You're Not Alone", set: 'FIN',
    types: ['Instant'], colors: ['W'], manaCost: 1,
    oracleText: 'Target creature gets +2/+2 until end of turn. If you control three or more creatures, it gets +4/+4 until end of turn instead.',
    imageUri: 'https://cards.scryfall.io/large/front/1/8/1867b5cb-2bb0-4f49-b302-036fdffa2344.jpg?1783906640',
    spell: {
      timing: 'instant',
      targets: [{ type: 'creature' }],
      effects: [{ type: 'pump', power: 2, toughness: 2, upgradeIfCreatures: { min: 3, power: 4, toughness: 4 } }],
    },
    artId: 29, plan: 'Final Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Agate Assault (BLB) {2}{R} Sorcery — modal: 4 obrażenia w stwora
  //    + „if it would die this turn, exile it instead” (nowy znacznik
  //    exile_if_dies_this_turn → deathZoneFor) ALBO wygnanie artefaktu.
  defineCard({
    id: 'agate-assault', name: 'Agate Assault', set: 'BLB',
    types: ['Sorcery'], colors: ['R'], manaCost: 3,
    oracleText: 'Choose one —\n• Agate Assault deals 4 damage to target creature. If that creature would die this turn, exile it instead.\n• Exile target artifact.',
    imageUri: 'https://cards.scryfall.io/large/front/7/d/7dd9946b-515e-4e0d-9da2-711e126e9fa6.jpg?1783910826',
    spell: {
      timing: 'sorcery',
      modes: [
        { name: 'Obrażenia', targets: [{ type: 'creature' }],
          effects: [
            { type: 'exile_if_dies_this_turn' },
            { type: 'damage', amount: 4 },
          ] },
        { name: 'Wygnanie artefaktu', targets: [{ type: 'artifact' }],
          effects: [{ type: 'exile_permanent' }] },
      ],
    },
    artId: 236, plan: 'Bloomburrow',
    support: { status: 'supported', limitations: [] },
  }),


// ---- Batch 42 — transza B ----

  // 4. Makeshift Mauler (ISD) {3}{U} 4/5 Zombie Horror — dodatkowy koszt:
  //    wygnaj kartę stwora z WŁASNEGO grobu (nowy additionalCost
  //    exileCreatureFromGraveyard; zasila trigger Rakshasy).
  defineCard({
    id: 'makeshift-mauler', name: 'Makeshift Mauler', set: 'ISD',
    types: ['Creature'], subtypes: ['Zombie', 'Horror'], colors: ['U'],
    power: 4, toughness: 5, manaCost: 4,
    additionalCost: { exileCreatureFromGraveyard: true },
    oracleText: 'As an additional cost to cast this spell, exile a creature card from your graveyard.',
    imageUri: 'https://cards.scryfall.io/large/front/d/8/d869de57-9454-47ff-af14-eaefd387047a.jpg?1783940971',
    artId: 226, plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Rakshasa Vizier (KTK) {2}{B}{G}{U} 4/4 Demon — „Whenever one or more
  //    cards are put into exile from your graveyard, put that many +1/+1
  //    counters on this creature” (nowy trigger cards_exiled_from_your_
  //    graveyard; liczba z kontekstu zdarzenia — amountFromContext).
  defineCard({
    id: 'rakshasa-vizier', name: 'Rakshasa Vizier', set: 'KTK',
    types: ['Creature'], subtypes: ['Demon'], colors: ['B', 'G', 'U'],
    power: 4, toughness: 4, manaCost: 5,
    oracleText: 'Whenever one or more cards are put into exile from your graveyard, put that many +1/+1 counters on this creature.',
    imageUri: 'https://cards.scryfall.io/large/front/c/b/cb39e674-919d-4db6-9ac1-cfa1cca02207.jpg?1783939055',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'cards_exiled_from_your_graveyard' },
        effect: { type: 'add_counter', counter: '+1/+1', amount: 1, amountFromContext: 'exiledCount' },
      }),
    ],
    artId: 520, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),


// ---- Batch 42 — transza C ----

  // 6. Sifter Wurm (HOU) {5}{G}{G} 7/7 Wurm — Trample; ETB: scry 3, POTEM
  //    reveal wierzchu + życie równe mana value (thenRevealTopGainLife na
  //    pendingScry — reveal po decyzji gracza, CR 608.2).
  defineCard({
    id: 'sifter-wurm', name: 'Sifter Wurm', set: 'HOU',
    types: ['Creature'], subtypes: ['Wurm'], colors: ['G'],
    power: 7, toughness: 7, manaCost: 7, keywords: ['trample'],
    oracleText: "Trample\nWhen this creature enters, scry 3, then reveal the top card of your library. You gain life equal to that card's mana value.",
    imageUri: 'https://cards.scryfall.io/large/front/5/d/5dbaf7e3-e2fc-4399-aa83-c13df43008a0.jpg?1783936012',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: { type: 'scry', amount: 3, thenRevealTopGainLife: true },
      }),
    ],
    artId: 183, plan: 'Amonkhet',
    support: { status: 'supported', limitations: [] },
  }),

  // 7. Final Parting (DOM) {3}{B}{B} Sorcery — przeszukaj bibliotekę po DWIE
  //    karty: jedna do ręki, druga do grobu; potem tasowanie. Wyszukiwanie
  //    bez kryterium = OBOWIĄZKOWE (CR 701.19c — bez fail to find).
  defineCard({
    id: 'final-parting', name: 'Final Parting', set: 'DOM',
    types: ['Sorcery'], colors: ['B'], manaCost: 5,
    oracleText: 'Search your library for two cards. Put one into your hand and the other into your graveyard. Then shuffle.',
    imageUri: 'https://cards.scryfall.io/large/front/d/e/de8803f6-9efa-4323-b8c5-29bdd5a48f9a.jpg?1783935009',
    spell: {
      timing: 'sorcery',
      effects: [{ type: 'search_library_two_cards_hand_and_grave' }],
    },
    artId: 111, plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
  }),


// ---- Batch 42 — transza D ----

  // 8. Vanish from Sight (DSK) {3}{U} Instant — właściciel celowanego
  //    nielandowego permanentu kładzie go wg SWOJEGO wyboru na wierzch albo
  //    spód biblioteki (nowa decyzja resolve_library_placement); potem
  //    surveil 1 rzucającego (czar wisi w pendingSpell do decyzji).
  defineCard({
    id: 'vanish-from-sight', name: 'Vanish from Sight', set: 'DSK',
    types: ['Instant'], colors: ['U'], manaCost: 4,
    oracleText: "Target nonland permanent's owner puts it on their choice of the top or bottom of their library. Surveil 1. (Look at the top card of your library. You may put it into your graveyard.)",
    imageUri: 'https://cards.scryfall.io/large/front/5/2/5254988b-3113-42f7-b751-517ffb3b40f0.jpg?1783909486',
    spell: {
      timing: 'instant',
      targets: [{ type: 'nonland_permanent' }],
      effects: [
        { type: 'owner_library_top_or_bottom' },
        { type: 'surveil', amount: 1 },
      ],
    },
    artId: 512, plan: 'Duskmourn',
    support: { status: 'supported', limitations: [] },
  }),


// ---- Batch 42 — transza E ----

  // 9. Azorius Justiciar (RTR) {2}{W}{W} 2/2 Human Wizard — ETB: detain up to
  //    two target creatures your opponents control (NOWA mechanika detain,
  //    CR 701.29: do twojej następnej tury cel nie atakuje, nie blokuje,
  //    nie aktywuje zdolności; multi-target z upTo — reuse M171/Z6).
  defineCard({
    id: 'azorius-justiciar', name: 'Azorius Justiciar', set: 'RTR',
    types: ['Creature'], subtypes: ['Human', 'Wizard'], colors: ['W'],
    power: 2, toughness: 2, manaCost: 4,
    oracleText: "When this creature enters, detain up to two target creatures your opponents control. (Until your next turn, those creatures can't attack or block and their activated abilities can't be activated.)",
    imageUri: 'https://cards.scryfall.io/large/front/9/f/9f56272e-c05e-446b-8871-e3783dd29a8b.jpg?1783940377',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'creature_opponent_controls', count: 2, upTo: true } },
        effect: { type: 'detain' },
      }),
    ],
    artId: 6, plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
  }),

  // 10. Merchant's Dockhand (AER) {1} 1/2 Artifact Creature Construct —
  //     „{3}{U}, {T}, Tap X untapped artifacts you control: Look at the top X
  //     cards… one into your hand, the rest on the bottom in any order”
  //     (NOWY koszt tapXArtifacts + look_top_put_one_hand_rest_bottom).
  defineCard({
    id: 'merchants-dockhand', name: "Merchant's Dockhand", set: 'AER',
    types: ['Artifact', 'Creature'], subtypes: ['Construct'], colors: [],
    power: 1, toughness: 2, manaCost: 1,
    oracleText: '{3}{U}, {T}, Tap X untapped artifacts you control: Look at the top X cards of your library. Put one of them into your hand and the rest on the bottom of your library in any order.',
    imageUri: 'https://cards.scryfall.io/large/front/9/5/955b4bc9-1ded-4f23-b415-ab968c681eb7.jpg?1783936724',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 4, colors: ['U'], tap: true, tapXArtifacts: true },
        effect: { type: 'look_top_put_one_hand_rest_bottom', amount: 'x' },
      }),
    ],
    artId: 12, plan: 'Kaladesh',
    support: { status: 'supported', limitations: [] },
  }),

  // =========================================================================
  // Batch 43 (10 kart, 2026-08-22) — lista właściciela (M182)
  // Sleep of the Dead, Severed Strands, Rush of Battle, Dispeller's Capsule,
  // Fleeting Distraction, Forced Landing, Tireless Hauler (DFC), Sea God's
  // Scorn, Balamb Garden SeeD Academy (DFC land→vehicle), Greenwood Sentinel.
  // Dane Oracle: docs/cards/scryfall-*.json; artId ze słownika kolekcji
  // (tylne strony DFC mają WŁASNE wpisy: Dire-Strain Brawler 118,
  // Balamb Garden Airborne 153).
  // =========================================================================

  // ---- Batch 43 — transza A: istniejące mechaniki ----

  // 1. Greenwood Sentinel (M20) — 2/2 vigilance (french vanilla).
  defineCard({
    id: 'greenwood-sentinel', name: 'Greenwood Sentinel', set: 'M20',
    types: ['Creature'], subtypes: ['Elf', 'Scout'], colors: ['G'],
    power: 2, toughness: 2, manaCost: 2, keywords: ['vigilance'],
    oracleText: 'Vigilance (Attacking doesn\'t cause this creature to tap.)',
    imageUri: 'https://cards.scryfall.io/large/front/e/9/e9a1a70d-c146-453e-84c4-71cae4e0afaa.jpg?1783932966',
    artId: 169, plan: 'Śródziemie',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Fleeting Distraction (FDN) — cantrip: cel −1/−0 do końca tury + dobierz.
  defineCard({
    id: 'fleeting-distraction', name: 'Fleeting Distraction', set: 'FDN',
    types: ['Instant'], colors: ['U'], manaCost: 1,
    oracleText: 'Target creature gets -1/-0 until end of turn.\nDraw a card.',
    imageUri: 'https://cards.scryfall.io/large/front/c/0/c0b86a7b-4912-43a7-ab89-c3432385baa1.jpg?1783909081',
    spell: {
      timing: 'instant',
      targets: [{ type: 'creature' }],
      effects: [
        { type: 'pump', power: -1, toughness: 0 },
        { type: 'draw_cards', amount: 1 },
      ],
    },
    artId: 98, plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Tireless Hauler // Dire-Strain Brawler (MID) — wilkołak
  //    daybound/nightbound (wzorzec Ballista Watcher, M68/CR 708.9).
  defineCard({
    id: 'tireless-hauler', name: 'Tireless Hauler', set: 'MID',
    types: ['Creature'], subtypes: ['Human', 'Werewolf'], colors: ['G'],
    power: 4, toughness: 5, manaCost: 5, keywords: ['vigilance', 'daybound'],
    oracleText: 'Vigilance\nDaybound (If a player casts no spells during their own turn, it becomes night next turn.)',
    imageUri: 'https://cards.scryfall.io/large/front/3/e/3e96f9a6-c215-42b1-aa02-8e6143fe5bd7.jpg?1783925578',
    transformTo: 'dire-strain-brawler',
    artId: 117, plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),
  defineCard({
    id: 'dire-strain-brawler', name: 'Dire-Strain Brawler', set: 'MID',
    types: ['Creature'], subtypes: ['Werewolf'], colors: ['G'],
    power: 6, toughness: 6, manaCost: 5, keywords: ['vigilance', 'nightbound'],
    oracleText: 'Vigilance\nNightbound (If a player casts at least two spells during their own turn, it becomes day next turn.)',
    imageUri: 'https://cards.scryfall.io/large/back/3/e/3e96f9a6-c215-42b1-aa02-8e6143fe5bd7.jpg?1783925578',
    transformTo: 'tireless-hauler',
    artId: 118, plan: 'Innistrad',
    support: { status: 'limited', limitations: ['tylna strona daybound/nightbound — nie można umieścić w talii'] },
  }),

  // 4. Dispeller's Capsule (ALA) — artefakt {W}; „{2}{W}, {T}, Sacrifice:
  //    Destroy target artifact or enchantment."
  defineCard({
    id: 'dispellers-capsule', name: "Dispeller's Capsule", set: 'ALA',
    types: ['Artifact'], colors: ['W'], manaCost: 1,
    oracleText: '{2}{W}, {T}, Sacrifice this artifact: Destroy target artifact or enchantment.',
    imageUri: 'https://cards.scryfall.io/large/front/d/3/d3cf0771-10d6-427a-b4e5-3e1d4db14667.jpg?1783942584',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 3, colors: ['W'], tap: true, sacrificeSelf: true },
        targets: [{ type: 'artifact_or_enchantment' }],
        effect: { type: 'destroy_permanent' },
      }),
    ],
    artId: 93, plan: 'Alara',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Sleep of the Dead (THB) — tap + jednorazowa blokada odkręcenia
  //    (dont_untap_next_untap_step, wzorzec Wavecrash Triton); Escape
  //    {2}{U} + wygnaj 3 inne karty z grobu (wzorzec Sweet Oblivion).
  defineCard({
    id: 'sleep-of-the-dead', name: 'Sleep of the Dead', set: 'THB',
    types: ['Sorcery'], colors: ['U'], manaCost: 1,
    oracleText: 'Tap target creature. It doesn\'t untap during its controller\'s next untap step.\nEscape—{2}{U}, Exile three other cards from your graveyard. (You may cast this card from your graveyard for its escape cost.)',
    imageUri: 'https://cards.scryfall.io/large/front/4/0/4007572b-a6c8-4a56-b1a7-ff099189c9c0.jpg?1783931579',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'creature' }],
      effects: [
        { type: 'tap_permanent' },
        { type: 'dont_untap_next_untap_step' },
      ],
      // Escape (CR 702.138): rzuć z grobu za {2}{U} + wygnaj 3 inne karty z grobu.
      escape: { cost: 3, exileCount: 3 },
    },
    artId: 11, plan: 'Theros',
    support: { status: 'supported', limitations: [] },
    notes: ['Escape: czar z grobu za koszt escape + wygnanie 3 innych kart z grobu; po rozstrzygnięciu wraca do grobu'],
  }),

  // ---- Batch 43 — transza B: drobne rozszerzenia silnika ----

  // 6. Severed Strands (GRN) — dodatkowy koszt sacrifice a creature (wzorzec
  //    Village Rites); zysk życia = wytrzymałość poświęconego (NOWE:
  //    sacrificedToughness na obiekcie stosu + amountFromSacrificedToughness).
  defineCard({
    id: 'severed-strands', name: 'Severed Strands', set: 'GRN',
    types: ['Sorcery'], colors: ['B'], manaCost: 2,
    oracleText: 'As an additional cost to cast this spell, sacrifice a creature.\nYou gain life equal to the sacrificed creature\'s toughness. Destroy target creature an opponent controls.',
    imageUri: 'https://cards.scryfall.io/large/front/b/c/bce654d6-fcf1-40a8-8bdb-5c37e561f7dc.jpg?1783934171',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'creature_opponent_controls' }],
      additionalCost: { sacrificeCreature: true },
      effects: [
        { type: 'gain_life', amountFromSacrificedToughness: true },
        { type: 'destroy_permanent' },
      ],
    },
    artId: 41, plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
    notes: ['zysk życia = wytrzymałość poświęconego stwora (LKI z chwili płatności kosztu); przy nielegalnym celu w rozstrzygnięciu czar fizzluje w całości (CR 608.2b) — bez zysku życia'],
  }),

  // 7. Rush of Battle (KTK) — masowy buff +2/+1 dla wszystkich + lifelink
  //    TYLKO dla Warriorów (NOWE: filtr subtype w buff_creatures_you_control).
  defineCard({
    id: 'rush-of-battle', name: 'Rush of Battle', set: 'KTK',
    types: ['Sorcery'], colors: ['W'], manaCost: 4,
    oracleText: 'Creatures you control get +2/+1 until end of turn. Warrior creatures you control gain lifelink until end of turn. (Damage dealt by those Warriors also causes their controller to gain that much life.)',
    imageUri: 'https://cards.scryfall.io/large/front/0/d/0d47d8aa-59c8-4e2c-bb48-328ae924dbb3.jpg?1783939093',
    spell: {
      timing: 'sorcery',
      targets: [],
      effects: [
        { type: 'buff_creatures_you_control', power: 2, toughness: 1 },
        { type: 'buff_creatures_you_control', keywords: ['lifelink'], subtype: 'Warrior' },
      ],
    },
    artId: 74, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Forced Landing (WAR) — cel: stwór z lataniem; na SPÓD biblioteki
  //    właściciela (NOWY efekt bounce_to_library_bottom; token → przestaje
  //    istnieć, CR 111.7).
  defineCard({
    id: 'forced-landing', name: 'Forced Landing', set: 'WAR',
    types: ['Instant'], colors: ['G'], manaCost: 2,
    oracleText: 'Put target creature with flying on the bottom of its owner\'s library.',
    imageUri: 'https://cards.scryfall.io/large/front/5/c/5cb319a7-564c-4748-82cf-c26ab110c32c.jpg?1783933414',
    spell: {
      timing: 'instant',
      targets: [{ type: 'creature_with_keyword', keyword: 'flying' }],
      effects: [{ type: 'bounce_to_library_bottom' }],
    },
    artId: 108, plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
  }),

  // 9. Sea God's Scorn (THB) — „Return up to three target creatures and/or
  //    enchantments to their owners' hands" (variableTargets z NOWYM `type`:
  //    creature_or_enchantment; bounce per cel przez apply_to_each_target).
  defineCard({
    id: 'sea-gods-scorn', name: "Sea God's Scorn", set: 'THB',
    types: ['Sorcery'], colors: ['U'], manaCost: 6,
    oracleText: 'Return up to three target creatures and/or enchantments to their owners\' hands.',
    imageUri: 'https://cards.scryfall.io/large/front/9/5/9504dc26-f5d8-4b9d-9eb1-51a12b893beb.jpg?1783931579',
    spell: {
      timing: 'sorcery',
      modes: [{
        name: 'Wzgarda boga mórz',
        variableTargets: { max: 3, min: 0, type: 'creature_or_enchantment' },
        effects: [{
          type: 'apply_to_each_target',
          effects: [{ type: 'bounce_permanent' }],
        }],
      }],
    },
    artId: 121, plan: 'Theros',
    support: { status: 'supported', limitations: [] },
  }),

  // ---- Batch 43 — transza C: Balamb Garden (DFC land → vehicle) ----

  // 10. Balamb Garden, SeeD Academy (FIN) — Land Town wchodzący tapnięty;
  //     {T}: Add {G} or {U}; aktywowany transform {5}{G}{U},{T} z redukcją
  //     {1} za każdy INNY Town (NOWE: costReduction.perOtherSubtype).
  defineCard({
    id: 'balamb-garden-seed-academy', name: 'Balamb Garden, SeeD Academy', set: 'FIN',
    types: ['Land'], subtypes: ['Town'], colors: [], entersTapped: true,
    oracleText: 'This land enters tapped.\n{T}: Add {G} or {U}.\n{5}{G}{U}, {T}: Transform this land. This ability costs {1} less to activate for each other Town you control.',
    imageUri: 'https://cards.scryfall.io/large/front/0/0/001e9f20-5b15-41cb-bf82-46172decc235.jpg?1783906558',
    transformTo: 'balamb-garden-airborne',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        effect: { type: 'add_mana', amount: 1, colors: ['G', 'U'] },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 7, colors: ['G', 'U'], tap: true },
        costReduction: { perOtherSubtype: 'Town' },
        effect: [{ type: 'transform' }],
      }),
    ],
    artId: 150, plan: 'Final Fantasy',
    support: { status: 'supported', limitations: [] },
    notes: ['jedyny Town w katalogu — redukcja za inne Towny działa, ale w praktyce wynosi 0, dopóki nie dojdą kolejne Towny'],
  }),
  // Tylna strona — Balamb Garden, Airborne (Legendary Artifact — Vehicle 5/4).
  defineCard({
    id: 'balamb-garden-airborne', name: 'Balamb Garden, Airborne', set: 'FIN',
    types: ['Legendary', 'Artifact'], subtypes: ['Vehicle'], colors: [],
    power: 5, toughness: 4, keywords: ['flying'],
    oracleText: 'Flying\nWhenever Balamb Garden attacks, draw a card.\nCrew 1 (Tap any number of creatures you control with total power 1 or more: This Vehicle becomes an artifact creature until end of turn.)',
    imageUri: 'https://cards.scryfall.io/large/back/0/0/001e9f20-5b15-41cb-bf82-46172decc235.jpg?1783906558',
    transformTo: 'balamb-garden-seed-academy',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'attacks' },
        effect: { type: 'draw_cards', amount: 1 },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        // Crew (CR 701.36) aktywuje się jak instant (audyt Batchu 26/M65).
        cost: { crewPower: 1 },
        effect: { type: 'animate_permanent_until_end_of_turn', power: 5, toughness: 4, typesAdd: ['Creature'] },
      }),
    ],
    artId: 153, plan: 'Final Fantasy',
    support: { status: 'limited', limitations: ['tylna strona transform — nie można umieścić w talii'] },
  }),

  // =========================================================================
  // Batch 44 (10 kart, 2026-08-22) — lista właściciela (M183)
  // Dismal Backwater, Descendant of Storms, Frightful Delusion, Hill Giant,
  // Angel's Herald, Heap Gate, Thieves' Tools, Farbog Explorer, Blanchwood
  // Prowler, Glaring Aegis. Dane Oracle: docs/cards/scryfall-*.json.
  // =========================================================================

  // ---- Batch 44 — transza A: istniejące mechaniki ----

  // 1. Hill Giant (7ED) — vanilla 3/3.
  defineCard({
    id: 'hill-giant', name: 'Hill Giant', set: '7ED',
    types: ['Creature'], subtypes: ['Giant'], colors: ['R'],
    power: 3, toughness: 3, manaCost: 4, oracleText: '',
    imageUri: 'https://cards.scryfall.io/large/front/e/7/e7ea1719-2bed-46f4-bb14-e3a4c87ce50a.jpg?1783945460',
    artId: 258, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Farbog Explorer (AVR) — swampwalk (wzorzec Emerald Oryx, CR 702.33).
  defineCard({
    id: 'farbog-explorer', name: 'Farbog Explorer', set: 'AVR',
    types: ['Creature'], subtypes: ['Human', 'Scout'], colors: ['W'],
    power: 2, toughness: 3, manaCost: 3,
    oracleText: "Swampwalk (This creature can't be blocked as long as defending player controls a Swamp.)",
    imageUri: 'https://cards.scryfall.io/large/front/4/8/489c6a2f-38b4-4ff9-95f7-431384480ed9.jpg?1783940735',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.static,
        landwalk: { subtype: 'Swamp' },
      }),
    ],
    artId: 299, plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Dismal Backwater (M20) — dual land: wchodzi tapnięty, ETB +1 życia,
  //    {T}: Add {U} or {B}.
  defineCard({
    id: 'dismal-backwater', name: 'Dismal Backwater', set: 'M20',
    types: ['Land'], colors: [], entersTapped: true,
    oracleText: 'This land enters tapped.\nWhen this land enters, you gain 1 life.\n{T}: Add {U} or {B}.',
    imageUri: 'https://cards.scryfall.io/large/front/a/5/a5ff247f-82d1-4b79-9ac0-1471a1f0f58b.jpg?1783932937',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{ type: 'gain_life', amount: 1 }],
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        effect: { type: 'add_mana', amount: 1, colors: ['U', 'B'] },
      }),
    ],
    artId: 197, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 4. Glaring Aegis (M20) — aura +1/+3; ETB: tapnij stwora przeciwnika.
  defineCard({
    id: 'glaring-aegis', name: 'Glaring Aegis', set: 'M20',
    types: ['Enchantment'], subtypes: ['Aura'], colors: ['W'], manaCost: 1,
    oracleText: 'Enchant creature\nWhen this Aura enters, tap target creature an opponent controls.\nEnchanted creature gets +1/+3.',
    imageUri: 'https://cards.scryfall.io/large/front/d/a/daa83dc2-4ec0-4e4f-8bfd-4f6d6df06a2d.jpg?1783933028',
    aura: { pump: { power: 1, toughness: 3 } },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'creature_opponent_controls' } },
        effect: [{ type: 'tap_permanent' }],
      }),
    ],
    artId: 337, plan: 'Theros',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Descendant of Storms (TDM) — „Whenever this creature attacks, you may
  //    pay {1}{W}. If you do, it endures 1." — opcjonalna płatność triggera
  //    (wzorzec Zoraline) + endure (wzorzec Krumar Initiate, CR 702.174).
  defineCard({
    id: 'descendant-of-storms', name: 'Descendant of Storms', set: 'TDM',
    types: ['Creature'], subtypes: ['Human', 'Soldier'], colors: ['W'],
    power: 2, toughness: 1, manaCost: 1,
    oracleText: 'Whenever this creature attacks, you may pay {1}{W}. If you do, it endures 1. (Put a +1/+1 counter on it or create a 1/1 white Spirit creature token.)',
    imageUri: 'https://cards.scryfall.io/large/front/f/6/f632be90-9e7f-41f8-a52e-a2952354d730.jpg?1783907415',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'attacks', payMana: 2, payColors: ['W'] },
        effect: [
          { type: 'pay_mana', amount: 2 },
          { type: 'endure_x', amount: 1 },
        ],
      }),
    ],
    artId: 240, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
    notes: ['płatność {1}{W} to decyzja gracza przy triggerze (resolve_optional_pay_choice); endure 1 = wybór: licznik +1/+1 albo token Spirit 1/1'],
  }),

  // ---- Batch 44 — transza B: rozszerzenia silnika ----

  // 6. Blanchwood Prowler (BRO) — ETB: mill 3; land z młyna do ręki ALBO
  //    +1/+1 (reveal_top_pick_land_rest_grave z counterIfNone).
  defineCard({
    id: 'blanchwood-prowler', name: 'Blanchwood Prowler', set: 'BRO',
    types: ['Creature'], subtypes: ['Elemental'], colors: ['G'],
    power: 1, toughness: 1, manaCost: 2,
    oracleText: 'When this creature enters, mill three cards. You may put a land card from among the cards milled this way into your hand. If you don\'t, put a +1/+1 counter on this creature. (To mill a card, put the top card of your library into your graveyard.)',
    imageUri: 'https://cards.scryfall.io/large/front/9/c/9c6988b6-ade0-4cd5-b27c-146e5e7ae91f.jpg?1783920050',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{ type: 'reveal_top_pick_land_rest_grave', amount: 3, counterIfNone: true }],
      }),
    ],
    artId: 303, plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
    notes: ['bez landa wśród zmielonych: karty do grobu + licznik bez decyzji; rezygnacja z landa = licznik'],
  }),

  // 7. Thieves' Tools (CLB) — Equipment: ETB Treasure; nosiciel o mocy <=3
  //    nie może być blokowany (NOWE: equipment.cantBeBlockedMaxPower).
  defineCard({
    id: 'thieves-tools', name: "Thieves' Tools", set: 'CLB',
    types: ['Artifact'], subtypes: ['Equipment'], colors: ['B'], manaCost: 2,
    oracleText: 'When this Equipment enters, create a Treasure token. (It\'s an artifact with "{T}, Sacrifice this token: Add one mana of any color.")\nEquipped creature can\'t be blocked as long as its power is 3 or less.\nEquip {2} ({2}: Attach to target creature you control. Equip only as a sorcery.)',
    imageUri: 'https://cards.scryfall.io/large/front/c/3/c3bf4ee1-b6a8-4a69-adab-6839c1786cc9.jpg?1783922750',
    equipment: { equip: 2, cantBeBlockedMaxPower: 3 },
    abilities: [
      // M190/C (zgłoszenie właściciela): bez tej zdolności sprzęt był
      // NIEGRYWALNY — deskryptor `equipment` opisuje skutek założenia, ale
      // samą aktywację „Equip {2}" (CR 702.6) enumeruje dopiero zdolność
      // z keyword: 'equip'. Batch 44 jej nie dopisał, więc Thieves' Tools
      // leżało na stole bez żadnej oferty. Strażnik: test M190/C2.
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'equip',
        cost: { mana: 2 },
        effect: [],
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{
          type: 'create_token', cardId: 'token_treasure', name: 'Treasure',
          kind: 'artifact', colors: [], types: ['Artifact'], subtypes: ['Treasure'],
          abilities: [
            createAbility({
              type: ABILITY_TYPE.activated,
              cost: { tap: true, sacrificeSelf: true },
              effect: { type: 'add_mana', amount: 1, fromTreasure: true },
            }),
          ],
        }],
      }),
    ],
    artId: 284, plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
    notes: ['próg mocy liczony EFEKTYWNIE przy deklaracji blokerów — pump ponad 3 wyłącza nieblokowalność'],
  }),

  // 8. Heap Gate (CLB) — Gate: {T}: C; {1},{T}: dowolny kolor; {1},{T},
  //    tapnij nietapnięty Gate: Treasure (NOWY koszt tapUntappedSubtype).
  defineCard({
    id: 'heap-gate', name: 'Heap Gate', set: 'CLB',
    types: ['Land'], subtypes: ['Gate'], colors: [],
    oracleText: '{T}: Add {C}.\n{1}, {T}: Add one mana of any color.\n{1}, {T}, Tap an untapped Gate you control: Create a Treasure token. (It\'s an artifact with "{T}, Sacrifice this token: Add one mana of any color.")',
    imageUri: 'https://cards.scryfall.io/large/front/6/8/68489d65-1978-48b1-a903-2ef38c583239.jpg?1783922657',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        effect: { type: 'add_mana', amount: 1 },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 1, tap: true },
        effect: { type: 'add_mana', amount: 1, colors: ['W', 'U', 'B', 'R', 'G'] },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 1, tap: true, tapUntappedSubtype: 'Gate' },
        effect: [{
          type: 'create_token', cardId: 'token_treasure', name: 'Treasure',
          kind: 'artifact', colors: [], types: ['Artifact'], subtypes: ['Treasure'],
          abilities: [
            createAbility({
              type: ABILITY_TYPE.activated,
              cost: { tap: true, sacrificeSelf: true },
              effect: { type: 'add_mana', amount: 1, fromTreasure: true },
            }),
          ],
        }],
      }),
    ],
    artId: 276, plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
    notes: ['koszt „tapnij nietapnięty Gate" wymaga INNEJ bramy — {T} w koszcie zużywa już samą Heap Gate'],
  }),

  // 9. Angel's Herald (ALA) — {2}{W}, {T}, poświęć zielonego, białego
  //    i niebieskiego stwora: tutor Empyrial Archangel na pole bitwy
  //    (NOWY koszt sacrificeCreaturesByColors + search po nazwie).
  defineCard({
    id: 'angels-herald', name: "Angel's Herald", set: 'ALA',
    types: ['Creature'], subtypes: ['Human', 'Cleric'], colors: ['W'],
    power: 1, toughness: 1, manaCost: 1,
    oracleText: '{2}{W}, {T}, Sacrifice a green creature, a white creature, and a blue creature: Search your library for a card named Empyrial Archangel, put it onto the battlefield, then shuffle.',
    imageUri: 'https://cards.scryfall.io/large/front/3/6/36197ed0-4382-4de3-8359-73cb74edc78b.jpg?1783942584',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 3, colors: ['W'], tap: true, sacrificeCreaturesByColors: ['G', 'W', 'U'] },
        effect: { type: 'search_library_to_battlefield', qualifier: { name: 'Empyrial Archangel' } },
      }),
    ],
    artId: 262, plan: 'Alara',
    support: { status: 'supported', limitations: [] },
    notes: ['Empyrial Archangel nie jest w katalogu — search legalnie „fails to find" (CR 701.19b: kryterium nazwy); zdolność w pełni wg Oracle, użyteczna po ewentualnym dodaniu anioła'],
  }),

  // 10. Frightful Delusion (ISD) — „Counter target spell unless its
  //     controller pays {1}. That player discards a card." (NOWY efekt
  //     counter_spell_unless_pays: decyzja kontrolera celu + discard).
  defineCard({
    id: 'frightful-delusion', name: 'Frightful Delusion', set: 'ISD',
    types: ['Instant'], colors: ['U'], manaCost: 3,
    oracleText: 'Counter target spell unless its controller pays {1}. That player discards a card.',
    imageUri: 'https://cards.scryfall.io/large/front/3/8/38c9ba98-90b4-4c28-9eef-a4fe0913b921.jpg?1783940974',
    spell: {
      timing: 'instant',
      targets: [{ type: 'spell_on_stack' }],
      effects: [{ type: 'counter_spell_unless_pays', amount: 1 }],
    },
    artId: 256, plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
    notes: ['kontroler celu decyduje (resolve_counter_pay_choice): zapłać {1} — czar zostaje; nie płać — skontrowany; NIEZALEŻNIE od decyzji odrzuca potem kartę (wybór odrzucanej — CR 701.18); bez many na {1} decyzji nie ma'],
  }),

  // =========================================================================
  // Batch 45 (10 kart, 2026-08-22) — lista właściciela (M185)
  // Call the Mountain Chocobo, Patron of the Arts, Pain for All, Assert
  // Perfection, Ivy Lane Denizen, Malamet Battle Glyph, Unearth, Ghost
  // Warden, Crawling Chorus, Doomed Dissenter. Oracle: docs/cards/.
  // =========================================================================

  // ---- Batch 45 — transza A: istniejące mechaniki ----

  // 1. Ghost Warden (GPT) — „{T}: Target creature gets +1/+1 until end of turn."
  defineCard({
    id: 'ghost-warden', name: 'Ghost Warden', set: 'GPT',
    types: ['Creature'], subtypes: ['Spirit'], colors: ['W'],
    power: 1, toughness: 1, manaCost: 2,
    oracleText: '{T}: Target creature gets +1/+1 until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/4/3/4304abfe-3c81-4053-a398-574cfac613a7.jpg?1783943530',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        targets: [{ type: 'creature' }],
        effect: { type: 'pump', power: 1, toughness: 1 },
      }),
    ],
    artId: 264, plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Doomed Dissenter (VOW) — dies → token Zombie 2/2.
  defineCard({
    id: 'doomed-dissenter', name: 'Doomed Dissenter', set: 'VOW',
    types: ['Creature'], subtypes: ['Human'], colors: ['B'],
    power: 1, toughness: 1, manaCost: 2,
    oracleText: 'When this creature dies, create a 2/2 black Zombie creature token.',
    imageUri: 'https://cards.scryfall.io/large/front/f/7/f7c0cf16-81ea-45e3-99cc-4424d59bb44b.jpg?1783924866',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'dies' },
        effect: [{
          type: 'create_token', cardId: 'token_zombie', name: 'Zombie',
          kind: 'creature', power: 2, toughness: 2, colors: ['B'],
          types: ['Creature'], subtypes: ['Zombie'],
        }],
      }),
    ],
    artId: 376, plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Patron of the Arts (CLB) — „When this creature enters OR dies,
  //    create a Treasure token" — dwa triggery z tym samym efektem.
  defineCard({
    id: 'patron-of-the-arts', name: 'Patron of the Arts', set: 'CLB',
    types: ['Creature'], subtypes: ['Dragon', 'Noble'], colors: ['R'],
    power: 3, toughness: 1, manaCost: 3,
    oracleText: 'When this creature enters or dies, create a Treasure token. (It\'s an artifact with "{T}, Sacrifice this token: Add one mana of any color.")',
    imageUri: 'https://cards.scryfall.io/large/front/1/0/10b2b8ca-7433-4bfe-abab-e19128e46a1d.jpg?1783922732',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{
          type: 'create_token', cardId: 'token_treasure', name: 'Treasure',
          kind: 'artifact', colors: [], types: ['Artifact'], subtypes: ['Treasure'],
          abilities: [
            createAbility({
              type: ABILITY_TYPE.activated,
              cost: { tap: true, sacrificeSelf: true },
              effect: { type: 'add_mana', amount: 1, fromTreasure: true },
            }),
          ],
        }],
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'dies' },
        effect: [{
          type: 'create_token', cardId: 'token_treasure', name: 'Treasure',
          kind: 'artifact', colors: [], types: ['Artifact'], subtypes: ['Treasure'],
          abilities: [
            createAbility({
              type: ABILITY_TYPE.activated,
              cost: { tap: true, sacrificeSelf: true },
              effect: { type: 'add_mana', amount: 1, fromTreasure: true },
            }),
          ],
        }],
      }),
    ],
    artId: 339, plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
  }),

  // 4. Unearth (MH1) — return creature mv≤3 z grobu na pole; Cycling {2}.
  defineCard({
    id: 'unearth', name: 'Unearth', set: 'MH1',
    types: ['Sorcery'], colors: ['B'], manaCost: 1,
    oracleText: 'Return target creature card with mana value 3 or less from your graveyard to the battlefield.\nCycling {2} ({2}, Discard this card: Draw a card.)',
    imageUri: 'https://cards.scryfall.io/large/front/b/6/b62abd0c-ec3e-45d7-989d-da269812aeef.jpg?1783933118',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'creature_card_in_graveyard', maxManaValue: 3 }],
      effects: [{ type: 'return_permanent_from_graveyard' }],
    },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'cycling',
        cost: { mana: 2 },
        cycling: { drawCards: 1 },
        effect: [],
      }),
    ],
    artId: 395, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Call the Mountain Chocobo (FIN) — tutor Mountain do ręki + token
  //    Bird 2/2 z landfallowym +1/+0; Flashback {5}{R}.
  defineCard({
    id: 'call-the-mountain-chocobo', name: 'Call the Mountain Chocobo', set: 'FIN',
    types: ['Sorcery'], colors: ['R'], manaCost: 4,
    oracleText: 'Search your library for a Mountain card, reveal it, put it into your hand, then shuffle. Create a 2/2 green Bird creature token with "Whenever a land you control enters, this token gets +1/+0 until end of turn."\nFlashback {5}{R} (You may cast this card from your graveyard for its flashback cost. Then exile it.)',
    imageUri: 'https://cards.scryfall.io/large/front/b/2/b2e1986c-2852-4843-bdc4-eddb727ba3d4.jpg?1783906607',
    spell: {
      timing: 'sorcery',
      targets: [],
      effects: [
        { type: 'search_library_to_hand', qualifier: { subtypes: ['Mountain'] } },
        {
          type: 'create_token', cardId: 'token_bird_chocobo', name: 'Bird',
          kind: 'creature', power: 2, toughness: 2, colors: ['G'],
          types: ['Creature'], subtypes: ['Bird'],
          abilities: [
            createAbility({
              type: ABILITY_TYPE.triggered,
              trigger: { event: 'land_entered_under_your_control' },
              effect: [{ type: 'pump', power: 1, toughness: 0 }],
            }),
          ],
        },
      ],
      flashback: { cost: 6, colors: ['R'] },
    },
    artId: 319, plan: 'Final Fantasy',
    support: { status: 'supported', limitations: [] },
    notes: ['token Bird pumpuje SAM SIEBIE przy wejściu landa kontrolera (landfall — trigger bez celu pumpuje źródło)'],
  }),

  // ---- Batch 45 — transza B: rozszerzenia silnika ----

  // 6. Ivy Lane Denizen (CMR) — „Whenever another green creature you control
  //    enters, put a +1/+1 counter on target creature" (filtry youControl +
  //    colorsInclude na another_creature_enters).
  defineCard({
    id: 'ivy-lane-denizen', name: 'Ivy Lane Denizen', set: 'CMR',
    types: ['Creature'], subtypes: ['Elf', 'Warrior'], colors: ['G'],
    power: 2, toughness: 3, manaCost: 4,
    oracleText: 'Whenever another green creature you control enters, put a +1/+1 counter on target creature.',
    imageUri: 'https://cards.scryfall.io/large/front/7/8/78bea375-8af3-4425-a418-bb5503e2dfb7.jpg?1783928792',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: {
          event: 'another_creature_enters', youControl: true, colorsInclude: ['G'],
          requiresTarget: { type: 'creature' },
        },
        effect: [{ type: 'add_counter', counter: '+1/+1', amount: 1 }],
      }),
    ],
    artId: 460, plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
  }),

  // 7. Malamet Battle Glyph (LCI) — dwa cele; licznik, jeśli własny stwór
  //    wszedł w tej turze; potem FIGHT (NOWY efekt, CR 701.12).
  defineCard({
    id: 'malamet-battle-glyph', name: 'Malamet Battle Glyph', set: 'LCI',
    types: ['Sorcery'], colors: ['G'], manaCost: 1,
    oracleText: 'Choose target creature you control and target creature you don\'t control. If the creature you control entered this turn, put a +1/+1 counter on it. Then those creatures fight each other.',
    imageUri: 'https://cards.scryfall.io/large/front/2/2/2259f959-ca97-4df9-8d50-0532090fb967.jpg?1783913743',
    spell: {
      timing: 'sorcery',
      targets: [
        { type: 'creature_you_control' },
        { type: 'creature_opponent_controls' },
      ],
      effects: [
        { type: 'add_counter', counter: '+1/+1', amount: 1, targetIndex: 0, onlyIfTargetEnteredThisTurn: true },
        { type: 'fight', targetIndexA: 0, targetIndexB: 1 },
      ],
    },
    artId: 215, plan: 'Ixalan',
    support: { status: 'supported', limitations: [] },
    notes: ['fight PO ewentualnym liczniku (kolejność Oracle); licznik tylko gdy własny cel wszedł w tej turze (enteredOnTurn)'],
  }),

  // 8. Assert Perfection (ECL) — bite: +1/+0 dla własnego stwora; obrażenia
  //    równe jego mocy w „up to one" wrogiego stwora (NOWE: optional target).
  defineCard({
    id: 'assert-perfection', name: 'Assert Perfection', set: 'ECL',
    types: ['Sorcery'], colors: ['G'], manaCost: 2,
    oracleText: 'Target creature you control gets +1/+0 until end of turn. It deals damage equal to its power to up to one target creature an opponent controls.',
    imageUri: 'https://cards.scryfall.io/large/front/6/9/6995b308-5582-4ca1-ab10-a536d5ca0a6d.jpg?1783904435',
    spell: {
      timing: 'sorcery',
      targets: [
        { type: 'creature_you_control' },
        { type: 'creature_opponent_controls', optional: true },
      ],
      effects: [
        { type: 'pump', power: 1, toughness: 0 },
        { type: 'damage_from_target_power', sourceTargetIndex: 0, targetIndex: 1 },
      ],
    },
    artId: 366, plan: 'Lorwyn',
    support: { status: 'supported', limitations: [] },
    notes: ['„up to one target" — wariant bez drugiego celu jest legalny (pump bez ugryzienia); pump PRZED obrażeniami (kolejność Oracle — obrażenia liczą moc po +1/+0)'],
  }),

  // 9. Crawling Chorus (ONE) — Toxic 1 (NOWY keyword, CR 702.180); dies →
  //    token Phyrexian Mite 1/1 (toxic 1, can't block).
  defineCard({
    id: 'crawling-chorus', name: 'Crawling Chorus', set: 'ONE',
    types: ['Creature'], subtypes: ['Phyrexian', 'Horror'], colors: ['W'],
    power: 1, toughness: 1, manaCost: 1, keywords: ['toxic'], toxic: 1,
    oracleText: 'Toxic 1 (Players dealt combat damage by this creature also get a poison counter.)\nWhen this creature dies, create a 1/1 colorless Phyrexian Mite artifact creature token with toxic 1 and "This token can\'t block."',
    imageUri: 'https://cards.scryfall.io/large/front/a/a/aace4c44-7250-414b-aac4-df042a1e2e1d.jpg?1783918086',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'dies' },
        effect: [{
          type: 'create_token', cardId: 'token_phyrexian_mite', name: 'Phyrexian Mite',
          kind: 'creature', power: 1, toughness: 1, colors: [],
          types: ['Artifact', 'Creature'], subtypes: ['Phyrexian', 'Mite'],
          keywords: ['toxic'], toxic: 1, cantBlock: true,
        }],
      }),
    ],
    artId: 456, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
    notes: ['toxic N: combat damage graczowi daje mu N poison counterów DODATKOWO do obrażeń (inaczej niż infect — życie spada normalnie)'],
  }),

  // 10. Pain for All (EOE) — „Enchant creature you control"; ETB: host zadaje
  //     obrażenia = swojej mocy w dowolny INNY cel; każdy damage w hosta
  //     odbija się w każdego przeciwnika (NOWY trigger na aurze).
  defineCard({
    id: 'pain-for-all', name: 'Pain for All', set: 'EOE',
    types: ['Enchantment'], subtypes: ['Aura'], colors: ['R'], manaCost: 3,
    oracleText: 'Enchant creature you control\nWhen this Aura enters, enchanted creature deals damage equal to its power to any other target.\nWhenever enchanted creature is dealt damage, it deals that much damage to each opponent.',
    imageUri: 'https://cards.scryfall.io/large/front/d/2/d2948913-817b-4715-92d5-ed3cde347be7.jpg?1783905949',
    aura: { enchantType: 'creature_you_control' },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'any_target', excludeAttachedHost: true } },
        effect: [{ type: 'damage_from_enchanted_power' }],
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enchanted_creature_dealt_damage' },
        effect: [{ type: 'damage_each_opponent', amountFrom: 'damageAmount', fromEnchanted: true }],
      }),
    ],
    artId: 344, plan: 'The Edge',
    support: { status: 'supported', limitations: [] },
    notes: ['źródłem obu porcji obrażeń jest ZACZAROWANY STWÓR (nie aura); utrata kontroli hosta zrzuca aurę (enchant creature you control — SBA)'],
  }),

  // =========================================================================
  // Batch 46 — 10 kart (2026-08-22, lista właściciela)
  // Cathartic Reunion, Roiling Regrowth, Manor Gate, Bone Shredder,
  // Infectious Horror, Guildscorn Ward, Gila Courser, Rediscover the Way,
  // Bring Low, Glint-Sleeve Artisan.
  // Dane Oracle: docs/cards/scryfall-* (pobrane 2026-08-22, ADR 0010 §2a).
  // =========================================================================

  // 1. Infectious Horror (CON) — {3}{B} 2/2: atak → każdy przeciwnik traci 2.
  //    Mechanika w całości istniejąca (trigger attacks + lose_life scope).
  defineCard({
    id: 'infectious-horror', name: 'Infectious Horror', set: 'CON',
    types: ['Creature'], subtypes: ['Zombie', 'Horror'], colors: ['B'],
    power: 2, toughness: 2, manaCost: 4,
    oracleText: 'Whenever this creature attacks, each opponent loses 2 life.',
    imageUri: 'https://cards.scryfall.io/large/front/b/b/bb460855-f09d-4460-9d3f-1bfcc7f3e626.jpg?1783942484',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'attacks' },
        effect: { type: 'lose_life', amount: 2, scope: 'each_opponent' },
      }),
    ],
    artId: 320, plan: 'Alara',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Roiling Regrowth (ZNR) — {2}{G} instant: poświęć ląd, znajdź do dwóch
  //    podstawowych lądów na pole bitwy TAPNIĘTE, potem tasuj. Efekt jak
  //    Springbloom Druid (ETB), tu jako CZAR — poświęcenie jest OBOWIĄZKOWE
  //    („Sacrifice a land.", nie „you may"), więc bez landa czar fizzluje.
  defineCard({
    id: 'roiling-regrowth', name: 'Roiling Regrowth', set: 'ZNR',
    types: ['Instant'], colors: ['G'], manaCost: 3,
    oracleText: 'Sacrifice a land. Search your library for up to two basic land cards, put them onto the battlefield tapped, then shuffle.',
    imageUri: 'https://cards.scryfall.io/large/front/f/a/fa259096-b24f-414c-af59-301bed4b4627.jpg?1783929332',
    spell: {
      timing: 'instant',
      effects: [{ type: 'springbloom_sacrifice_search', mandatory: true }],
    },
    artId: 270, plan: 'Zendikar',
    support: { status: 'supported', limitations: [] },
    notes: ['poświęcenie lądu jest OBOWIĄZKOWE (nie „you may") — bez lądu na polu bitwy czar nie robi nic'],
  }),

  // 3. Bring Low (KTK) — {3}{R} instant: 3 obrażenia w stwora, ale 5, gdy cel
  //    ma licznik +1/+1 (NOWE: warunkowa kwota obrażeń od stanu celu).
  defineCard({
    id: 'bring-low', name: 'Bring Low', set: 'KTK',
    types: ['Instant'], colors: ['R'], manaCost: 4,
    oracleText: 'Bring Low deals 3 damage to target creature. If that creature has a +1/+1 counter on it, Bring Low deals 5 damage to it instead.',
    imageUri: 'https://cards.scryfall.io/large/front/9/b/9ba5e7bf-2ad8-4061-937a-ef1e9b63da3d.jpg?1783939074',
    spell: {
      timing: 'instant',
      targets: [{ type: 'creature' }],
      effects: [{ type: 'damage', amount: 3, amountIfTargetHasCounter: { counter: '+1/+1', amount: 5 } }],
    },
    artId: 389, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
    notes: ['kwota liczona przy ROZSTRZYGNIĘCIU (CR 608.2) — licznik dołożony w odpowiedzi podbija obrażenia do 5'],
  }),

  // 4. Cathartic Reunion (2XM) — {1}{R} sorcery: dodatkowy koszt „odrzuć dwie
  //    karty" (CR 601.2h), potem dobierz trzy.
  defineCard({
    id: 'cathartic-reunion', name: 'Cathartic Reunion', set: '2XM',
    types: ['Sorcery'], colors: ['R'], manaCost: 2,
    oracleText: 'As an additional cost to cast this spell, discard two cards.\nDraw three cards.',
    imageUri: 'https://cards.scryfall.io/large/front/b/3/b36fa6f3-29e8-4788-bfcd-59576187c399.jpg?1783930169',
    spell: {
      timing: 'sorcery',
      additionalCost: { discardCards: 2 },
      effects: [{ type: 'draw_cards', amount: 3 }],
    },
    artId: 355, plan: 'Kaladesh',
    support: { status: 'supported', limitations: [] },
    notes: ['odrzucenie DWÓCH kart to koszt (CR 601.2h): płacony przy rzucaniu, więc kontrczar nie zwraca kart'],
  }),

  // 5. Guildscorn Ward (GTC) — {W} aura: zaczarowany ma ochronę przed
  //    WIELOKOLOROWYMI (CR 702.16e). NOWE: trwała ochrona po jakości na aurze.
  defineCard({
    id: 'guildscorn-ward', name: 'Guildscorn Ward', set: 'GTC',
    types: ['Enchantment'], subtypes: ['Aura'], colors: ['W'], manaCost: 1,
    oracleText: 'Enchant creature\nEnchanted creature has protection from multicolored.',
    imageUri: 'https://cards.scryfall.io/large/front/8/9/89c5c496-0a3e-40e1-84ac-8ad3a9d8352b.jpg?1783940143',
    aura: { enchant: 'creature', protection: { multicolored: true } },
    artId: 301, plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
    notes: ['„multicolored" = źródło o dwóch lub więcej kolorach (CR 105.4); ochrona znika natychmiast po odpięciu aury'],
  }),

  // 6. Glint-Sleeve Artisan (2XM) — {2}{W} 2/2: Fabricate 1 (CR 702.122).
  //    NOWE: wybór kontrolera przy ETB — licznik +1/+1 ALBO token Servo.
  defineCard({
    id: 'glint-sleeve-artisan', name: 'Glint-Sleeve Artisan', set: '2XM',
    types: ['Creature'], subtypes: ['Dwarf', 'Artificer'], colors: ['W'],
    power: 2, toughness: 2, manaCost: 3, keywords: ['fabricate'],
    oracleText: 'Fabricate 1 (When this creature enters, put a +1/+1 counter on it or create a 1/1 colorless Servo artifact creature token.)',
    imageUri: 'https://cards.scryfall.io/large/front/1/c/1c2fd5ac-963b-49ea-bd72-d0958ef8eb3e.jpg?1783930215',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{ type: 'fabricate', amount: 1 }],
      }),
    ],
    artId: 189, plan: 'Kaladesh',
    support: { status: 'supported', limitations: [] },
    notes: ['wybór (licznik albo token) należy do kontrolera — blokująca decyzja resolve_fabricate'],
  }),

  // 7. Bone Shredder (MH2) — {2}{B} 1/1 flying: ETB destroy target
  //    nonartifact, nonblack creature; Echo {2}{B} (CR 702.29).
  defineCard({
    id: 'bone-shredder', name: 'Bone Shredder', set: 'MH2',
    types: ['Creature'], subtypes: ['Phyrexian', 'Minion'], colors: ['B'],
    power: 1, toughness: 1, manaCost: 3, keywords: ['flying', 'echo'],
    // M259/B7: echo {2}{B} — echoColors niesie pipy kolorowe (dotąd koszt
    // płatny 3 bezbarwnymi; CR 702.29 + 118.2).
    echo: 3, echoColors: ['B'],
    oracleText: 'Flying\nEcho {2}{B} (At the beginning of your upkeep, if this came under your control since the beginning of your last upkeep, sacrifice it unless you pay its echo cost.)\nWhen this creature enters, destroy target nonartifact, nonblack creature.',
    imageUri: 'https://cards.scryfall.io/large/front/6/3/63d0b5f0-ed45-4b30-9c24-1c12011e3513.jpg?1783926787',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'creature', notArtifact: true, notColors: ['B'] } },
        effect: [{ type: 'destroy_permanent' }],
      }),
    ],
    artId: 326, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
    notes: ['echo płaci się w PIERWSZYM własnym upkeepie po wejściu (CR 702.29); bez many na opłatę stwór jest poświęcany'],
  }),

  // 8. Manor Gate (CLB) — land Gate: wchodzi tapnięty, przy wejściu wybór
  //    koloru INNEGO NIŻ ZIELONY; {T}: {G} albo mana wybranego koloru.
  defineCard({
    id: 'manor-gate', name: 'Manor Gate', set: 'CLB',
    types: ['Land'], subtypes: ['Gate'], colors: [],
    oracleText: 'This land enters tapped.\nAs this land enters, choose a color other than green.\n{T}: Add {G} or one mana of the chosen color.',
    imageUri: 'https://cards.scryfall.io/large/front/7/9/793d4978-9e00-453d-8dc2-6d51ad6c26b7.jpg?1783922657',
    entersTapped: true,
    chooseColor: { exclude: ['G'] },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        // M193/A: Oracle „{T}: Add {G} or one mana of the chosen color" —
        // baza {G} w deskryptorze; wybrany kolor doklada getSourceForObject
        // z pola `chosenColor` obiektu gry (ustawianego przy wejsciu).
        effect: { type: 'add_mana', amount: 1, colors: ['G'] },
      }),
    ],
    artId: 217, plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
    notes: ['kolory produkcji: {G} + wybrany przy wejściu (deskryptor chooseColor.exclude pilnuje „other than green")'],
  }),

  // 9. Gila Courser (OTJ) — {2}{R} 4/2 Mount: atak w stanie saddled wygania
  //    wierzch biblioteki z prawem zagrania do końca NASTĘPNEJ tury; Saddle 1.
  defineCard({
    id: 'gila-courser', name: 'Gila Courser', set: 'OTJ',
    types: ['Creature'], subtypes: ['Lizard', 'Mount'], colors: ['R'],
    power: 4, toughness: 2, manaCost: 3, keywords: ['saddle'],
    oracleText: 'Whenever this creature attacks while saddled, exile the top card of your library. Until the end of your next turn, you may play that card.\nSaddle 1 (Tap any number of other creatures you control with total power 1 or more: This Mount becomes saddled until end of turn. Saddle only as a sorcery.)',
    imageUri: 'https://cards.scryfall.io/large/front/f/5/f568803d-65c0-48d7-916f-671267a9e00e.jpg?1783911821',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'attacks', condition: { saddled: true } },
        effect: [{ type: 'exile_top_playable_until_next_turn' }],
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'saddle',
        timing: 'sorcery',
        cost: { saddlePower: 1 },
        effect: { type: 'set_saddled' },
      }),
    ],
    artId: 300, plan: 'Thunder Junction',
    support: { status: 'supported', limitations: [] },
    notes: ['wygnana karta jest grywalna z exile za PEŁNY koszt do końca twojej następnej tury (impulse)'],
  }),

  // 10. Rediscover the Way (TDM) — {U}{R}{W} Saga: I i II ten sam rozdział
  //     (look 3, jedną do ręki, reszta na spód), III — double strike po
  //     rzuceniu czaru niebędącego stworem w tej turze.
  defineCard({
    id: 'rediscover-the-way', name: 'Rediscover the Way', set: 'TDM',
    types: ['Enchantment'], subtypes: ['Saga'], colors: ['U', 'R', 'W'], manaCost: 3,
    oracleText: '(As this Saga enters and after your draw step, add a lore counter. Sacrifice after III.)\nI, II — Look at the top three cards of your library. Put one of them into your hand and the rest on the bottom of your library in any order.\nIII — Whenever you cast a noncreature spell this turn, target creature you control gains double strike until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/7/9/79d6decf-afd5-4e96-b87e-fd7ab7e3c068.jpg?1783907303',
    saga: {
      chapterNames: ['Rediscover the Way', 'Rediscover the Way', 'Rediscover the Way'],
      chapters: [
        // I — look 3, jedna do ręki, reszta na spód (ten sam efekt co II).
        [{ type: 'look_top_put_one_hand_rest_bottom', amount: 3 }],
        // II — identyczny rozdział (Oracle: „I, II —").
        [{ type: 'look_top_put_one_hand_rest_bottom', amount: 3 }],
        // III — opóźniony trigger na czar niebędący stworem w TEJ turze.
        [{ type: 'grant_double_strike_on_noncreature_cast_this_turn' }],
      ],
    },
    artId: 292, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
    notes: ['rozdziały I i II mają identyczny efekt (Oracle „I, II —"); III działa do końca tury, w której Saga dobiła do trzeciego licznika'],
  }),

  // =========================================================================
  // Batch 47 (8 kart, 2026-08-23) — lista właściciela (M194)
  // Caves of Chaos Adventurer, Curate (STX), Pyxis of Pandemonium, Divest,
  // Negate (M15), Supernatural Stamina, Sequestered Stash, Enduring Sliver.
  // Dane Oracle: docs/cards/scryfall-*.json (pobrane 2026-08-23).
  //
  // DWA WARIANTY TEJ SAMEJ KARTY (decyzja właściciela): Curate i Negate już
  // były w katalogu w innych drukach. Właściciel nie zmienia tamtych kart —
  // dokłada drugi egzemplarz z własnym artem i PLANEM, żeby trafił do innej
  // talii. Reguły są identyczne (ten sam Oracle), różni się tylko druk.
  // Pliki talii rozróżniają je sufiksem setu (M194/K1, deck-text.js).
  // =========================================================================

  // ---- Batch 47 — transza A: warianty druku (zero nowych mechanik) ----

  // 1. Curate (STX) — drugi druk karty `curate` (BRO). Oracle identyczny:
  //    „Surveil 2. Draw a card." Plan: Arcavios (art 65STX).
  defineCard({
    id: 'curate-stx', name: 'Curate', set: 'STX',
    types: ['Instant'], colors: ['U'], manaCost: 2,
    oracleText: 'Surveil 2. (Look at the top two cards of your library, then put any number of them into your graveyard and the rest on top of your library in any order.)\nDraw a card.',
    imageUri: 'https://cards.scryfall.io/large/front/f/2/f2a0e716-22b7-4a5e-9b7a-d4a806ee7427.jpg?1783927381',
    spell: {
      timing: 'instant',
      targets: [],
      effects: [
        { type: 'surveil', amount: 2 },
        { type: 'draw_cards', amount: 1 },
      ],
    },
    artId: 65, plan: 'Arcavios',
    support: { status: 'supported', limitations: [] },
    notes: ['drugi druk karty Curate (obok BRO/Forgotten Realms) — te same reguły, inny art i plan; talie rozróżniają egzemplarze sufiksem setu'],
  }),

  // 2. Negate (M15) — drugi druk karty `negate` (M20). Oracle identyczny:
  //    „Counter target noncreature spell." Plan: Warhammer Fantasy (art 76M15).
  defineCard({
    id: 'negate-m15', name: 'Negate', set: 'M15',
    types: ['Instant'], colors: ['U'], manaCost: 2,
    oracleText: 'Counter target noncreature spell.',
    imageUri: 'https://cards.scryfall.io/large/front/6/4/64a2ba6d-ada1-4f06-b135-37606b6588fc.jpg?1783939190',
    spell: {
      timing: 'instant',
      targets: [{ type: 'noncreature_spell_on_stack' }],
      effects: [{ type: 'counter_spell' }],
    },
    artId: 76, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
    notes: ['drugi druk karty Negate (obok M20/Wiedźmin) — te same reguły, inny art i plan'],
  }),

  // ---- Batch 47 — transza B: istniejące mechaniki + deskryptorowy filtr ----

  // 3. Divest (2XM) — reveal + wybór artefaktu/stwora do odrzucenia.
  //    Wzorzec Toll of the Invasion, ale Oracle zawęża wybór do „artifact or
  //    creature card" — stąd deskryptor `filter.anyTypes` (ADR 0002).
  defineCard({
    id: 'divest', name: 'Divest', set: '2XM',
    types: ['Sorcery'], colors: ['B'], manaCost: 1,
    oracleText: 'Target player reveals their hand. You choose an artifact or creature card from it. That player discards that card.',
    imageUri: 'https://cards.scryfall.io/large/front/4/4/4494cb6d-1a99-40b6-96cc-0dc2ddec102f.jpg?1783930183',
    spell: {
      timing: 'sorcery',
      targets: [{ type: 'player' }],
      effects: [{
        type: 'reveal_hand_choose_discard',
        // „You choose" = wybór OBOWIĄZKOWY, bez wariantu „If you don't"
        // (to Nightsnare). Brak artefaktu/stwora w ręce = nikt nic nie odrzuca.
        mandatory: true,
        filter: { anyTypes: ['Artifact', 'Creature'] },
      }],
    },
    artId: 52, plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
    notes: ['cel „target player\" obejmuje też samego siebie (Oracle nie mówi „opponent\"); filtr artefakt/stwór jest deskryptorem, nie warunkiem po nazwie karty'],
  }),

  // 4. Supernatural Stamina (2XM) — +2/+0 i nadany trigger „dies → wróć
  //    zatapniony". Wzorzec Fake Your Own Death, ale BEZ tokenu Skarbu.
  defineCard({
    id: 'supernatural-stamina', name: 'Supernatural Stamina', set: '2XM',
    types: ['Instant'], colors: ['B'], manaCost: 1,
    oracleText: 'Until end of turn, target creature gets +2/+0 and gains "When this creature dies, return it to the battlefield tapped under its owner\'s control."',
    imageUri: 'https://cards.scryfall.io/large/front/f/0/f0bff1b7-838f-48de-96bd-0c79e59ff827.jpg?1783930174',
    spell: {
      timing: 'instant',
      targets: [{ type: 'creature' }],
      effects: [
        { type: 'pump', power: 2, toughness: 0 },
        {
          type: 'grant_abilities',
          abilities: [
            createAbility({
              type: ABILITY_TYPE.triggered,
              trigger: { event: 'dies' },
              effect: [{ type: 'return_to_battlefield_tapped' }],
            }),
          ],
        },
      ],
    },
    artId: 383, plan: 'Amonkhet',
    support: { status: 'supported', limitations: [] },
    notes: ['nadany trigger dies działa z LKI (formerAbilityGrants) — przechodzi z obiektem do grobu w tej samej turze', 'wraca pod kontrolę WŁAŚCICIELA (Oracle „its owner\'s control\") — istotne przy przejętych stworach'],
  }),

  // ---- Batch 47 — transza C: Sequestered Stash ----

  // 5. Sequestered Stash (KLD) — land {C} + zdolność „mill 5, potem MOŻESZ
  //    wziąć artefakt z grobu na wierzch biblioteki". Kolejność z Oracle jest
  //    istotna: wybór następuje PO millu, więc kandydatem może być artefakt
  //    dopiero co zmielony (CR 608.2).
  defineCard({
    id: 'sequestered-stash', name: 'Sequestered Stash', set: 'KLD',
    types: ['Land'], colors: [],
    oracleText: '{T}: Add {C}.\n{4}, {T}, Sacrifice this land: Mill five cards. Then you may put an artifact card from your graveyard on top of your library.',
    imageUri: 'https://cards.scryfall.io/large/front/8/6/86a17084-bb96-4e81-bff0-005bd44a1fbd.jpg?1783937143',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        // Oracle „Add {C}" — mana BEZBARWNA (brak `colors`), czytana wprost
        // z deskryptora (M193/A: kolory źródeł many idą z danych karty).
        effect: { type: 'add_mana', amount: 1 },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 4, tap: true, sacrificeSelf: true },
        effect: [
          { type: 'mill_cards', amount: 5 },
          {
            type: 'graveyard_card_to_library_top_choice',
            filter: { anyTypes: ['Artifact'] },
          },
        ],
      }),
    ],
    artId: 384, plan: 'Kaladesh',
    support: { status: 'supported', limitations: [] },
    notes: ['mill dotyczy WŁASNEJ biblioteki (Oracle „Mill five cards" bez wskazania gracza = kontroler)', 'wybór artefaktu jest opcjonalny („you may") i następuje PO millu — zmielony artefakt też jest kandydatem'],
  }),

  // ---- Batch 47 — transza C: Enduring Sliver (keyword outlast) ----

  // 6. Enduring Sliver (MH1) — outlast {2} + nadanie outlast innym Sliverom.
  //    CR 702.100a: „Outlast [cost]" = „[cost], {T}: Put a +1/+1 counter on
  //    this creature. Activate only as a sorcery."
  defineCard({
    id: 'enduring-sliver', name: 'Enduring Sliver', set: 'MH1',
    types: ['Creature'], subtypes: ['Sliver'], colors: ['W'],
    power: 2, toughness: 2, manaCost: 2, keywords: ['outlast'],
    oracleText: 'Outlast {2} ({2}, {T}: Put a +1/+1 counter on this creature. Outlast only as a sorcery.)\nOther Sliver creatures you control have outlast {2}.',
    imageUri: 'https://cards.scryfall.io/large/front/6/e/6ed0f6a5-ed40-44fc-a5e1-3f8bb968d1d9.jpg?1783933164',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'outlast',
        cost: { mana: 2, tap: true },
        timing: 'sorcery',
        effect: { type: 'add_counter', counter: '+1/+1', amount: 1 },
      }),
      // „Other Sliver creatures you control have outlast {2}" — zdolność
      // statyczna nadająca AKTYWOWANĄ zdolność plemieniu (CR 604). Zasięg po
      // PODTYPIE (wzorzec Altar of the Goyf); `grantsAbilities` niesie tę samą
      // zdolność, którą ma źródło, więc opis i koszt nie mogą się rozjechać.
      createAbility({
        type: ABILITY_TYPE.static,
        scope: {
          affects: 'creatures_with_subtype',
          subtype: 'Sliver',
          grantsAbilities: [
            createAbility({
              type: ABILITY_TYPE.activated,
              keyword: 'outlast',
              cost: { mana: 2, tap: true },
              timing: 'sorcery',
              effect: { type: 'add_counter', counter: '+1/+1', amount: 1 },
            }),
          ],
        },
      }),
    ],
    artId: 349, plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
    notes: ['outlast (CR 702.100a) wymaga {T} i działa tylko jak sorcery — stwór z chorobą przywołania go nie użyje', 'nadanie plemieniu liczone przy odczycie: zniknięcie Enduring Slivera natychmiast odbiera outlast pozostałym Sliverom'],
  }),

  // ---- Batch 47 — transza D: Caves of Chaos Adventurer ----

  // 7. Caves of Chaos Adventurer (CLB) — trample, ETB inicjatywa, a przy
  //    ataku impulse-exile z bonusem za UKOŃCZONY loch (CR 701.51b).
  defineCard({
    id: 'caves-of-chaos-adventurer', name: 'Caves of Chaos Adventurer', set: 'CLB',
    types: ['Creature'], subtypes: ['Human', 'Barbarian'], colors: ['R'],
    power: 5, toughness: 3, manaCost: 4, keywords: ['trample'],
    oracleText: "Trample\nWhen this creature enters, you take the initiative.\nWhenever this creature attacks, exile the top card of your library. If you've completed a dungeon, you may play that card this turn without paying its mana cost. Otherwise, you may play that card this turn.",
    imageUri: 'https://cards.scryfall.io/large/front/0/9/09abb6df-2aa1-4999-b550-db2892faa8c7.jpg?1783922743',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{ type: 'take_initiative' }],
      }),
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'attacks' },
        effect: [{
          type: 'exile_top_playable_until_next_turn',
          // „If you've completed a dungeon … without paying its mana cost."
          // Warunek w DANYCH; silnik sprawdza stan lochu (ADR 0002).
          freeIfCondition: { type: 'completed_dungeon' },
        }],
      }),
    ],
    artId: 175, plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
    notes: ['ukończenie lochu = dotarcie do pokoju bez dalszych ścieżek (Throne of the Dead Three) — Undercity jest grafem, więc liczy się brak wyjścia, nie numer pokoju', 'bez ukończonego lochu karta i tak jest grywalna w tej turze, ale za pełny koszt many'],
  }),

  // ---- Batch 47 — transza E: Pyxis of Pandemonium ----

  // 8. Pyxis of Pandemonium (THS) — {T}: każdy gracz wygania wierzch swojej
  //    biblioteki ZAKRYTY; {7},{T},poświęć: wszyscy odkrywają swoje karty
  //    wygnane TYM artefaktem i kładą spośród nich permanenty na pole bitwy.
  defineCard({
    id: 'pyxis-of-pandemonium', name: 'Pyxis of Pandemonium', set: 'THS',
    types: ['Artifact'], colors: [], manaCost: 1,
    oracleText: '{T}: Each player exiles the top card of their library face down.\n{7}, {T}, Sacrifice this artifact: Each player turns face up all cards they own exiled with this artifact, then puts all permanent cards among them onto the battlefield.',
    imageUri: 'https://cards.scryfall.io/large/front/d/b/dbc6a246-f32a-4dc0-9785-4038804f372f.jpg?1783939717',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        effect: { type: 'each_player_exiles_top_face_down' },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 7, tap: true, sacrificeSelf: true },
        effect: { type: 'turn_up_exiled_and_put_permanents' },
      }),
    ],
    artId: 21, plan: 'Theros',
    support: { status: 'supported', limitations: [] },
    notes: ['karty wygnane tym artefaktem są POWIĄZANE ze źródłem (exiledCardIds, CR 400.7) — druga zdolność odkrywa wyłącznie je', 'permanenty wchodzą pod kontrolę WŁAŚCICIELA karty (Oracle „all cards they own"), instanty i sorcery zostają w wygnaniu odkryte'],
  }),

  // =========================================================================
  // Batch 48 (14 kart, 2026-08-23) — lista właściciela (M196)
  // Pierwszy batch w NOWYM formacie: artId, set i plan podane wprost
  // w zleceniu (bez zgadywania ze słownika kolekcji).
  // Dane Oracle: docs/cards/scryfall-*.json (pobrane 2026-08-23).
  // =========================================================================

  // ---- Batch 48 — transza A: istniejące mechaniki ----

  // 1. Thraben Valiant (AVR) — 2/1 vigilance.
  defineCard({
    id: 'thraben-valiant', name: 'Thraben Valiant', set: 'AVR',
    types: ['Creature'], subtypes: ['Human', 'Soldier'], colors: ['W'],
    power: 2, toughness: 1, manaCost: 2, keywords: ['vigilance'],
    oracleText: 'Vigilance',
    imageUri: 'https://cards.scryfall.io/large/front/2/0/20558f69-9240-49b9-9695-caf75ee2db1b.jpg?1783940728',
    artId: 544, plan: 'Innistrad',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Quicksilver Fisher (ONE) — 4/3 flying, ETB „draw, then discard".
  defineCard({
    id: 'quicksilver-fisher', name: 'Quicksilver Fisher', set: 'ONE',
    types: ['Creature'], subtypes: ['Phyrexian', 'Drake'], colors: ['U'],
    power: 4, toughness: 3, manaCost: 5, keywords: ['flying'],
    oracleText: 'Flying\nWhen this creature enters, draw a card, then discard a card.',
    imageUri: 'https://cards.scryfall.io/large/front/b/a/bad0e96a-b4cc-4439-aab9-731a1036145d.jpg?1783918058',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{ type: 'draw_then_discard', amount: 1 }],
      }),
    ],
    artId: 547, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Coat with Venom (DTK) — +1/+2 i deathtouch do końca tury.
  defineCard({
    id: 'coat-with-venom', name: 'Coat with Venom', set: 'DTK',
    types: ['Instant'], colors: ['B'], manaCost: 1,
    oracleText: 'Target creature gets +1/+2 and gains deathtouch until end of turn. (Any amount of damage it deals to a creature is enough to destroy it.)',
    imageUri: 'https://cards.scryfall.io/large/front/8/c/8cc8e012-7043-405c-b6cd-b3b38f8a8d54.jpg?1783938600',
    spell: {
      timing: 'instant',
      targets: [{ type: 'creature' }],
      effects: [
        { type: 'pump', power: 1, toughness: 2 },
        { type: 'grant_keywords_until_end_of_turn', keywords: ['deathtouch'] },
      ],
    },
    artId: 553, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),

  // 4. Frost Lynx (M15) — ETB: tapnij stwora wroga; nie odkręci się
  //    w jego najbliższym kroku odkręcania (tap + lock_untap, wzorzec Liry).
  defineCard({
    id: 'frost-lynx', name: 'Frost Lynx', set: 'M15',
    types: ['Creature'], subtypes: ['Elemental', 'Cat'], colors: ['U'],
    power: 2, toughness: 2, manaCost: 3,
    oracleText: "When this creature enters, tap target creature an opponent controls. That creature doesn't untap during its controller's next untap step.",
    imageUri: 'https://cards.scryfall.io/large/front/6/1/619268d2-f7a8-48cd-b17b-197e82474b13.jpg?1783939193',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield', requiresTarget: { type: 'creature_opponent_controls' } },
        effect: [
          { type: 'tap_permanent' },
          { type: 'lock_untap' },
        ],
      }),
    ],
    artId: 550, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Bedhead Beastie (DSK) — 5/6 menace + Mountaincycling {2}
  //    (typecycling: szuka LĄDU o podtypie Mountain, nie karty „Mountain").
  defineCard({
    id: 'bedhead-beastie', name: 'Bedhead Beastie', set: 'DSK',
    types: ['Creature'], subtypes: ['Beast'], colors: ['R'],
    power: 5, toughness: 6, manaCost: 6, keywords: ['menace'],
    oracleText: 'Menace (This creature can\'t be blocked except by two or more creatures.)\nMountaincycling {2} ({2}, Discard this card: Search your library for a Mountain card, reveal it, put it into your hand, then shuffle.)',
    imageUri: 'https://cards.scryfall.io/large/front/7/7/77c72b5b-dd81-4eb4-80d9-a0124e27e1dc.jpg?1783909472',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'cycling',
        cost: { mana: 2 },
        cycling: { subtypes: ['Mountain'] },
        effect: [],
      }),
    ],
    artId: 555, plan: 'Wiedźmin',
    support: { status: 'supported', limitations: [] },
  }),

  // 6. Ettercap // Web Shot (CLB) — stwór 2/5 reach z Adventure niszczącą
  //    latającego stwora (CR 715: przygoda wygania kartę, potem rzut stwora).
  defineCard({
    id: 'ettercap', name: 'Ettercap', set: 'CLB',
    types: ['Creature'], subtypes: ['Spider', 'Beast'], colors: ['G'],
    power: 2, toughness: 5, manaCost: 5, keywords: ['reach'],
    oracleText: 'Reach // Destroy target creature with flying. (Then exile this card. You may cast the creature later from exile.)',
    imageUri: 'https://cards.scryfall.io/large/front/8/f/8f5228dc-ec9d-456f-a89c-1bc592a1bbab.jpg?1783922714',
    adventure: {
      cost: 3, colors: ['G'],
      spell: {
        timing: 'instant',
        targets: [{ type: 'creature_with_keyword', keyword: 'flying' }],
        effects: [{ type: 'destroy_permanent' }],
      },
    },
    artId: 552, plan: 'Forgotten Realms',
    support: { status: 'supported', limitations: [] },
    notes: ['Adventure „Web Shot" niszczy WYŁĄCZNIE stwora z lataniem (creature_with_keyword) — wzorzec Sagittars\' Volley'],
  }),

  // ---- Batch 48 — transza B: kontra z proliferate, trigger bloku ----

  // 7. Fuel for the Cause (MBS) — „Counter target spell, then proliferate."
  //    Oba efekty już istnieją; nowość to ich ZŁOŻENIE w jednym czarze.
  defineCard({
    id: 'fuel-for-the-cause', name: 'Fuel for the Cause', set: 'MBS',
    types: ['Instant'], colors: ['U'], manaCost: 4,
    oracleText: 'Counter target spell, then proliferate. (Choose any number of permanents and/or players, then give each another counter of each kind already there.)',
    imageUri: 'https://cards.scryfall.io/large/front/4/1/4126e0e5-9b23-496f-8a09-7a35499f9a09.jpg?1783941389',
    spell: {
      timing: 'instant',
      targets: [{ type: 'spell_on_stack' }],
      effects: [
        { type: 'counter_spell' },
        // Proliferate (CR 701.27) — blokująca decyzja gracza (resolve_proliferate).
        { type: 'proliferate' },
      ],
    },
    artId: 545, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Wooden Stake (ISD) — sprzęt +1/+0; nosiciel zabija Wampira, którego
  //    blokuje albo który blokuje jego (bez regeneracji).
  defineCard({
    id: 'wooden-stake', name: 'Wooden Stake', set: 'ISD',
    types: ['Artifact'], subtypes: ['Equipment'], colors: [], manaCost: 2,
    oracleText: "Equipped creature gets +1/+0.\nWhenever equipped creature blocks or becomes blocked by a Vampire, destroy that creature. It can't be regenerated.\nEquip {1} ({1}: Attach to target creature you control. Equip only as a sorcery.)",
    imageUri: 'https://cards.scryfall.io/large/front/7/e/7e2825f5-8112-4108-910a-4303b2d57356.jpg?1783940895',
    equipment: { equip: 1, pump: { power: 1, toughness: 0 } },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'equip',
        cost: { mana: 1 },
        effect: [],
      }),
      // NOWY trigger (Batch 48): blok w OBIE strony — nosiciel blokuje Wampira
      // albo Wampir blokuje nosiciela. Podtyp jest deskryptorem (ADR 0002),
      // więc ta sama ścieżka obsłuży przyszłe „…by a Zombie" itd.
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'equipped_creature_blocks_or_blocked_by', subtype: 'Vampire' },
        effect: [
          { type: 'destroy_permanent' },
          { type: 'cant_be_regenerated_this_turn' },
        ],
      }),
    ],
    artId: 543, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
    notes: ['trigger działa w OBIE strony (CR 509.1): nosiciel blokujący Wampira i Wampir blokujący nosiciela'],
  }),

  // ---- Batch 48 — transza C: equip warunkowy, globalny zakaz bloku ----

  // 9. Steelclaw Lance (ELD) — +2/+2 z DWOMA kosztami equip: tańszy dla
  //    Rycerza (CR 702.6e). Koszt zależy od CELU, nie od samego sprzętu.
  defineCard({
    id: 'steelclaw-lance', name: 'Steelclaw Lance', set: 'ELD',
    types: ['Artifact'], subtypes: ['Equipment'], colors: ['B', 'R'], manaCost: 2,
    oracleText: 'Equipped creature gets +2/+2.\nEquip Knight {1}\nEquip {3}',
    imageUri: 'https://cards.scryfall.io/large/front/c/a/cafcf909-d726-4bc2-adf6-c12ca242f0c1.jpg?1783932592',
    equipment: {
      equip: 3,
      pump: { power: 2, toughness: 2 },
      // Tańszy wariant equipu dla wskazanego PODTYPU (deskryptor, ADR 0002).
      equipFor: { subtype: 'Knight', equip: 1 },
    },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'equip',
        cost: { mana: 3 },
        effect: [],
      }),
    ],
    artId: 548, plan: 'Eldraine',
    support: { status: 'supported', limitations: [] },
    notes: ['dwa koszty equip: {1} na Rycerza, {3} na dowolnego innego stwora — oferta i płatność liczą koszt dla KONKRETNEGO celu'],
  }),

  // 10. Ruthless Invasion (NPH) — „Nonartifact creatures can't block this
  //     turn." Koszt {3}{R/P}: phyrexian można zapłacić 2 życiami.
  defineCard({
    id: 'ruthless-invasion', name: 'Ruthless Invasion', set: 'NPH',
    // M259/B3 (CR 202.3): manaCost = PEŁNA wartość kosztu ({3}{R/P} = 4,
    // włącznie z symbolem phyrexian) — wspólna konwencja z Porcelain
    // Legionnaire; płatność odejmuje pipy opłacone życiem.
    types: ['Sorcery'], colors: ['R'], manaCost: 4, phyrexianManaCost: 1,
    oracleText: "({R/P} can be paid with either {R} or 2 life.)\nNonartifact creatures can't block this turn.",
    imageUri: 'https://cards.scryfall.io/large/front/b/c/bc2bbff9-af57-4858-9351-d148b8c4bc3a.jpg?1783941306',
    spell: {
      timing: 'sorcery',
      targets: [],
      effects: [{ type: 'creatures_cant_block_this_turn', exceptTypes: ['Artifact'] }],
    },
    artId: 556, plan: 'Mirrodin',
    support: { status: 'supported', limitations: [] },
    notes: ['efekt globalny bez celu; zbiór stworów ustalany PRZY ROZSTRZYGNIĘCIU (CR 611.2c) — stwór wchodzący później blokuje normalnie'],
  }),

  // ---- Batch 48 — transza D: aura warunkowa, formidable ----

  // 11. Clawing Torment (NEO) — aura na artefakt LUB stwora: -1/-1 i zakaz
  //     bloku (gdy jest stworem) oraz utrata 1 życia w upkeepie kontrolera.
  defineCard({
    id: 'clawing-torment', name: 'Clawing Torment', set: 'NEO',
    types: ['Enchantment'], subtypes: ['Aura'], colors: ['B'], manaCost: 1,
    oracleText: 'Enchant artifact or creature\nAs long as enchanted permanent is a creature, it gets -1/-1 and can\'t block.\nEnchanted permanent has "At the beginning of your upkeep, you lose 1 life."',
    imageUri: 'https://cards.scryfall.io/large/front/6/2/621fce96-5933-4e2b-98ec-2589940e24cb.jpg?1783923889',
    // „As long as enchanted permanent IS A CREATURE" — pump i zakaz bloku
    // dotyczą wyłącznie stworów, więc na artefakcie bez typu Creature
    // po prostu nie mają na czym zadziałać (silnik liczy je dla stworów).
    // `ownControlOnly: false` — Oracle NIE mówi „you control", więc aura
    // celuje też w permanenty przeciwnika (to karta-debuff).
    aura: { enchantType: 'artifact_or_creature', ownControlOnly: false, pump: { power: -1, toughness: -1 }, cantBlock: true },
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'upkeep', condition: { enchantedPermanentControllerUpkeep: true } },
        effect: { type: 'lose_life_enchanted_permanent_controller', amount: 1 },
      }),
    ],
    artId: 546, plan: 'Kamigawa',
    support: { status: 'supported', limitations: [] },
    notes: ['utrata życia (CR 118.2), nie obrażenia — prewencja obrażeń jej nie zatrzyma', 'wzorzec triggera upkeepu z Feedback (enchantedPermanentControllerUpkeep)'],
  }),

  // 12. Stampeding Elk Herd (DTK) — formidable (CR 702.103): przy ataku,
  //     jeśli łączna moc twoich stworów ≥ 8, cała drużyna dostaje trample.
  defineCard({
    id: 'stampeding-elk-herd', name: 'Stampeding Elk Herd', set: 'DTK',
    types: ['Creature'], subtypes: ['Elk'], colors: ['G'],
    power: 5, toughness: 5, manaCost: 5,
    oracleText: 'Formidable — Whenever this creature attacks, if creatures you control have total power 8 or greater, creatures you control gain trample until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/7/e/7e55e213-6eab-4086-96cd-024de6150fbe.jpg?1783938575',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'attacks', condition: { minTotalPowerYouControl: 8 } },
        effect: { type: 'your_creatures_gain_keywords_until_end_of_turn', keywords: ['trample'] },
      }),
    ],
    artId: 549, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
    notes: ['formidable to intervening-if (CR 603.4): warunek sprawdzany przy odpaleniu I przy rozstrzyganiu', 'moc liczona EFEKTYWNIE (bufy, liczniki), nie wydrukowana'],
  }),

  // ---- Batch 48 — transza E: przejmowany artefakt, Dinozaury z flash ----

  // 13. Contested Game Ball (LCI) — piłka przechodzi do gracza, który zada
  //     ci obrażenia bojowe; po piątym liczniku point znika, dając Skarb.
  defineCard({
    id: 'contested-game-ball', name: 'Contested Game Ball', set: 'LCI',
    types: ['Artifact'], colors: [], manaCost: 2,
    oracleText: "Whenever you're dealt combat damage, the attacking player gains control of this artifact and untaps it.\n{2}, {T}: Draw a card and put a point counter on this artifact. Then if it has five or more point counters on it, sacrifice it and create a Treasure token.",
    imageUri: 'https://cards.scryfall.io/large/front/7/1/71cb7776-a6af-4efb-b536-6b9b4f3d3874.jpg?1783913724',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'combat_damage_to_you' },
        effect: [{ type: 'attacker_gains_control_and_untaps' }],
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2, tap: true },
        effect: [
          { type: 'draw_cards', amount: 1 },
          { type: 'add_counter', counter: 'point', amount: 1 },
          { type: 'sacrifice_self_if_counters_then_treasure', counter: 'point', threshold: 5 },
        ],
      }),
    ],
    artId: 551, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
    notes: ['zmiana kontroli jest TRWAŁA (nie „do końca tury") — piłka krąży między graczami', 'próg 5 liczników jest deskryptorem (counter/threshold), nie stałą w kodzie'],
  }),

  // 14. Cherished Hatchling (RIX) — po śmierci Dinozaury zyskują w tej turze
  //     flash oraz ETB „możesz walczyć z innym stworem".
  defineCard({
    id: 'cherished-hatchling', name: 'Cherished Hatchling', set: 'RIX',
    types: ['Creature'], subtypes: ['Dinosaur'], colors: ['G'],
    power: 2, toughness: 1, manaCost: 2,
    oracleText: 'When this creature dies, you may cast Dinosaur spells this turn as though they had flash, and whenever you cast a Dinosaur spell this turn, it gains "When this creature enters, you may have it fight another target creature."',
    imageUri: 'https://cards.scryfall.io/large/front/0/a/0a14fe6c-b272-415b-974d-c60d016ab786.jpg?1783935290',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'dies' },
        effect: [{ type: 'subtype_spells_gain_flash_and_etb_fight_this_turn', subtype: 'Dinosaur' }],
      }),
    ],
    artId: 554, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
    notes: ['efekt dotyczy PRZYSZŁYCH czarów w tej turze — pozwolenie żyje w stanie tury (subtypeFlashThisTurn), nie na karcie', 'podtyp jest deskryptorem, więc ta sama ścieżka obsłuży przyszłe „Angel spells"'],
  }),


  // ==== Batch 49 (lista właściciela 557–566) ====

  // 1. Shock (AER) {R} Instant — 2 obrażenia w dowolny cel.
  defineCard({
    id: 'shock', name: 'Shock', set: 'AER',
    types: ['Instant'], colors: ['R'], manaCost: 1,
    oracleText: 'Shock deals 2 damage to any target.',
    imageUri: 'https://cards.scryfall.io/large/front/0/0/00365412-41db-427c-9109-8f69c17c326d.jpg?1783936748',
    spell: {
      timing: 'instant',
      targets: [{ type: 'any_target' }],
      effects: [{ type: 'damage', amount: 2 }],
    },
    artId: 562, plan: 'Kaladesh',
    support: { status: 'supported', limitations: [] },
  }),

  // 2. Razorfoot Griffin (INV) {3}{W} 2/2 — flying + first strike.
  defineCard({
    id: 'razorfoot-griffin', name: 'Razorfoot Griffin', set: 'INV',
    types: ['Creature'], subtypes: ['Griffin'], colors: ['W'],
    power: 2, toughness: 2, manaCost: 4,
    keywords: ['flying', 'first_strike'],
    oracleText: 'Flying (This creature can\'t be blocked except by creatures with flying or reach.)\\nFirst strike (This creature deals combat damage before creatures without first strike.)',
    imageUri: 'https://cards.scryfall.io/large/front/8/1/819e2046-9b78-4fd0-92f8-798bfac51195.jpg?1783945714',
    artId: 564, plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
  }),

  // 3. Gaelicat (FIN) {2}{W} 1/3 — flying, vigilance; +2/+0 przy 2+ artefaktach.
  defineCard({
    id: 'gaelicat', name: 'Gaelicat', set: 'FIN',
    types: ['Creature'], subtypes: ['Cat'], colors: ['W'],
    power: 1, toughness: 3, manaCost: 3,
    keywords: ['flying', 'vigilance'],
    oracleText: 'Flying, vigilance\nAs long as you control two or more artifacts, this creature gets +2/+0.',
    imageUri: 'https://cards.scryfall.io/large/front/2/9/29606c49-e1a4-49c3-883b-9122c08bbbc7.jpg?1783906648',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.static,
        condition: { minArtifactsControlled: 2 },
        pump: { power: 2, toughness: 0 },
      }),
    ],
    artId: 559, plan: 'Final Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 4. Mana Cylix (CON) {1} Artifact — filtr many na dowolny kolor.
  defineCard({
    id: 'mana-cylix', name: 'Mana Cylix', set: 'CON',
    types: ['Artifact'], colors: [], manaCost: 1,
    oracleText: '{1}, {T}: Add one mana of any color.',
    imageUri: 'https://cards.scryfall.io/large/front/6/8/68e25c75-5e20-4990-9b7e-9d04c94fee9f.jpg?1783942461',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 1, tap: true },
        effect: { type: 'add_mana', amount: 1, colors: ['W', 'U', 'B', 'R', 'G'] },
      }),
    ],
    artId: 565, plan: 'Alara',
    support: { status: 'supported', limitations: [] },
  }),

  // 5. Koilos Roc (BRO) {4}{U} 3/3 — flash, flying, ETB tapped Powerstone.
  defineCard({
    id: 'koilos-roc', name: 'Koilos Roc', set: 'BRO',
    types: ['Creature'], subtypes: ['Bird'], colors: ['U'],
    power: 3, toughness: 3, manaCost: 5,
    keywords: ['flash', 'flying'],
    oracleText: 'Flash\nFlying\nWhen this creature enters, create a tapped Powerstone token. (It\'s an artifact with "{T}: Add {C}. This mana can\'t be spent to cast a nonartifact spell.")',
    imageUri: 'https://cards.scryfall.io/large/front/e/b/ebdbcb87-c6ea-477f-a560-c175d99e21b8.jpg?1783920113',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: [{
          type: 'create_token', cardId: 'token_powerstone', name: 'Powerstone',
          kind: 'artifact', colors: [], types: ['Artifact'], subtypes: ['Powerstone'],
          abilities: [createAbility({
            type: ABILITY_TYPE.activated,
            cost: { tap: true },
            effect: { type: 'add_mana', amount: 1, colors: [], spendOnly: 'artifact' },
          })],
          tapped: true,
        }],
      }),
    ],
    artId: 563, plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
    notes: ['token Powerstone wchodzi ZATAPNIĘTY (tapped: true) — jak w druku BRO'],
  }),

  // 6. Kishla Village (TDM) Land — ETB tapped, chyba że kontrolujesz Island
  //    lub Swamp; {T}: Add {G}; {3}{G}, {T}: Surveil 2.
  defineCard({
    id: 'kishla-village', name: 'Kishla Village', set: 'TDM',
    types: ['Land'], colors: [],
    entersTapped: true,
    entersTappedCondition: { type: 'controls_land_subtype_any', subtypes: ['Island', 'Swamp'], amount: 1 },
    oracleText: 'This land enters tapped unless you control an Island or a Swamp.\n{T}: Add {G}.\n{3}{G}, {T}: Surveil 2. (Look at the top two cards of your library, then put any number of them into your graveyard and the rest on top of your library in any order.)',
    imageUri: 'https://cards.scryfall.io/large/front/9/f/9f0ff90d-7312-44df-afc5-29c768fa7758.jpg?1783907278',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        effect: { type: 'add_mana', amount: 1, colors: ['G'] },
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 4, tap: true },
        effect: { type: 'surveil', amount: 2 },
      }),
    ],
    artId: 557, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
    notes: ['warunek ETB to wariant danych (controls_land_subtype_any), nie kod karto-specyficzny — Oracle nie wymaga „other”, a sam land nie ma tych podtypów'],
  }),

  // 7. White Mage's Staff (FIN) {1}{W} Equipment — Job select; +1/+1, trigger
  //    ataku (1 życie) i typ Cleric; Equip {3}.
  defineCard({
    id: 'white-mages-staff', name: "White Mage's Staff", set: 'FIN',
    types: ['Artifact'], subtypes: ['Equipment'], colors: ['W'], manaCost: 2,
    equipment: { equip: 3, pump: { power: 1, toughness: 1 }, subtypes: ['Cleric'] },
    oracleText: 'Job select (When this Equipment enters, create a 1/1 colorless Hero creature token, then attach this to it.)\nEquipped creature gets +1/+1, has "Whenever this creature attacks, you gain 1 life," and is a Cleric in addition to its other types.\nEquip {3} ({3}: Attach to target creature you control. Equip only as a sorcery.)',
    imageUri: 'https://cards.scryfall.io/large/front/3/0/30db372e-0b4c-4e16-9667-bf3fda666f72.jpg?1783906642',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'enter_battlefield' },
        effect: { type: 'job_select' },
      }),
      // Trigger nadany nosicielowi siedzi na EQUIPMENCIE (wzorzec Greatsword
      // of Tyr): odpala się przy deklaracji ataku wyposażonego stwora.
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'equipped_creature_attacks' },
        effect: [{ type: 'gain_life', amount: 1 }],
      }),
      createAbility({
        type: ABILITY_TYPE.activated,
        keyword: 'equip',
        cost: { mana: 3 },
        effect: [],
      }),
    ],
    artId: 558, plan: 'Final Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 8. Time to Feed (THS) {2}{G} Sorcery — fight + opóźniony trigger „gdy ten
  //    stwór zginie w tej turze, zyskujesz 3 życia".
  defineCard({
    id: 'time-to-feed', name: 'Time to Feed', set: 'THS',
    types: ['Sorcery'], colors: ['G'], manaCost: 3,
    oracleText: 'Choose target creature an opponent controls. When that creature dies this turn, you gain 3 life. Target creature you control fights that creature.',
    imageUri: 'https://cards.scryfall.io/large/front/7/9/799d08a6-d978-4731-98ad-38acd57f3196.jpg?1783939736',
    spell: {
      timing: 'sorcery',
      targets: [
        { type: 'creature_opponent_controls' },
        { type: 'creature_you_control' },
      ],
      effects: [
        // Kolejność Oracle: znacznik śmierci PRZED walką — stwór zabity
        // w tej właśnie walce też daje 3 życia (CR 603.7a).
        { type: 'gain_life_if_target_dies_this_turn', targetIndex: 0, amount: 3 },
        { type: 'fight', targetIndexA: 1, targetIndexB: 0 },
      ],
    },
    artId: 561, plan: 'Theros',
    support: { status: 'supported', limitations: [] },
    notes: ['znacznik zakładany przed fightem, więc stwór zabity w tej walce także daje 3 życia'],
  }),

  // 9. Creakwood Safewright (ECL) {1}{B} 5/5 — wchodzi z trzema -1/-1;
  //    w end stepie zdejmuje licznik, jeśli w grobie jest Elf.
  defineCard({
    id: 'creakwood-safewright', name: 'Creakwood Safewright', set: 'ECL',
    types: ['Creature'], subtypes: ['Elf', 'Warrior'], colors: ['B'],
    power: 5, toughness: 5, manaCost: 2,
    entersWithCounters: { '-1/-1': 3 },
    oracleText: 'This creature enters with three -1/-1 counters on it.\nAt the beginning of your end step, if there is an Elf card in your graveyard and this creature has a -1/-1 counter on it, remove a -1/-1 counter from this creature.',
    imageUri: 'https://cards.scryfall.io/large/front/3/b/3bcc24cf-776a-4182-bf77-a611ad90b28f.jpg?1783904467',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: {
          event: 'end_step',
          condition: { subtypeCardInYourGraveyard: 'Elf', selfHasCounter: '-1/-1' },
        },
        effect: [{ type: 'remove_counter', counter: '-1/-1', amount: 1 }],
      }),
    ],
    artId: 566, plan: 'Lorwyn',
    support: { status: 'supported', limitations: [] },
    notes: ['intervening-if (CR 603.4): oba warunki sprawdzane przy odpaleniu i ponownie przy rozstrzyganiu'],
  }),

  // 10. Dead Ringers (APC) {4}{B} Sorcery — niszczy DWA nieczarne stwory
  //     tylko wtedy, gdy mają identyczne zbiory kolorów.
  defineCard({
    id: 'dead-ringers', name: 'Dead Ringers', set: 'APC',
    types: ['Sorcery'], colors: ['B'], manaCost: 5,
    oracleText: 'Destroy two target nonblack creatures unless either one is a color the other isn\'t. They can\'t be regenerated.',
    imageUri: 'https://cards.scryfall.io/large/front/9/b/9b78028c-3ebd-432d-b628-e1fa284f08f3.jpg?1783945349',
    spell: {
      timing: 'sorcery',
      targets: [
        { type: 'nonblack_creature' },
        { type: 'nonblack_creature' },
      ],
      effects: [
        { type: 'destroy_pair_if_same_colors', targetIndexA: 0, targetIndexB: 1 },
      ],
    },
    artId: 560, plan: 'Dominaria',
    support: { status: 'supported', limitations: [] },
    notes: ['„unless either one is a color the other isn\'t” = równość ZBIORÓW kolorów (CR 105.2); przy różnicy nie ginie żaden z celów', 'dwa bezbarwne stwory (puste zbiory) są legalnym, skutecznym celem'],
  }),

  // ===== Batch 49 (2026-08-26) =====================================

  // Dimir Guildgate (GRN) Land — Gate: enters tapped, {T}: Add {U} or {B}.
  // Zero nowych mechanik — wzorzec Dismal Backwater / Heap Gate bez lifegain.
  defineCard({
    id: 'dimir-guildgate', name: 'Dimir Guildgate', set: 'GRN',
    types: ['Land'], subtypes: ['Gate'], colors: [], entersTapped: true,
    oracleText: 'This land enters tapped.\n{T}: Add {U} or {B}.',
    imageUri: 'https://cards.scryfall.io/large/front/b/7/b7129bdf-de02-4ed2-b5de-f774b8a7d302.jpg?1783934104',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { tap: true },
        effect: { type: 'add_mana', amount: 1, colors: ['U', 'B'] },
      }),
    ],
    artId: 570, plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
  }),

  // Vow of Flight (CMR) {2}{U} Aura — +2/+2, flying, can't attack you.
  // Bliźniak Vow of Wildness (ten sam cykl) — zero nowych mechanik.
  defineCard({
    id: 'vow-of-flight', name: 'Vow of Flight', set: 'CMR',
    types: ['Enchantment'], subtypes: ['Aura'], colors: ['U'], manaCost: 3,
    oracleText: "Enchant creature\nEnchanted creature gets +2/+2, has flying, and can't attack you or planeswalkers you control.",
    imageUri: 'https://cards.scryfall.io/large/front/c/9/c9887121-6206-44bb-a1b4-520f28a61a17.jpg?1783928847',
    aura: { pump: { power: 2, toughness: 2 }, keywords: ['flying'], cantAttackYou: true },
    artId: 571,
    plan: 'Fiora',
    support: { status: 'supported', limitations: [] },
    notes: ['can\'t attack you — w 1v1 stwór przeciwnika z Vow nie może atakować (jedyny przeciwnik to Ty)'],
  }),

  // Nanoform Sentinel (EOE) {2}{U} 3/2 Artifact Creature — Robot.
  // „Whenever this creature becomes tapped, untap another target permanent.
  //  This ability triggers only once each turn.\" — nowa mechanika generyczna:
  // trigger `self_becomes_tapped` z celem (permanent, notSelf) + oncePerTurn.
  defineCard({
    id: 'nanoform-sentinel', name: 'Nanoform Sentinel', set: 'EOE',
    types: ['Artifact', 'Creature'], subtypes: ['Robot'], colors: ['U'],
    power: 3, toughness: 2, manaCost: 3,
    oracleText: 'Whenever this creature becomes tapped, untap another target permanent. This ability triggers only once each turn.',
    imageUri: 'https://cards.scryfall.io/large/front/3/e/3eeae8c3-7939-4c79-92f0-fbdb9c1b71d3.jpg?1783905976',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: {
          event: 'self_becomes_tapped',
          oncePerTurn: true,
          requiresTarget: { type: 'permanent', notSelf: true },
        },
        effect: [{ type: 'untap_permanent' }],
      }),
    ],
    artId: 568, plan: 'The Edge',
    support: { status: 'supported', limitations: [] },
    notes: ['„triggers only once each turn” — kolejne tapnięcia w tej samej turze nie odpalają triggera (triggerFiredThisTurn)'],
  }),

  // Jwar Isle Avenger (OGW) {4}{U} 3/3 Sphinx — Flying, Surge {2}{U}.
  // Nowa mechanika generyczna: surge (alt-cost rzutu z ręki, gdy rzucono inny
  // czar w tej turze; płatność normalną maną).
  defineCard({
    id: 'jwar-isle-avenger', name: 'Jwar Isle Avenger', set: 'OGW',
    types: ['Creature'], subtypes: ['Sphinx'], colors: ['U'],
    power: 3, toughness: 3, manaCost: 5, keywords: ['flying'],
    surge: { cost: 3, colors: ['U'] },
    oracleText: 'Surge {2}{U} (You may cast this spell for its surge cost if you or a teammate has cast another spell this turn.)\nFlying',
    imageUri: 'https://cards.scryfall.io/large/front/0/a/0a5b059f-2fa3-474f-9c74-6d4021703add.jpg?1783937918',
    artId: 567, plan: 'Zendikar',
    support: { status: 'supported', limitations: [] },
    notes: ['surge {2}{U}: alternatywny koszt rzutu z ręki, gdy rzuciłeś inny czar w tej turze (w 1v1 „teammate” nie występuje)'],
  }),

  // Manifest Dread (DSK) {1}{G} Sorcery — manifest dread.
  // Nowa mechanika generyczna: manifest_dread (look top 2, jedna face-down 2/2,
  // druga do grobu; obrót twarzą do góry za koszt many, jeśli karta stwora).
  defineCard({
    id: 'manifest-dread', name: 'Manifest Dread', set: 'DSK',
    types: ['Sorcery'], colors: ['G'], manaCost: 2,
    oracleText: 'Manifest dread. (Look at the top two cards of your library. Put one onto the battlefield face down as a 2/2 creature and the other into your graveyard. Turn it face up any time for its mana cost if it\'s a creature card.)',
    imageUri: 'https://cards.scryfall.io/large/front/a/6/a649265b-6c32-49e7-b6cb-6086c40d26e8.jpg?1783909451',
    spell: {
      timing: 'sorcery',
      targets: [],
      effects: [{ type: 'manifest_dread' }],
    },
    artId: 569, plan: 'Duskmourn',
    support: { status: 'supported', limitations: [] },
    notes: ['manifest dread: wybór którą z 2 kart z wierzchu zmanifestować (2/2 face-down), druga do grobu; obrót za koszt many tylko dla kart stworów (CR 701.34)'],
  }),

  // =========================================================================
  // Batch 51 (2026-08-28, lista właściciela: artId 572–579) — 8 kart.
  // Dane Oracle pobrane ze Scryfall per druk (docs/cards/scryfall-*.json),
  // artId i plan ze słownika kolekcji (tools/collection-art-ids.csv).
  //
  // Nowe mechaniki generyczne (osobne commity, ADR 0002 — zero warunków na
  // nazwę karty): bloodrush (zdolność z ręki, cel = atakujący stwór),
  // renown N (CR 702.112), statyczna prewencja obrażeń bojowych w gracza,
  // efekt na atakujące stwory, warunek mana value rzucanego czaru, filtr
  // celu „another permanent you control".
  // =========================================================================

  // 572GTC Skinbrand Goblin (GTC) {1}{R} 2/1 Goblin Warrior — Bloodrush.
  // „Bloodrush — {R}, Discard this card: Target attacking creature gets
  //  +2/+1 until end of turn." Bloodrush to SŁOWO ZDOLNOŚCI (CR 207.2c),
  // nie słowo kluczowe — mechanikę niesie zdolność aktywowana karty w ręce.
  defineCard({
    id: 'skinbrand-goblin', name: 'Skinbrand Goblin', set: 'GTC',
    types: ['Creature'], subtypes: ['Goblin', 'Warrior'], colors: ['R'],
    power: 2, toughness: 1, manaCost: 2,
    oracleText: 'Bloodrush — {R}, Discard this card: Target attacking creature gets +2/+1 until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/f/e/fe4f9b6c-3ba9-4f4f-8135-f5236195e507.jpg?1783940122',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 1, colors: ['R'] },
        bloodrush: { power: 2, toughness: 1 },
        targets: [{ type: 'attacking_creature' }],
        effect: { type: 'pump', power: 2, toughness: 1 },
      }),
    ],
    artId: 572, plan: 'Ravnica',
    support: { status: 'supported', limitations: [] },
    notes: ['bloodrush działa wyłącznie z ręki (koszt = odrzucenie karty) i wyłącznie w atakującego stwora — poza fazą walki zdolność nie ma legalnego celu (CR 508.1k)'],
  }),

  // 573FRF Typhoid Rats (FRF) {B} 1/1 Rat — deathtouch (druk Sultai z FRF).
  defineCard({
    id: 'typhoid-rats', name: 'Typhoid Rats', set: 'FRF',
    types: ['Creature'], subtypes: ['Rat'], colors: ['B'],
    power: 1, toughness: 1, manaCost: 1, keywords: ['deathtouch'],
    oracleText: 'Deathtouch (Any amount of damage this deals to a creature is enough to destroy it.)',
    imageUri: 'https://cards.scryfall.io/large/front/d/1/d13cb90b-50c3-46ef-83f8-812dfb7ff881.jpg?1783938691',
    artId: 573, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),

  // 574M15 Invasive Species (M15) {2}{G} 3/3 Insect —
  // „When this creature enters, return another permanent you control to its
  //  owner's hand." Cel jest obowiązkowy: bez własnego permanentu trigger
  // gaśnie bez efektu (CR 603.3d).
  defineCard({
    id: 'invasive-species', name: 'Invasive Species', set: 'M15',
    types: ['Creature'], subtypes: ['Insect'], colors: ['G'],
    power: 3, toughness: 3, manaCost: 3,
    oracleText: "When this creature enters, return another permanent you control to its owner's hand.",
    imageUri: 'https://cards.scryfall.io/large/front/c/1/c1fb5a98-94f4-419f-850b-e3a01f17080f.jpg?1783939166',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: {
          event: 'enter_battlefield',
          requiresTarget: { type: 'permanent', controlledBy: 'controller', notSelf: true },
        },
        effect: [{ type: 'bounce_permanent' }],
      }),
    ],
    artId: 574, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
    notes: ['cel obowiązkowy — przy braku innego własnego permanentu trigger gaśnie bez efektu (CR 603.3d); polityka deterministyczna wybiera najcenniejszy własny permanent'],
  }),

  // 575DTK Dromoka Warrior (DTK) {1}{W} 3/1 Human Warrior — wanilia.
  defineCard({
    id: 'dromoka-warrior', name: 'Dromoka Warrior', set: 'DTK',
    types: ['Creature'], subtypes: ['Human', 'Warrior'], colors: ['W'],
    power: 3, toughness: 1, manaCost: 2, oracleText: '',
    imageUri: 'https://cards.scryfall.io/large/front/1/3/13ae001b-556f-4576-8cf4-0b8902997bb1.jpg?1783938618',
    artId: 575, plan: 'Tarkir',
    support: { status: 'supported', limitations: [] },
  }),

  // 576ORI Akroan Sergeant (ORI) {2}{R} 2/2 Human Soldier —
  // first strike + Renown 1 (CR 702.112).
  defineCard({
    id: 'akroan-sergeant', name: 'Akroan Sergeant', set: 'ORI',
    types: ['Creature'], subtypes: ['Human', 'Soldier'], colors: ['R'],
    power: 2, toughness: 2, manaCost: 3, keywords: ['first_strike'], renown: 1,
    oracleText: "First strike (This creature deals combat damage before creatures without first strike.)\nRenown 1 (When this creature deals combat damage to a player, if it isn't renowned, put a +1/+1 counter on it and it becomes renowned.)",
    imageUri: 'https://cards.scryfall.io/large/front/3/1/31913547-460c-45b3-be23-89f0e3a43325.jpg?1783938333',
    artId: 576, plan: 'Theros',
    support: { status: 'supported', limitations: [] },
    notes: ['renown 1: licznik +1/+1 za PIERWSZE obrażenia bojowe zadane graczowi (znacznik „renowned” ginie po opuszczeniu pola bitwy, CR 702.112b)'],
  }),

  // 577DST Thunderstaff (DST) {3} Artifact — prewencja statyczna (dopóki
  // nietapnięty) oraz {2}, {T}: atakujące stwory dostają +1/+0 do końca tury.
  defineCard({
    id: 'thunderstaff', name: 'Thunderstaff', set: 'DST',
    types: ['Artifact'], colors: [], manaCost: 3,
    oracleText: 'As long as this artifact is untapped, if a creature would deal combat damage to you, prevent 1 of that damage.\n{2}, {T}: Attacking creatures get +1/+0 until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/8/4/84d23ce7-3880-40e7-985b-a8dce97ff77c.jpg?1783944415',
    abilities: [
      // Prewencja wyłącza się po tapnięciu — warunek „untapped" jest częścią
      // tekstu karty, więc engine czyta stan permanentu przy każdych obrażeniach.
      createAbility({
        type: ABILITY_TYPE.static,
        preventCombatDamageToController: { amount: 1 },
      }),
      // {2}, {T}: atakujące stwory +1/+0 do końca tury (zbiór ustalany przy
      // rozstrzygnięciu, CR 611.2c).
      createAbility({
        type: ABILITY_TYPE.activated,
        cost: { mana: 2, tap: true },
        effect: { type: 'buff_attacking_creatures', power: 1, toughness: 0 },
      }),
    ],
    artId: 577, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
    notes: ['prewencja 1 liczy się od KAŻDEGO źródła obrażeń bojowych (trzech atakujących = 3 zapobiegnięte), nie raz na turę'],
  }),

  // 578THS Savage Surge (THS) {1}{G} Instant —
  // „Target creature gets +2/+2 until end of turn. Untap that creature."
  defineCard({
    id: 'savage-surge', name: 'Savage Surge', set: 'THS',
    types: ['Instant'], colors: ['G'], manaCost: 2,
    oracleText: 'Target creature gets +2/+2 until end of turn. Untap that creature.',
    imageUri: 'https://cards.scryfall.io/large/front/5/9/5916d5e7-0825-4d72-82e4-1e4c86d1fafe.jpg?1783939737',
    spell: {
      timing: 'instant',
      targets: [{ type: 'creature' }],
      effects: [
        { type: 'buff_creature_until_end_of_turn', power: 2, toughness: 2 },
        { type: 'untap_permanent' },
      ],
    },
    artId: 578, plan: 'Warhammer Fantasy',
    support: { status: 'supported', limitations: [] },
  }),

  // 579ECL Kulrath Mystic (ECL) {2}{U} 2/4 Elemental Wizard —
  // „Whenever you cast a spell with mana value 4 or greater, this creature
  //  gets +2/+0 and gains vigilance until end of turn."
  defineCard({
    id: 'kulrath-mystic', name: 'Kulrath Mystic', set: 'ECL',
    types: ['Creature'], subtypes: ['Elemental', 'Wizard'], colors: ['U'],
    power: 2, toughness: 4, manaCost: 3,
    oracleText: 'Whenever you cast a spell with mana value 4 or greater, this creature gets +2/+0 and gains vigilance until end of turn.',
    imageUri: 'https://cards.scryfall.io/large/front/3/7/377d257c-920c-4dd4-a4b1-01cbc631ef8f.jpg?1783904487',
    abilities: [
      createAbility({
        type: ABILITY_TYPE.triggered,
        trigger: { event: 'when_you_cast_spell', condition: { spellManaValueAtLeast: 4 } },
        effect: { type: 'buff_creature_until_end_of_turn', power: 2, toughness: 0, keywords: ['vigilance'] },
      }),
    ],
    artId: 579, plan: 'Lorwyn',
    support: { status: 'supported', limitations: [] },
    notes: ['mana value to koszt many z karty (CR 202.3) — mana WYDANA po zniżkach nie ma znaczenia'],
  }),


]);

/**
 * M173/B (uwaga właściciela): druki Scryfalla dla TOKENÓW. Tokeny mają
 * cardId `token_*` spoza rejestru kart, więc kafel nie znajdował żadnej
 * ilustracji. Adresy WYŁĄCZNIE z API Scryfalla (L26 — bez zgadywania UUID);
 * kolejne tokeny uzupełniamy tą samą mapą.
 */
export const TOKEN_IMAGES = Object.freeze({
  // Squirrel 1/1 G (TMSH 14) — api.scryfall.com/cards/fd0474f3-682d-4c6d-b902-84f3250aa269
  token_squirrel: 'https://cards.scryfall.io/large/front/f/d/fd0474f3-682d-4c6d-b902-84f3250aa269.jpg?1783902800',
});

/** Registry repozytorium: katalog syntetyczny (stabilna baza testów) + realne karty + wirtualne landy podstawowe. */
export function createCardRegistry() {
  return createRegistry([...REAL_CARDS, ...VIRTUAL_BASIC_LANDS]);
}
