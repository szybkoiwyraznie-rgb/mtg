# Ilustracje kart na stole

Jak Wirtualny Stół dobiera obrazy kart i co zrobić, żeby działały też lokalne
ilustracje właściciela (warianty FOT/KON z arkusza kolekcji).

Kod: [`src/table/card-images.js`](../../src/table/card-images.js) (adresy),
[`src/table/render.js`](../../src/table/render.js) (ładowanie i fallback),
[`tools/fetch-art-ids.mjs`](../../tools/fetch-art-ids.mjs) (numery ilustracji).

## Co widać na stole

| Miejsce | Obraz | Rozmiar |
|---|---|---|
| Kafel karty (stół, ręka, groby, exile) | druk ze Scryfalla z `imageUri` definicji karty | `normal` (488×680) |
| Podgląd hover (desktop) | ten sam druk | `large` (672×936) |
| Pełny podgląd karty (klik / menu) | ten sam druk | `large` |
| Karta zakryta (morph, ręka przeciwnika) | wspólny rewers Magica | — |
| Karta bez druku (syntetyczna, token) | kolorowa twarz syntetyczna | — |

Reguła nadrzędna: **obraz jest domyślny, syntetyczna twarz jest fallbackiem.**
Twarz zostaje w DOM przez cały czas i pokazuje się, dopóki obraz się nie
wczyta — a po błędzie (404, brak sieci, tryb offline) zostaje na stałe. Nigdy
nie ma pustego kafla, a stół działa bez internetu.

Szczegóły:

- **Lazy-load** (`loading="lazy"`, `decoding="async"`): przeglądarka pobiera
  tylko to, co realnie widać — na stole bywa kilkadziesiąt kart.
- **Tapnięcie** obraca cały kafel (`.tile.tapped .cardvis`), więc ilustracja
  kręci się razem z ramką.
- **DFC (transform)**: obiekt gry po transformacji ma `cardId` drugiej strony,
  a jej definicja własny `imageUri` z `/back/` — kafel sam pokazuje tył.
- **Wirtualne landy podstawowe** nie mają druku w definicji batchowej, więc
  używają przekierowania po nazwie (`api.scryfall.com/cards/named?exact=…`),
  dokładnie jak plik legacy. Decyzja właściciela: druk domyślny Scryfalla.
  Świadomy koszt: Scryfall może z czasem zmienić, który druk jest domyślny.
- **Nakładka stanu** (obrażenia, choroba przywołania, aura/equipment,
  efektywne P/T) rysuje się **na** ilustracji — druk zna tylko wartości bazowe.
- **Fog of War**: każda zakryta karta ma ten sam adres rewersu. Gdyby zależał
  od karty, samo pobranie pliku zdradzałoby tożsamość (ADR 0003).

## Tory podglądu i scroll (jak w legacy HTML)

Na desktopie hover pokazuje powiększenie, a **scroll nad kartą przełącza tor**
(`playtableState.hoverMode` w legacy):

| Tor | Źródło | Kształt okna |
|---|---|---|
| `scryfall` (domyślny) | pełna karta ze Scryfalla | 320×448 |
| `fot` | `./img/<artId>FOT.png` — panorama 21:9 | 900×386 |
| `kon` | `./img/<artId>KON.png` — bestiariusz 16:9 | 900×550 |

Tory lokalne wymagają `artId` (numer z arkusza kolekcji) i plików w `./img/`.
Gdy któregoś brakuje, podgląd cicho spada na pełną kartę ze Scryfalla.
Tor żyje w pamięci strony — bez `localStorage`.

Na urządzeniach dotykowych hover pozostaje wyłączony (M7c): tapnięcie otwiera
menu kontekstowe, a pełny obraz jest pod pozycją „Pełny podgląd karty".

## Skąd się bierze `artId`

W arkuszu kolekcji nie ma kolumny z ID — numer jest **prefiksem kolumny
`Ilustracja`**, zob. audyt §3.2. Format bywał różny: `412FOT.png` → `412`,
`77.png` → `77`, `9KRA.png` → `9`, a obecnie `1LTR` (liczba + kod setu) → `1`.
Narzędzie odcina sufiks pliku (`FOT`/`KON`/`KRA`/`.png`) i bierze liczbę
z początku. Uzupełnia to narzędzie, a nie człowiek:

```bash
# Bez żadnych argumentów narzędzie używa lokalnego słownika
# tools/collection-art-ids.csv (pełna lista kart kolekcji wersjonowana w repo).
node tools/fetch-art-ids.mjs --dry-run   # raport dopasowań
node tools/fetch-art-ids.mjs             # dopisuje artId do src/cards/card-data.js
npm test && npm run build

# Świeże dane z sieci (gdy słownik nie zawiera nowej karty):
export MTG_COLLECTION_CSV_URL='https://docs.google.com/spreadsheets/…/pub?output=csv'
node tools/fetch-art-ids.mjs --dry-run
```

Kolejność źródeł i logika dopasowania (bez `--csv`):

1. **lokalny słownik `tools/collection-art-ids.csv`** — domyślne źródło,
   działa offline (nowy batch: `node tools/fetch-art-ids.mjs --dry-run`);
2. **karty spoza słownika** → świeży fetch z arkusza (`MTG_COLLECTION_CSV_URL`
   lub `csvUrl` z configu); gdy fetch się nie powiedzie — czytelne ostrzeżenie;
3. **karty nadal bez numeru** → zostają bez `artId`, tory FOT/KON cicho
   spadają na pełną kartę ze Scryfalla (poprawne dla kart spoza kolekcji).

`--csv plik` to pełne nadpisanie źródeł — używa wyłącznie danego pliku,
bez słownika i sieci. Wystarczy eksport zredukowany do kolumn `A:B`
(`…pub?gid=0&single=true&output=csv&range=A:B`), bo dopasowanie idzie po
nazwie, a kolumny Prompt/Narracja/Lore są ogromne.

## Słownik kart w repozytorium (`tools/collection-art-ids.csv`)

Pełna lista kart z arkusza (kolumny `Ilustracja`, `Nazwa Karty`; stan na
2026-08-02: 542 karty) jest wersjonowana w repo — **nowy batch sprawdzisz
bez sieci**:

```bash
node tools/fetch-art-ids.mjs --dry-run   # domyślnie czyta słownik z repo
```

Słownik zawiera **wszystkie karty kolekcji z ID setu** (`1LTR` = karta nr 1
z setu LTR, `5_2XM` = nr 5 z setu 2XM; wiodący podkreślnik to ucieczka arkusza
dla setów zaczynających się cyfrą). **Duplikaty nazw z różnych setów zostają
w słowniku** (np. Negate `76M15` i `461M20`) — dopasowanie preferuje wpis
zgodny z setem karty z `card-data.js`, a bez zgodnego setu bierze pierwszy.
Test pilnuje, że słownik ma komplet wpisów i że każda karta z `artId`
w katalogu ma zgodny wpis.

- Karty z raportu „Bez odpowiednika w arkuszu", które **są** w kolekcji —
  wymagają odświeżenia słownika (pobierz świeży eksport `range=A:B` z arkusza,
  nadpisz `tools/collection-art-ids.csv`, zacommituj razem z `card-data.js`).
- Karty, których w kolekcji nie ma — zostają bez `artId`, a tory FOT/KON
  spadają na Scryfall (poprawne zachowanie).

Test `test/art-ids-tool.test.js` pilnuje, że każda karta z `artId`
w `src/cards/card-data.js` ma zgodny wpis w słowniku — rozjazd słownik↔katalog
od razu wywali CI.

Stan na 2026-08-02: wszystkie 13 realnych kart ma `artId` uzupełnione (M13).
Dopóki pliki `./img/<artId>FOT.png` / `KON.png` nie istnieją, tory lokalne
cicho spadają na pełną kartę ze Scryfalla.

Zasady:

- narzędzie dopasowuje wiersze do kart **po nazwie** (bez rozróżniania wielkości liter);
- zapis jest **idempotentny** — ponowne uruchomienie nic nie zmienia;
- do repozytorium i do artefaktu stołu trafiają wyłącznie numery (`artId`),
  nigdy sam adres arkusza — adres żyje tylko w zmiennej środowiskowej lub w
  `tools/collection.config.json` (zob. uwaga o sekretach niżej);
- `tools/collection.config.json` (pole `csvUrl`) jest opcjonalny i **tylko dla
  publicznie opublikowanych arkuszy** — właściciel zatwierdził to 2026-08-02,
  bo jego arkusz kolekcji jest jawny (nie jest sekretem wg [SECURITY.md](../../SECURITY.md)
  §Sekrety). Dla prywatnego arkusza ten plik należy usunąć i używać wyłącznie
  zmiennej środowiskowej / sekretu GitHub Actions.

Dopóki `artId` nie istnieje (stan po pierwszym wdrożeniu), tory FOT/KON
zachowują się jak tor Scryfall — funkcja jest gotowa, brakuje tylko danych.

## Tryb lokalny `./img/` dla pełnego podglądu

Przełącznik „Ilustracje" w pasku stołu nadal steruje kolejnością źródeł
w **pełnym podglądzie karty**: `img/<SET>/<slug>.jpg` przed Scryfallem
(tryb `local-first`, domyślny przy otwarciu pliku z dysku) albo odwrotnie.
Kafle na stole zawsze idą po druk ze Scryfalla — tak zdecydował właściciel.
